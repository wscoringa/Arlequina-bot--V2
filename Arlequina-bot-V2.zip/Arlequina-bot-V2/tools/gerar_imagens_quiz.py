# Gera todas as imagens do menu QUIZ em arquivos/imagem/quiz/  (python3 tools/gerar_imagens_quiz.py)
import os, math, random
from PIL import Image, ImageDraw, ImageFont, ImageFilter

OUT = os.path.join(os.path.dirname(__file__), '..', 'arquivos', 'imagem', 'quiz')
os.makedirs(OUT, exist_ok=True)
W, H = 1280, 720
POP = '/usr/share/fonts/truetype/google-fonts/Poppins-%s.ttf'
EMO = '/usr/share/fonts/truetype/noto/NotoColorEmoji.ttf'
def F(w, s): return ImageFont.truetype(POP % w, s)

def emoji(img, ch, size, cx, cy):
    f = ImageFont.truetype(EMO, 109)
    tmp = Image.new('RGBA', (160, 160), (0, 0, 0, 0))
    ImageDraw.Draw(tmp).text((80, 80), ch, font=f, embedded_color=True, anchor='mm')
    bb = tmp.getbbox() or (0, 0, 160, 160)
    tmp = tmp.crop(bb)
    r = size / max(tmp.size)
    tmp = tmp.resize((max(1, int(tmp.width * r)), max(1, int(tmp.height * r))), Image.LANCZOS)
    img.paste(tmp.convert('RGB'), (int(cx - tmp.width / 2), int(cy - tmp.height / 2)), tmp.split()[3])

def fundo(c1, c2, seed=1):
    img = Image.new('RGB', (W, H))
    px = img.load()
    for y in range(H):
        for x in range(W):
            t = (x / W * 0.4 + y / H * 0.6)
            px[x, y] = tuple(int(c1[i] + (c2[i] - c1[i]) * t) for i in range(3))
    d = ImageDraw.Draw(img, 'RGBA')
    rnd = random.Random(seed)
    # losangos de arlequim
    for gx in range(-1, 12):
        for gy in range(-1, 7):
            cx, cy, s = gx * 130 + (65 if gy % 2 else 0), gy * 130, 60
            if (gx + gy) % 2 == 0:
                d.polygon([(cx, cy - s), (cx + s, cy), (cx, cy + s), (cx - s, cy)], fill=(255, 255, 255, 10))
    # glow
    g = Image.new('RGBA', (W, H), (0, 0, 0, 0))
    gd = ImageDraw.Draw(g)
    for _ in range(14):
        x, y, r = rnd.randint(0, W), rnd.randint(0, H), rnd.randint(40, 120)
        gd.ellipse([x - r, y - r, x + r, y + r], fill=(255, 255, 255, 14))
    g = g.filter(ImageFilter.GaussianBlur(30))
    img.paste(g.convert('RGB'), (0, 0), g.split()[3])
    return img

def moldura(img, cor):
    d = ImageDraw.Draw(img, 'RGBA')
    d.rounded_rectangle([26, 26, W - 26, H - 26], 34, outline=cor + (255,), width=6)
    d.rounded_rectangle([44, 44, W - 44, H - 44], 26, outline=(255, 255, 255, 70), width=2)

def texto_c(d, xy, t, font, fill, sombra=True):
    x, y = xy
    if sombra: d.text((x + 4, y + 5), t, font=font, fill=(0, 0, 0, 150), anchor='mm')
    d.text((x, y), t, font=font, fill=fill, anchor='mm')

def banner(nome, titulo, sub, emo, c1, c2, acento, faixa=None, seed=1):
    img = fundo(c1, c2, seed)
    moldura(img, acento)
    d = ImageDraw.Draw(img, 'RGBA')
    # faixa topo
    d.rounded_rectangle([W // 2 - 260, 60, W // 2 + 260, 118], 28, fill=(0, 0, 0, 120), outline=acento + (255,), width=3)
    texto_c(d, (W // 2, 90), 'ARLEQUINA  •  QUIZ', F('SemiBold' if os.path.exists(POP % 'SemiBold') else 'Bold', 28), (255, 255, 255, 255), False)
    # halo + emoji
    halo = Image.new('RGBA', (W, H), (0, 0, 0, 0))
    ImageDraw.Draw(halo).ellipse([W // 2 - 190, 150, W // 2 + 190, 530], fill=acento + (70,))
    hb = halo.filter(ImageFilter.GaussianBlur(35)); img.paste(hb.convert('RGB'), (0, 0), hb.split()[3])
    d = ImageDraw.Draw(img, 'RGBA')
    d.ellipse([W // 2 - 150, 175, W // 2 + 150, 475], fill=(0, 0, 0, 90), outline=acento + (255,), width=5)
    emoji(img, emo, 190, W // 2, 325)
    d = ImageDraw.Draw(img, 'RGBA')
    fs = 96
    while F('Bold', fs).getlength(titulo) > W - 360: fs -= 4
    texto_c(d, (W // 2, 555), titulo, F('Bold', fs), (255, 255, 255, 255))
    d.rounded_rectangle([W // 2 - 90, 610, W // 2 + 90, 616], 3, fill=acento + (255,))
    texto_c(d, (W // 2, 655), sub, F('Medium', 32), (255, 255, 255, 225), False)
    for cx in (110, W - 110):
        emoji(img, '🃏', 70, cx, 100); emoji(img, '💜', 60, cx, H - 100)
    img.convert('RGB').save(os.path.join(OUT, nome + '.jpg'), quality=92)

# ---- paletas
ROXO = ((44, 8, 84), (150, 30, 140), (255, 120, 230))
VERDE = ((6, 60, 40), (30, 150, 90), (120, 255, 170))
AMAR = ((84, 56, 4), (200, 140, 20), (255, 220, 90))
VERM = ((70, 6, 20), (190, 30, 60), (255, 110, 130))
AZUL = ((8, 24, 84), (40, 100, 200), (120, 200, 255))
ROSA = ((90, 10, 70), (220, 60, 150), (255, 160, 220))
LARA = ((84, 30, 4), (220, 100, 20), (255, 180, 90))
CIAN = ((4, 60, 70), (20, 160, 170), (110, 240, 240))
CINZA = ((24, 20, 40), (70, 60, 110), (190, 170, 255))

B = {  # arquivo: (titulo, subtitulo, emoji, paleta)
 'quiz': ('QUIZ', 'Perguntas gerais valendo pontos', '🧠', ROXO),
 'quizfacil': ('QUIZ FÁCIL', 'Aquecimento pra começar', '🟢', VERDE),
 'quizmedio': ('QUIZ MÉDIO', 'Pra quem já sabe das coisas', '🟡', AMAR),
 'quizdificil': ('QUIZ DIFÍCIL', 'Só os brabos acertam', '🔴', VERM),
 'quizveloz': ('QUIZ VELOZ', 'Só 30 segundos. Corre!', '⚡', AMAR),
 'quizen': ('QUIZ EN', 'English quiz', '🇺🇸', AZUL),
 'quizes': ('QUIZ ES', 'Quiz en español', '🇪🇸', VERM),
 'quizpt': ('QUIZ PT', 'Quiz em português', '🇧🇷', VERDE),
 'quizrusso': ('QUIZ RUSSO', 'Викторина', '🇷🇺', AZUL),
 'quizcoreano': ('QUIZ COREANO', '한국어 퀴즈', '🇰🇷', ROSA),
 'quizjapones': ('QUIZ JAPONÊS', '日本語クイズ', '🇯🇵', VERM),
 'quiztemageografia': ('GEOGRAFIA', 'Quiz por tema', '🌍', CIAN),
 'quiztemaanimal': ('ANIMAIS', 'Quiz por tema', '🐾', VERDE),
 'quiztemapokemon': ('POKÉMON', 'Quiz por tema', '⚡', AMAR),
 'quiztemakpop': ('K-POP', 'Quiz por tema', '🎤', ROSA),
 'quiztemafutebol': ('FUTEBOL', 'Quiz por tema', '⚽', VERDE),
 'quiztemamarvel': ('MARVEL', 'Quiz por tema', '🦸', VERM),
 'quiztemaanime': ('ANIME', 'Quiz por tema', '🎌', ROSA),
 'quiztemahistoria': ('HISTÓRIA', 'Quiz por tema', '📜', LARA),
 'quiztemaciencia': ('CIÊNCIA', 'Quiz por tema', '🔬', CIAN),
 'quiztemaharrypotter': ('HARRY POTTER', 'Quiz por tema', '🧙', ROXO),
 'quiztemafilme': ('FILMES', 'Quiz por tema', '🎬', CINZA),
 'adivinhapalavra': ('ADIVINHA A PALAVRA', 'Descubra pela dica', '🔤', AZUL),
 'girias': ('QUIZ DE GÍRIAS', 'Você entende o povo?', '🗣️', VERDE),
 'proverbio': ('PROVÉRBIO', 'Sabedoria popular', '📜', LARA),
 'completeprovervio': ('COMPLETE O PROVÉRBIO', 'Termine a frase', '📜', LARA),
 'completeamusica': ('COMPLETE A MÚSICA', 'Cante e acerte', '🎵', ROSA),
 'completeafrase': ('COMPLETE A FRASE', 'Falta uma palavra', '📝', AZUL),
 'charada': ('CHARADA', 'Use a cabeça', '🧩', ROXO),
 'emojifilme': ('EMOJI FILME', 'Adivinhe pelos emojis', '🎬', CINZA),
 'emojianimal': ('EMOJI ANIMAL', 'Adivinhe pelos emojis', '🐾', VERDE),
 'emojipais': ('EMOJI PAÍS', 'Adivinhe pelos emojis', '🌍', CIAN),
 'adivinhenumero': ('ADIVINHE O NÚMERO', 'De 1 a 100 • 10 tentativas', '🔢', AZUL),
 'maioromenor': ('MAIOR OU MENOR', 'O próximo é maior ou menor?', '🃏', ROXO),
 'parouimpar': ('PAR OU ÍMPAR', 'Sorte grande', '🎲', AMAR),
 'simounao': ('SIM OU NÃO', 'A Arlequina responde', '🔮', ROXO),
 'verdadeirooufalso': ('VERDADEIRO OU FALSO', 'Será que é mesmo?', '✅', VERDE),
 'matematicaquiz': ('MATEMÁTICA', 'Calcule rápido', '➕', AZUL),
 'dica': ('DICA', 'Uma ajudinha da Arlequina', '💡', AMAR),
 'pular': ('PULAR', 'Pergunta pulada', '⏭️', CINZA),
 'quizparar': ('QUIZ PARADO', 'Até a próxima rodada', '🛑', VERM),
 'resposta_certa': ('ACERTOU!', 'Mandou muito bem', '🎉', VERDE),
 'resposta_errada': ('ERROU!', 'Tenta de novo', '❌', VERM),
 'tempo': ('TEMPO ESGOTADO', 'Acabou o tempo', '⏰', VERM),
 'score': ('SUA PONTUAÇÃO', 'Seu desempenho no quiz', '📊', ROXO),
 'quiztop': ('TOP QUIZ', 'Ranking do grupo', '🏆', AMAR),
 'chute_certo': ('ACERTOU O NÚMERO!', 'Na mosca', '🎯', VERDE),
 'chute_perdeu': ('GAME OVER', 'Acabaram as tentativas', '💀', VERM),
 'chute_maior': ('É MAIOR ⬆️', 'Tenta um número maior', '📈', AZUL),
 'chute_menor': ('É MENOR ⬇️', 'Tenta um número menor', '📉', LARA),
 'forca_desistiu': ('DESISTIU', 'A forca ficou vazia', '🏳️', CINZA),
 'menuquiz': ('MENU QUIZ', 'Todos os jogos da Arlequina', '🃏', ROXO),
}
for i, (k, (t, s, e, p)) in enumerate(B.items()):
    banner(k, t, s, e, p[0], p[1], p[2], seed=i + 3)

# ---------- FORCA: 7 estágios (0 a 6 erros) + vitória + derrota
def forca(estagio, nome, final=None):
    c1, c2, ac = (ROXO if final != 'lose' else VERM)[:3]
    img = fundo(c1, c2, 7)
    moldura(img, ac)
    d = ImageDraw.Draw(img, 'RGBA')
    d.rounded_rectangle([W // 2 - 300, 58, W // 2 + 300, 122], 30, fill=(0, 0, 0, 130), outline=ac + (255,), width=3)
    tit = {'win': 'VOCÊ SALVOU!', 'lose': 'ENFORCADO!'}.get(final, 'JOGO DA FORCA')
    texto_c(d, (W // 2, 92), tit, F('Bold', 40), (255, 255, 255, 255), False)
    # placa
    d.rounded_rectangle([330, 150, 950, 650], 40, fill=(0, 0, 0, 100), outline=(255, 255, 255, 90), width=3)
    madeira = (210, 160, 100, 255)
    sombra = (0, 0, 0, 110)
    def linha(p, w, c=madeira):
        d.line([(p[0] + 4, p[1] + 5), (p[2] + 4, p[3] + 5)], fill=sombra, width=w)
        d.line(p, fill=c, width=w)
    linha((420, 620, 700, 620), 22)          # base
    linha((520, 620, 520, 210), 20)          # poste
    linha((510, 210, 780, 210), 20)          # topo
    linha((520, 300, 600, 210), 14)          # reforço
    linha((760, 210, 760, 270), 8, (235, 235, 235, 255))  # corda
    cor = (255, 255, 255, 255) if final != 'lose' else (255, 120, 130, 255)
    if final == 'win': cor = (150, 255, 180, 255)
    def bl(p, w=12): 
        d.line([(p[0] + 3, p[1] + 4), (p[2] + 3, p[3] + 4)], fill=sombra, width=w)
        d.line(p, fill=cor, width=w)
    if final == 'win':
        ox, oy = 95, 52
        d.ellipse([720 + ox, 266 + oy, 796 + ox, 342 + oy], outline=cor, width=10)
        d.ellipse([740 + ox, 292 + oy, 748 + ox, 300 + oy], fill=cor); d.ellipse([768 + ox, 292 + oy, 776 + ox, 300 + oy], fill=cor)
        d.arc([740 + ox, 305 + oy, 776 + ox, 330 + oy], 10, 170, fill=cor, width=4)
        bl((758 + ox, 342 + oy, 758 + ox, 480 + oy))
        bl((758 + ox, 372 + oy, 705 + ox, 320 + oy)); bl((758 + ox, 372 + oy, 811 + ox, 320 + oy))   # braços pra cima
        bl((758 + ox, 480 + oy, 705 + ox, 565 + oy)); bl((758 + ox, 480 + oy, 811 + ox, 565 + oy))
    if final != 'win' and estagio >= 1:  # cabeça
        d.ellipse([722, 268, 798, 344], outline=(0, 0, 0, 110), width=12)
        d.ellipse([720, 266, 796, 342], outline=cor, width=10)
        if final == 'lose':
            for ex in (743, 773):
                d.line([(ex - 7, 293), (ex + 7, 307)], fill=cor, width=4); d.line([(ex - 7, 307), (ex + 7, 293)], fill=cor, width=4)
        else:
            d.ellipse([740, 292, 748, 300], fill=cor); d.ellipse([768, 292, 776, 300], fill=cor)
            if final == 'win': d.arc([740, 305, 776, 330], 10, 170, fill=cor, width=4)
            elif estagio >= 4: d.arc([742, 316, 774, 332], 190, 350, fill=cor, width=4)
            else: d.line([(745, 320), (771, 320)], fill=cor, width=4)
    if final != 'win' and estagio >= 2: bl((758, 342, 758, 480))            # corpo
    if final != 'win' and estagio >= 3: bl((758, 372, 700, 435))            # braço esq
    if final != 'win' and estagio >= 4: bl((758, 372, 816, 435))            # braço dir
    if final != 'win' and estagio >= 5: bl((758, 480, 705, 565))            # perna esq
    if final != 'win' and estagio >= 6: bl((758, 480, 811, 565))            # perna dir
    # vidas (corações) em coluna à esquerda + erros à direita
    restante = 6 - estagio
    d.rounded_rectangle([80, 170, 290, 640], 30, fill=(0, 0, 0, 110), outline=ac + (255,), width=3)
    texto_c(d, (185, 205), 'VIDAS', F('Bold', 30), (255, 255, 255, 255), False)
    for i in range(6):
        emoji(img, '💜' if i < restante else '🖤', 56, 185, 275 + i * 63)
    d.rounded_rectangle([990, 170, 1200, 640], 30, fill=(0, 0, 0, 110), outline=ac + (255,), width=3)
    texto_c(d, (1095, 205), 'ERROS', F('Bold', 30), (255, 255, 255, 255), False)
    texto_c(d, (1095, 330), f'{estagio}/6', F('Bold', 84), (255, 255, 255, 255))
    partes = ['cabeça', 'corpo', 'braço', 'braço', 'perna', 'perna']
    if final == 'win': texto_c(d, (1095, 450), 'SALVO!', F('Bold', 40), (150, 255, 180, 255), False)
    elif final == 'lose': texto_c(d, (1095, 450), 'FIM', F('Bold', 44), (255, 130, 140, 255), False)
    elif estagio: texto_c(d, (1095, 450), partes[estagio - 1], F('Medium', 32), ac + (255,), False)
    else: texto_c(d, (1095, 450), 'sem erros', F('Medium', 30), ac + (255,), False)
    img.convert('RGB').save(os.path.join(OUT, nome + '.jpg'), quality=92)

for e in range(7): forca(e, f'forca_{e}')
forca(6, 'forca_lose', 'lose')
forca(0, 'forca_win', 'win')
print('ok', len(os.listdir(OUT)), 'imagens')
