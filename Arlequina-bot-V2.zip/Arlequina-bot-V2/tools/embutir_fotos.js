/*
 Roda ISSO UMA VEZ SÓ, no celular/PC onde o bot tem internet de
 verdade (não dá pra rodar aqui no chat comigo, eu não tenho acesso
 à internet pra baixar as fotos):

     node tools/embutir_fotos.js

 O que ele faz: entra em cada comando de brincadeiras/rank que tem
 "LINK_FOTO = 'https://pin.it/...'", baixa a foto de verdade (usando
 o mesmo sistema que já corrige o problema do Pinterest) e TROCA essa
 linha por "LINK_FOTO = 'data:image/jpeg;base64,XXXXXX...'" — ou seja,
 a foto passa a morar dentro do próprio arquivo .js do comando.

 Depois disso:
 - Nunca mais acessa a internet pra essa foto.
 - Nunca mais grava NADA em midias/ (zero chance de ir pra galeria).
 - A foto só muda se você editar o arquivo e rodar o script de novo.

 É seguro rodar mais de uma vez: comando que já está embutido (já
 começa com "data:") é pulado automaticamente. Comando que falhar
 (ex: link quebrado) fica como estava, sem quebrar nada — você pode
 trocar o link dele manualmente e rodar o script de novo depois.
*/
const fs = require('fs')
const path = require('path')
const { imagemDeLink } = require('../arquivos/js/brincadeirasHelpers.js')

const PASTA = path.join(__dirname, '../plugins/brincadeiras')
const RE_LINK_FOTO = /const LINK_FOTO = '((?:https?:)[^']+)'/

function sleep(ms) { return new Promise(r => setTimeout(r, ms)) }

async function processarArquivo(nomeArquivo) {
  const caminho = path.join(PASTA, nomeArquivo)
  const conteudo = fs.readFileSync(caminho, 'utf-8')
  const match = conteudo.match(RE_LINK_FOTO)
  if (!match) return { nomeArquivo, status: 'sem LINK_FOTO (ignorado)' }

  const link = match[1]
  process.stdout.write(`🔎 ${nomeArquivo} — baixando ${link} ... `)
  let buffer
  try {
    buffer = await imagemDeLink(link)
  } catch (e) {
    console.log('❌ erro:', e?.message)
    return { nomeArquivo, status: 'falhou: ' + e?.message }
  }
  if (!buffer || buffer.length < 500) {
    console.log('❌ não baixou (link pode estar quebrado)')
    return { nomeArquivo, status: 'falhou: imagem vazia/curta' }
  }

  const base64 = buffer.toString('base64')
  const dataUri = `data:image/jpeg;base64,${base64}`
  const novoConteudo = conteudo.replace(
    RE_LINK_FOTO,
    `// Link original (guardado só de referência, pode trocar e rodar o script de novo): ${link}\nconst LINK_FOTO = '${dataUri}'`
  )
  fs.writeFileSync(caminho, novoConteudo, 'utf-8')
  console.log(`✅ embutida (${(buffer.length / 1024).toFixed(0)} KB)`)
  return { nomeArquivo, status: 'ok' }
}

async function main() {
  const arquivos = fs.readdirSync(PASTA).filter(f => f.endsWith('.js'))
  console.log(`💜 Embutindo fotos de ${arquivos.length} comandos de brincadeiras...\n`)

  const resultados = []
  for (const arquivo of arquivos) {
    const conteudo = fs.readFileSync(path.join(PASTA, arquivo), 'utf-8')
    if (/const LINK_FOTO = 'data:/.test(conteudo)) {
      resultados.push({ nomeArquivo: arquivo, status: 'já embutida (pulado)' })
      continue
    }
    resultados.push(await processarArquivo(arquivo))
    await sleep(400) // não martela o Pinterest
  }

  const ok = resultados.filter(r => r.status === 'ok').length
  const pulados = resultados.filter(r => r.status.includes('pulado') || r.status.includes('ignorado')).length
  const falhas = resultados.filter(r => r.status.startsWith('falhou'))

  console.log(`\n💜 Pronto! ${ok} fotos embutidas agora, ${pulados} já estavam prontas/não se aplicam.`)
  if (falhas.length) {
    console.log(`\n⚠️ ${falhas.length} não deram certo (o comando continua funcionando pelo link normal até você tentar de novo):`)
    falhas.forEach(f => console.log(`   - ${f.nomeArquivo}: ${f.status}`))
    console.log('\nPode rodar "node tools/embutir_fotos.js" de novo quando quiser — só tenta de novo quem falhou/ainda não foi.')
  }
}

main()
