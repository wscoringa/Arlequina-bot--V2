const { criarEfeitoSirv } = require('../../arquivos/js/efeitosLogo.js')

module.exports = criarEfeitoSirv({
  name: 'dragonred',
  urlTemplate: 'https://lollityp.sirv.com/venom_apis16.jpg?text.0.text={TEXTO}&text.0.position.gravity=north&text.0.position.y=58%25&text.0.size=99&text.0.color=fffefe&text.0.font.family=Permanent%20Marker&text.0.background.color=000000&text.0.outline.color=000000&text.0.outline.width=19&text.0.outline.blur=66'
})
