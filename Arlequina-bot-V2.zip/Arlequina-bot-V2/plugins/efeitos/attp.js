/*
 Comando: attp (aliases: rainbowtext, textoanimado)
 Gera uma figurinha animada de texto colorido (efeito "ATTP" clássico).

 BUGFIX: antes dependia de uma API de terceiro (systemzone.store) que
 parou de responder direito (dava erro/404). Agora gera tudo LOCALMENTE
 com ffmpeg (que já vem instalado no bot) — nunca mais vai cair por
 causa de site de terceiro fora do ar.
*/
const fs = require('fs')
const path = require('path')
const os = require('os')
const crypto = require('crypto')
const { execFile } = require('child_process')
const { sendVideoAsSticker2 } = require('../../arquivos/js/exif2.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

const FONTE = fs.existsSync('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf')
  ? '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
  : null

const CORES = ['red', 'orange', 'yellow', 'green', 'blue', 'purple', 'magenta']
const DURACAO_TOTAL = 2.4

// Escapa caracteres que o drawtext do ffmpeg trata como especiais
function escaparTextoFfmpeg(txt) {
  return txt.replace(/\\/g, '\\\\\\\\').replace(/'/g, "\u2019").replace(/:/g, '\\:').replace(/%/g, '\\%')
}

function rodarFfmpeg(args) {
  return new Promise((resolve, reject) => {
    execFile('ffmpeg', args, { timeout: 30000 }, (err, stdout, stderr) => {
      if (err) return reject(new Error(stderr?.slice(-500) || err.message))
      resolve()
    })
  })
}

module.exports = {
  name: 'attp',
  description: '🌈 Cria uma figurinha de texto animado colorido',
  category: 'efeitos',
  aliases: ['rainbowtext', 'textoanimado'],
  async execute({ arlequina, from, info, q, args, reply, reagir, prefix }) {
    const texto = (q || args.join(' ')).trim().slice(0, 25)

    if (!texto) {
      return reply(caixaArlequina('attp', `🌈 Como usar:\n${prefix}attp <texto>\n\nEx: ${prefix}attp Arlequina Bot`))
    }

    if (!FONTE) {
      return reply('❌ Não achei uma fonte instalada no servidor pra gerar o texto. Avisa quem cuida do servidor.')
    }

    const tmpDir = os.tmpdir()
    const arquivoMp4 = path.join(tmpDir, `attp_${crypto.randomBytes(6).toString('hex')}.mp4`)

    try {
      await reagir('🌈')

      const textoEscapado = escaparTextoFfmpeg(texto)
      const fatia = DURACAO_TOTAL / CORES.length
      const filtros = CORES.map((cor, i) => {
        const t1 = (i * fatia).toFixed(3)
        const t2 = ((i + 1) * fatia).toFixed(3)
        return `drawtext=text='${textoEscapado}':fontfile=${FONTE}:fontsize=42:x=(w-text_w)/2:y=(h-text_h)/2:fontcolor=${cor}:enable='between(t,${t1},${t2})'`
      }).join(',')

      await rodarFfmpeg([
        '-y', '-f', 'lavfi', '-i', `color=size=300x300:color=black:duration=${DURACAO_TOTAL}`,
        '-vf', filtros,
        '-r', '12', '-pix_fmt', 'yuv420p', arquivoMp4
      ])

      const buffer = fs.readFileSync(arquivoMp4)
      await sendVideoAsSticker2(arlequina, from, buffer, info, { packname: '🃏 Arlequina Bot', author: '💜 Coringa', categories: ['🌈'] })
    } catch (e) {
      console.log('❌ ERRO attp:', e?.message)
      await reply('❌ Não consegui gerar a figurinha agora. Tenta de novo.')
    } finally {
      if (fs.existsSync(arquivoMp4)) fs.unlinkSync(arquivoMp4)
    }
  }
}
