const { criarEditImagem, criarEditVideo, listarEfeitosDisponiveis } = require('../../arquivos/js/edicaoHelper.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'edit',
description: "🎬 Transforma a foto/vídeo respondido numa 'edição' com efeito (fogo, explosão, gelo, neon, sombrio) e legenda",
category: 'efeitos',
aliases: ['editar', 'animar', 'edicao'],
async execute({ arlequina, from, info, args, q, reply, reagir, getFileBuffer, prefix }) {

try {
  const quoted = info.message?.extendedTextMessage?.contextInfo?.quotedMessage
  if (!quoted) {
    return reply(
`${caixaArlequina("edit", `🎬 *Como usar:*
Responda uma *foto* ou *vídeo* com *${prefix}edit*

🔥 *Efeitos disponíveis:* ${listarEfeitosDisponiveis()}

💡 Exemplos:
*${prefix}edit fogo* → aplica o efeito de fogo
*${prefix}edit 10 fogo* → efeito de fogo, vídeo de 10 segundos
*${prefix}edit explosão feliz aniversário* → efeito de explosão + essa legenda
*${prefix}edit Voando alto* → sem efeito, só a legenda

⚠️ Isso aplica efeitos de verdade (cor, flash, brilho) — não gera vídeo novo a partir do texto, isso precisaria de uma IA de geração de vídeo que não está disponível aqui.`)}`
    )
  }

  const isImg = !!quoted.imageMessage
  const isVid = !!quoted.videoMessage
  if (!isImg && !isVid) return reply('❌ Responda uma *foto* ou *vídeo* com ${prefix}edit')

  // Primeiro argumento numérico = duração em segundos. O resto do texto =
  // efeito (se reconhecido) + legenda.
  let duracao = null
  let textoDigitado = q || ''
  if (args.length && /^\d+(\.\d+)?$/.test(args[0])) {
    duracao = parseFloat(args[0])
    textoDigitado = args.slice(1).join(' ')
  }

  await reagir('🎬')
  await reply('⏳ Montando a edição, aguenta aí...')

  const buffer = await getFileBuffer(
    isVid ? quoted.videoMessage : quoted.imageMessage,
    isVid ? 'video' : 'image'
  )

  const resultado = isVid
    ? await criarEditVideo(buffer, duracao, textoDigitado)
    : await criarEditImagem(buffer, duracao, textoDigitado)

  const legendaFinal = resultado.efeitoAplicado
    ? `${resultado.emoji} Edit com efeito de *${resultado.efeitoAplicado}* pronto! 🃏💜`
    : '🎬 Edit pronto! 🃏💜'

  await arlequina.sendMessage(from, {
    video: resultado.buffer,
    caption: legendaFinal
  }, { quoted: info })

  await reagir('✅')
} catch (e) {
  console.error('ERRO edit:', e?.message)
  await reply('❌ Não consegui montar a edição agora. Tenta com outra foto/vídeo.')
}

}
}
