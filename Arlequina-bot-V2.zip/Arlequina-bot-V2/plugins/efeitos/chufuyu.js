const { criarEfeitoSirv } = require('../../arquivos/js/efeitosLogo.js')

module.exports = criarEfeitoSirv({
  name: 'chufuyu',
  urlTemplate: 'https://lollityp.sirv.com/venom_apis14.jpg?text.0.text={TEXTO}&text.0.position.gravity=north&text.0.position.y=68%25&text.0.size=60&text.0.color=ffffff&text.0.font.family=Sigmar%20One&text.0.font.style=italic&text.0.background.opacity=17&text.0.outline.color=a99cff&text.0.outline.width=9&text.0.outline.blur=16'
})
