const { criarEfeitoSirv } = require('../../arquivos/js/efeitosLogo.js')

module.exports = criarEfeitoSirv({
  name: 'cria',
  urlTemplate: 'https://lollityp.sirv.com/venom_api.jpg?text.0.text={TEXTO}&text.0.color=000000&text.0.font.family=Pacifico&text.0.font.weight=600&text.0.background.color=ffffff&text.0.outline.color=ffffff&text.0.outline.width=10&text.0.outline.blur=17'
})
