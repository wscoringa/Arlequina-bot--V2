const { criarEfeitoSirv } = require('../../arquivos/js/efeitosLogo.js')

module.exports = criarEfeitoSirv({
  name: 'anime2',
  urlTemplate: 'https://lollityp.sirv.com/venom_apis7.jpg?text.0.text={TEXTO}&text.0.position.gravity=north&text.0.position.x=1%25&text.0.position.y=58%25&text.0.size=69&text.0.color=00ffea&text.0.opacity=37&text.0.font.family=Bangers&text.0.background.opacity=77&text.0.outline.color=ffffff&text.0.outline.width=2&text.0.outline.blur=20'
})
