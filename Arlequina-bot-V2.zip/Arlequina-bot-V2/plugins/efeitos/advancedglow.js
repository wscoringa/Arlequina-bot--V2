const { criarEfeitoNexfuture } = require('../../arquivos/js/efeitosLogo.js')

module.exports = criarEfeitoNexfuture({ name: 'advancedglow' })
