const { criarEfeitoSirv } = require('../../arquivos/js/efeitosLogo.js')

module.exports = criarEfeitoSirv({
  name: 'anime1',
  urlTemplate: 'https://lollityp.sirv.com/venom_apis2.jpg?text.0.text={TEXTO}&text.0.position.gravity=center&text.0.position.x=1%25&text.0.position.y=16%25&text.0.size=80&text.0.color=ff2772&text.0.opacity=67&text.0.font.family=Bangers&text.0.font.style=italic&text.0.background.opacity=50&text.0.outline.width=6'
})
