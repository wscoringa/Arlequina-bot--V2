/*
 Comando: brat
 Gera a capa estilo "Brat" (fundo verde limão, texto preto minúsculo
 borrado, referência ao álbum da Charli XCX) como figurinha.
 Uso: !brat texto aqui
*/
const sharp = require('sharp')
const { sendImageAsSticker2 } = require('../../arquivos/js/exif2.js')
const { metaFigurinha } = require('../../arquivos/js/stickerMeta.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

function escaparSvg(txt) {
  return txt.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
}

module.exports = {
  name: 'brat',
  description: '🍏 Gera a capa estilo "Brat" (fundo verde, texto minúsculo) como figurinha',
  category: 'efeitos',
  aliases: [],
  async execute({ arlequina, from, info, q, args, reply, reagir, prefix, pushname, sender, groupName, config }) {
    const texto = (q || args.join(' ')).trim().toLowerCase()
    if (!texto) return reply(caixaArlequina('brat', `❌ Cadê o texto?\n💡 Ex: *${prefix}brat* arlequina`))

    try {
      await reagir('🍏')

      const tamanho = 512
      // Quebra o texto em linhas curtas, tipo a capa original
      const palavras = texto.split(' ')
      const linhas = []
      let linhaAtual = ''
      for (const palavra of palavras) {
        const teste = linhaAtual ? `${linhaAtual} ${palavra}` : palavra
        if (teste.length > 12 && linhaAtual) {
          linhas.push(linhaAtual)
          linhaAtual = palavra
        } else {
          linhaAtual = teste
        }
      }
      if (linhaAtual) linhas.push(linhaAtual)

      const tamanhoFonte = linhas.length > 3 ? 42 : 56
      const alturaLinha = tamanhoFonte * 1.15
      const alturaTotalTexto = linhas.length * alturaLinha
      const yInicial = (tamanho - alturaTotalTexto) / 2 + tamanhoFonte

      const linhasSvg = linhas.map((linha, i) =>
        `<text x="50%" y="${yInicial + i * alturaLinha}" text-anchor="middle" font-family="Arial, sans-serif" font-size="${tamanhoFonte}" fill="#000000" filter="url(#borrado)">${escaparSvg(linha)}</text>`
      ).join('\n')

      const svg = `
        <svg width="${tamanho}" height="${tamanho}">
          <defs>
            <filter id="borrado"><feGaussianBlur stdDeviation="0.6"/></filter>
          </defs>
          <rect width="100%" height="100%" fill="#8ACE00"/>
          ${linhasSvg}
        </svg>`

      const buffer = await sharp(Buffer.from(svg)).png().toBuffer()
      await sendImageAsSticker2(arlequina, from, buffer, info, metaFigurinha({ pushname, sender, groupName, config }))
    } catch (e) {
      console.log('❌ ERRO brat:', e?.message)
      await reply('❌ Não consegui gerar a capa Brat agora.')
    }
  }
}
