/*
 Comando: emojimix
 Combina dois emojis numa figurinha (efeito "Emoji Kitchen" do Google).
 Uso: !emojimix 😀/😭
*/
const axios = require('axios')
const { sendImageAsSticker2 } = require('../../arquivos/js/exif2.js')
const { metaFigurinha } = require('../../arquivos/js/stickerMeta.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

function paraCodepoint(emoji) {
  return [...emoji].map(c => c.codePointAt(0).toString(16)).join('-')
}

module.exports = {
  name: 'emojimix',
  description: '🎨 Combina dois emojis numa figurinha (ex: 😀/😭)',
  category: 'efeitos',
  aliases: ['mixemoji'],
  async execute({ arlequina, from, info, q, args, reply, reagir, prefix, pushname, sender, groupName, config }) {
    const texto = (q || args.join(' ')).trim()
    const [emoji1, emoji2] = texto.split('/').map(e => e?.trim())
    if (!emoji1 || !emoji2) {
      return reply(caixaArlequina('emojimix', `❌ Formato errado.\n💡 Ex: *${prefix}emojimix* 😀/😭`))
    }

    try {
      await reagir('🎨')
      // API pública do Tenor (Emoji Kitchen) — chave de demonstração oficial do Google
      const chave = 'AIzaSyAyimkuYQYF_FXVALexPuGQctUWRURdCYQ'
      const busca = `${paraCodepoint(emoji1)}_${paraCodepoint(emoji2)}`
      const url = `https://tenor.googleapis.com/v2/featured?key=${chave}&contentfilter=high&media_filter=png_transparent&component=proactive&collection=emoji_kitchen_v6&q=${busca}`
      const { data } = await axios.get(url, { timeout: 15000 })

      const imagemUrl = data?.results?.[0]?.media_formats?.png_transparent?.url
      if (!imagemUrl) {
        return reply(caixaArlequina('emojimix', `❌ Essa combinação de emoji não existe. Tenta outra dupla.`))
      }

      const { data: imgData } = await axios.get(imagemUrl, { responseType: 'arraybuffer', timeout: 15000 })
      await sendImageAsSticker2(arlequina, from, Buffer.from(imgData), info, metaFigurinha({ pushname, sender, groupName, config }))
    } catch (e) {
      console.log('❌ ERRO emojimix:', e?.message)
      await reply('❌ Não consegui misturar esses emojis agora.')
    }
  }
}
