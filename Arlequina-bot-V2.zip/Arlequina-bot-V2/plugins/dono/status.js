/*
 Convertido automaticamente do connect.js (bot antigo monolitico) para
 o sistema de plugins da Arlequina Bot. Comando original: status
*/
const donoState = require('../../arquivos/js/donoState.js')
const adminState = require('../../arquivos/js/adminState.js')
const fs = require('fs')
const { dbPath } = require('../../arquivos/js/rpgDB.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'status',
description: "Mostra o status completo do bot",
category: 'dono',
aliases: [],
async execute({ isDono, arlequina, from, info, args, q, reply, reagir, prefix, sender, pushname, isGroup, donoJid, commandManager, config }) {
if (!isDono()) return reply('❌ Este comando é exclusivo do dono do bot!')


const sock = arlequina
const msg = info
const jid = sender
const jidReal = sender
const numeroReal = String(sender || '').split('@')[0]
const isGrupo = isGroup
const nome = pushname
const texto = q || args.join(' ')

const enviar = async (conteudo, _opcoes) => {
if (typeof conteudo === 'string') return reply(conteudo)
try {
return await sock.sendMessage(from, conteudo, { quoted: info })
} catch (e) {
const fallback = conteudo?.caption || conteudo?.text || '✅'
return reply(fallback)
}
}

try {
  const uptimeMs = process.uptime() * 1000
  const horas = Math.floor(uptimeMs / 3600000)
  const minutos = Math.floor((uptimeMs % 3600000) / 60000)
  const segundos = Math.floor((uptimeMs % 60000) / 1000)
  
  const grupos = await sock.groupFetchAllParticipating()
  const totalGrupos = Object.keys(grupos).length
  const totalUsuarios = Object.keys(usuarios).length
  
  await reply(`
  ╭─━━─🃏💜「 🤡 STATUS DO BOT 」💜🃏─━━─╮
  
  🔌 Ligado: ${donoState.botStatus.ligado ? '✅ Sim' : '❌ Não'}
  🛠️ Manutenção: ${donoState.botStatus.manutencao ? '✅ Ativada' : '❌ Desativada'}
  💬 Privado: ${donoState.botStatus.privadoOn ? '✅ Ativo' : '❌ Pausado'}
  
  ⏳ Online há: ${horas}h ${minutos}m ${segundos}s
  
  👥 Grupos: ${totalGrupos}
  🧑 Usuários registrados: ${totalUsuarios}
  
  🏠 Grupos no aluguel: ${Object.keys(donoState.aluguel.grupos).length}
  
  ╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯
  `)
} catch (e) {
console.log('❌ ERRO DONO (status):', e?.message)
await reply(caixaArlequina("status", `❌ Não consegui executar esse comando.`))
}

}
}
