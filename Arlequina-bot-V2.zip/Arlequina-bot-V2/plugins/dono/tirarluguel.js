/*
 Comando: tirarluguel
 Remove dias da validade do aluguel do grupo atual (ou cancela tudo
 se não sobrar dias / não passar número).
 Uso:
   !tirarluguel <dias>  -> tira X dias da validade
   !tirarluguel         -> cancela o aluguel agora mesmo
 Apenas o dono do bot pode usar.
*/
const donoState = require('../../arquivos/js/donoState.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

function formatarData(timestamp) {
const d = new Date(timestamp)
return d.toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' })
}

module.exports = {
name: 'tirarluguel',
description: "Tira dias do aluguel do grupo, ou cancela tudo",
category: 'dono',
aliases: ['tiraraluguel', 'removeraluguel', 'cancelaraluguel'],
async execute({ from, info, args, reply, reagir, prefix, isGroup, isDono, groupName }) {

try {
  if (!isDono()) return reply(caixaArlequina("tirarluguel", `❌ Apenas o dono pode usar este comando!`))
  if (!isGroup) return reply('❌ Use esse comando dentro do grupo que vai ter o aluguel removido.')

  const data = donoState.aluguel.grupos[from]

  if (!data || !data.ativo) {
    return reply(`╭─━━─🃏💜「 🃏💜 *ARLEQUINA BOT* 💜🃏 」💜🃏─━━─╮
┃ ⚠️ Esse grupo já não tem aluguel ativo.
╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯
💜🃏 _Arlequina Bot_ 😈`)
  }

  const diasTirar = Number(args[0])
  await reagir('🃏')

  // Sem número = cancela o aluguel agora
  if (!args[0] || isNaN(diasTirar) || diasTirar <= 0) {
    data.ativo = false
    donoState.salvar()
    return reply(`╭─━━─🃏💜「 🃏💜 *ARLEQUINA BOT* 💜🃏 」💜🃏─━━─╮
┃ ❌ *ALUGUEL CANCELADO*
┃ 🏠 *Grupo:* ${groupName || 'Este grupo'}
╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯
💜🃏 _Arlequina Bot_ 😈`)
  }

  // Com número = tira X dias da validade
  const msPorDia = 24 * 60 * 60 * 1000
  const fimAtual = data.fim || Date.now()
  const novoFim = fimAtual - diasTirar * msPorDia

  if (novoFim <= Date.now()) {
    data.ativo = false
    data.fim = Date.now()
    donoState.salvar()
    return reply(`╭─━━─🃏💜「 🃏💜 *ARLEQUINA BOT* 💜🃏 」💜🃏─━━─╮
┃ ❌ *ALUGUEL EXPIROU*
┃ 🏠 *Grupo:* ${groupName || 'Este grupo'}
┃ Tirou ${diasTirar} dia(s) e zerou a validade.
╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯
💜🃏 _Arlequina Bot_ 😈`)
  }

  data.fim = novoFim
  donoState.salvar()

  return reply(`╭─━━─🃏💜「 🃏💜 *ARLEQUINA BOT* 💜🃏 」💜🃏─━━─╮
┃ ✅ *${diasTirar} DIA(S) REMOVIDO(S)*
┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━⬣
┃ 🏠 *Grupo:* ${groupName || 'Este grupo'}
┃ 📅 *Nova validade:* ${formatarData(novoFim)}
╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯
💜🃏 _Arlequina Bot_ 😈`)
} catch (e) {
console.log('❌ ERRO (tirarluguel):', e?.message)
await reply('❌ Não consegui executar esse comando agora.')
}

}
}
