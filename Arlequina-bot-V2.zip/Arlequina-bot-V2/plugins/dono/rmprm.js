/*
 Comando: rmprm (aliases: rmprem, delprm, removeprm)
 Tira o premium de alguém (responda/marque a pessoa).
*/
const { existsLidData, userLid } = require('../../arquivos/js/userManager.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
  name: 'rmprm',
  description: '💎 Remove o premium de alguém',
  category: 'dono',
  aliases: ['rmprem', 'delprm', 'removeprm'],
  async execute({ from, info, reply, reagir, isDono, commandManager, prefix, groupMembers, isGroup }) {
    // BUGFIX SEGURANÇA: isDono chega como FUNÇÃO, tem que chamar isDono().
    if (!isDono()) {
      await reagir('❌')
      return reply('❌ Apenas o dono pode usar este comando!')
    }

    const quoted = info.message?.extendedTextMessage?.contextInfo
    const target = quoted?.participant || quoted?.mentionedJid?.[0]

    if (!target) {
      return reply(caixaArlequina('rmprm', `💎 Como usar:\n${prefix}rmprm @pessoa\n\n(marque/responda a pessoa)`))
    }

    const pegarPhoneNumberReal = (input) => {
      if (!input) return null
      if (input.match(/^\d+$/) && !input.includes('@')) return `${input}@s.whatsapp.net`
      if (input.includes('@s.whatsapp.net') && input.match(/^\d{10,15}@/)) return input

      const lidLimpo = input.replace('@lid', '').split(':')[0]
      if (isGroup && groupMembers?.length) {
        const membro = groupMembers.find(m => m.id === input || m.id === lidLimpo + '@lid' || m.id === lidLimpo)
        if (membro?.phoneNumber) return membro.phoneNumber
      }
      const lidCompleto = lidLimpo + '@lid'
      if (existsLidData(lidCompleto)) {
        const dados = userLid(lidCompleto)
        if (dados?.jid?.match(/^\d{10,15}@s\.whatsapp\.net$/)) return dados.jid
      }
      return null
    }

    const phoneReal = pegarPhoneNumberReal(target)
    if (!phoneReal) {
      await reagir('❌')
      return reply('❌ Não consegui identificar o número dessa pessoa.')
    }

    const success = commandManager.removePremium(phoneReal)
    if (success) {
      await reagir('✅')
      await reply(caixaArlequina('rmprm', `✅ Premium removido de ${phoneReal.split('@')[0]}.`))
    } else {
      await reagir('❌')
      await reply('❌ Essa pessoa não tinha premium.')
    }
  }
}
