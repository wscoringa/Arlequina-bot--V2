/*
 Comando: tirarxp (dono)
 #tirarxp <quantidade>            -> remove XP de você mesmo (dono)
 #tirarxp <quantidade> @usuario   -> remove XP do usuário marcado
 (marcando/respondendo também funciona sem precisar digitar @)
*/
const { carregarUsuarios, salvarUsuarios, getUsuario } = require('../../arquivos/js/rpgDB.js')
const { convertWhatsAppUser } = require('../../arquivos/js/userManager.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'tirarxp',
description: 'Remove XP de você (dono) ou de um usuário marcado',
category: 'dono',
aliases: ['removerxp', 'delxp'],
async execute({ isDono, arlequina, columbina, from, info, args, reply, reagir, sender, prefix }) {
if (!isDono()) return reply('❌ Este comando é exclusivo do dono do bot!')

const sock = arlequina || columbina

const quoted = info.message?.extendedTextMessage?.contextInfo
const mencionado = quoted?.participant || quoted?.mentionedJid?.[0]
const alvo = mencionado ? convertWhatsAppUser(mencionado, 'jid') : sender

const quantidade = parseInt((args.find(a => /^\d+$/.test(a)) || ''))
if (!quantidade || quantidade <= 0) {
return reply(`${caixaArlequina("tirarxp", `❗ Use: *${prefix}tirarxp <quantidade>*\nEx: ${prefix}tirarxp 500\n\nOu marcando alguém: *${prefix}tirarxp 500 @usuario*`)}`)
}

try {
  const usuarios = carregarUsuarios()
  const u = getUsuario(usuarios, alvo)
  u.xp = Math.max(0, u.xp - quantidade)

  salvarUsuarios(usuarios)

  await reagir('📉')

  const quemMsg = mencionado ? `@${alvo.split('@')[0]}` : 'você'
  const texto = `╭─━━─🃏💜「 📉💜 *TIRAR XP* 💜📉 」💜🃏─━━─╮\n┃ -${quantidade} XP de ${quemMsg}\n┃ 📊 XP atual: ${u.xp}/${u.level * 500}\n┃ 🏅 Level: ${u.level}\n╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯\n💜🃏 _Castigo aplicado... 😈_`

  await sock.sendMessage(from, { text: texto, mentions: mencionado ? [alvo] : [] }, { quoted: info })
} catch (e) {
  console.log('❌ ERRO tirarxp:', e?.message)
  await reply('❌ Não consegui remover o XP agora.')
}
}
}
