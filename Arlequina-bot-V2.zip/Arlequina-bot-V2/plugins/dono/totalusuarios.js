/*
 Convertido automaticamente do connect.js (bot antigo monolitico) para
 o sistema de plugins da Arlequina Bot. Comando original: totalusuarios
*/
const { carregarUsuarios, salvarUsuarios, getUsuario } = require('../../arquivos/js/rpgDB.js')
const adminState = require('../../arquivos/js/adminState.js')
const donoState = require('../../arquivos/js/donoState.js')
const { imagemDaBrincadeira, buscarImagemAleatoria } = require('../../arquivos/js/brincadeirasHelpers.js')
const fs = require('fs')
const axios = require('axios')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'totalusuarios',
description: "Mostra o total de usuários registrados",
category: 'dono',
aliases: [],
async execute({ isDono, arlequina, from, info, args, q, reply, reagir, prefix, sender, pushname, isGroup, donoJid, commandManager, config, getFileBuffer, sleep, fetchJson }) {
if (!isDono()) return reply('❌ Este comando é exclusivo do dono do bot!')


const sock = arlequina
const msg = info
const jid = sender
const jidReal = sender
const numeroReal = String(sender || '').split('@')[0]
const isGrupo = isGroup
const nome = pushname
const texto = q || args.join(' ')
const baixarMidia = (mediaMsg, tipo) => getFileBuffer(mediaMsg, tipo)

const ehDono = (jidAlvo, numeroAlvo) => {
const donoNum = String(donoJid || '').replace(/[^0-9]/g, '')
const num = String(numeroAlvo || '').replace(/[^0-9]/g, '')
return (donoNum && num === donoNum) || jidAlvo === donoJid
}

const usuarios = carregarUsuarios()
getUsuario(usuarios, sender)

const enviar = async (conteudo, _opcoes) => {
if (typeof conteudo === 'string') return reply(conteudo)
try {
return await sock.sendMessage(from, conteudo, { quoted: info })
} catch (e) {
const fallback = conteudo?.caption || conteudo?.text || '✅'
return reply(fallback)
}
}

try {
  const total = Object.keys(usuarios).length
  
  const totalOuro = Object.values(usuarios)
  .reduce((acc, u) => acc + (u.ouro || 0), 0)
  
  const totalSaldo = Object.values(usuarios)
  .reduce((acc, u) => acc + (u.saldo || 0) + (u.banco || 0), 0)
  
  await reply(`
  ╭─━━─🃏💜「 📊 ESTATÍSTICAS GERAIS 」💜🃏─━━─╮
  
  🧑 Usuários registrados: ${total}
  🪙 Ouro total em circulação: ${totalOuro}
  💵 Saldo+Banco total: ${totalSaldo}
  
  ╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯
  `)
} catch (e) {
console.log('❌ ERRO (totalusuarios):', e?.message)
await reply(caixaArlequina("totalusuarios", `❌ Não consegui executar esse comando agora.`))
} finally {
salvarUsuarios(usuarios)
}

}
}
