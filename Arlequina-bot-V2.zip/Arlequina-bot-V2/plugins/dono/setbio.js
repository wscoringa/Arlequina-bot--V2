/*
 Convertido automaticamente do connect.js (bot antigo monolitico) para
 o sistema de plugins da Arlequina Bot. Comando original: setbio, setrecado
*/
const donoState = require('../../arquivos/js/donoState.js')
const adminState = require('../../arquivos/js/adminState.js')
const fs = require('fs')
const { dbPath } = require('../../arquivos/js/rpgDB.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'setbio',
description: "Muda a bio/recado do bot no WhatsApp",
category: 'dono',
aliases: ["setrecado"],
async execute({ isDono, arlequina, from, info, args, q, reply, reagir, prefix, sender, pushname, isGroup, donoJid, commandManager, config }) {
if (!isDono()) return reply('❌ Este comando é exclusivo do dono do bot!')


const sock = arlequina
const msg = info
const jid = sender
const jidReal = sender
const numeroReal = String(sender || '').split('@')[0]
const isGrupo = isGroup
const nome = pushname
const texto = q || args.join(' ')

const enviar = async (conteudo, _opcoes) => {
if (typeof conteudo === 'string') return reply(conteudo)
try {
return await sock.sendMessage(from, conteudo, { quoted: info })
} catch (e) {
const fallback = conteudo?.caption || conteudo?.text || '✅'
return reply(fallback)
}
}

try {
  const novaBio = args.join(' ')
  
  if (!novaBio)
  return reply('❌ Digite a nova bio/recado.\n\nEx: !setbio 🤡 Arlequina Bot online!')
  
  try {
  await sock.updateProfileStatus(novaBio)
  await reply(`${caixaArlequina("setbio", `✅ Recado do bot alterado para:\n${novaBio}`)}`)
  } catch (e) {
  console.log(e)
  await reply('❌ Erro ao alterar o recado do bot.')
  }
} catch (e) {
console.log('❌ ERRO DONO (setbio):', e?.message)
await reply('❌ Não consegui executar esse comando.')
}

}
}
