/*
 !so_adm / !soadm on/off (só dono)
 Enquanto ligado NESSE GRUPO, só o dono do bot e os ADMINS desse grupo
 conseguem usar comandos aqui dentro. Outros grupos continuam normais —
 é por grupo, não afeta o bot inteiro. Todo mundo mais é ignorado em silêncio.
*/
const donoState = require('../../arquivos/js/donoState.js')

module.exports = {
  name: 'soadm',
  description: 'Liga/desliga o modo "só admin/dono usa o bot" NESSE grupo (só dono)',
  category: 'dono',
  aliases: ['so_adm'],

  async execute({ reply, reagir, args, isDono, isGroup, from }) {
    try {
      if (!isDono()) return reply('❌ Apenas o dono pode usar esse comando!')
      if (!isGroup) return reply('❌ Esse comando só funciona dentro de um grupo (ele ativa só pro grupo atual).')

      const ativoAqui = !!donoState.botStatus.soAdmGrupos[from]
      const modo = (args[0] || '').toLowerCase()

      if (!['on', 'off', '1', '0', 'ligar', 'desligar'].includes(modo)) {
        return reply(`🃏💜 *SÓ ADMIN (nesse grupo)* 💜🃏\n\nStatus aqui: *${ativoAqui ? 'Ligado ✅' : 'Desligado ❌'}*\n\n*!soadm on* — Só dono e admins usam o bot NESSE grupo\n*!soadm off* — Volta ao normal NESSE grupo`)
      }

      const ligar = modo === 'on' || modo === '1' || modo === 'ligar'

      if (ligar && ativoAqui) return reply('🛡️ O modo "só admin" já está ligado nesse grupo, senhor(a)!')
      if (!ligar && !ativoAqui) return reply('🔓 O modo "só admin" já está desligado nesse grupo, senhor(a)!')

      if (ligar) donoState.botStatus.soAdmGrupos[from] = true
      else delete donoState.botStatus.soAdmGrupos[from]
      donoState.salvar()

      await reagir(ligar ? '🛡️' : '🔓')

      return reply(ligar
        ? `🛡️💜 *MODO SÓ ADMIN ATIVADO NESSE GRUPO* 💜🛡️\n\n🚫 Só o dono e os admins desse grupo conseguem usar meus comandos aqui.\nOutros grupos continuam normais.\n\nPra desligar: *!soadm off*`
        : `🔓💜 *MODO SÓ ADMIN DESATIVADO NESSE GRUPO* 💜🔓\n\n✅ Todo mundo já pode voltar a usar meus comandos aqui.`)

    } catch (e) {
      console.log('❌ ERRO DONO (soadm):', e?.message)
      await reply('❌ Não consegui executar esse comando agora.')
    }
  }
}
