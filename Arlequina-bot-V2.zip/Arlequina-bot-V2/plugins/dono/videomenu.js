const fs = require('fs')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')
const donoState = require('../../arquivos/js/donoState.js')

// Desembrulha camadas que o WhatsApp/Baileys usam pra "empacotar" a
// mensagem de verdade: mensagem temporária (grupo com "mensagens
// temporárias" ativado) e view-once. Mesmo padrão usado no comando de
// figurinha (plugins/cmds-aleatorios/sticker.js). Sem isso, um
// vídeo/gif mandado num grupo assim "sumia" pro comando.
function desembrulhar(msg) {
  let atual = msg
  let seguranca = 0
  while (atual && seguranca < 5) {
    if (atual.ephemeralMessage?.message) { atual = atual.ephemeralMessage.message; seguranca++; continue }
    if (atual.viewOnceMessageV2?.message) { atual = atual.viewOnceMessageV2.message; seguranca++; continue }
    if (atual.viewOnceMessageV2Extension?.message) { atual = atual.viewOnceMessageV2Extension.message; seguranca++; continue }
    if (atual.viewOnceMessage?.message) { atual = atual.viewOnceMessage.message; seguranca++; continue }
    if (atual.documentWithCaptionMessage?.message) { atual = atual.documentWithCaptionMessage.message; seguranca++; continue }
    break
  }
  return atual || {}
}

module.exports = {
  name: 'videomenu',
  description: 'Troca o vídeo/gif exibido no menu principal (somente dono)',
  category: 'dono',
  aliases: ['gifmenu'],
  async execute({ isDono, arlequina, from, info, reply, getFileBuffer, prefix }) {
  if (!isDono()) return reply('❌ Este comando é exclusivo do dono do bot!')

    try {
      const quotedMsg = desembrulhar(info.message?.extendedTextMessage?.contextInfo?.quotedMessage)
      const mensagemAtual = desembrulhar(info.message)

      const videoQuoted = quotedMsg?.videoMessage
      const videoDireto = mensagemAtual?.videoMessage
      const videoMsg = videoQuoted || videoDireto

      // Alguns apps mandam o gif/vídeo "disfarçado" de documento (pra
      // não perder qualidade). Se o mimetype for video/* ou image/gif,
      // trata como se fosse a mídia normal.
      const documentoQuoted = quotedMsg?.documentMessage
      const documentoDireto = mensagemAtual?.documentMessage
      const docFinal =
        (documentoQuoted?.mimetype?.startsWith('video/') || documentoQuoted?.mimetype === 'image/gif') ? documentoQuoted
        : (documentoDireto?.mimetype?.startsWith('video/') || documentoDireto?.mimetype === 'image/gif') ? documentoDireto
        : null

      if (!videoMsg && !docFinal) {
        return reply(caixaArlequina("videomenu", `❌ Envie ou marque um vídeo ou GIF junto com o comando.\n\nEx: marque um vídeo/gif e mande ${prefix}videomenu`))
      }

      // Um GIF mandado pelo WhatsApp chega, por baixo dos panos, como um
      // vídeo comum com a flag "gifPlayback" ligada. Documento com
      // mimetype image/gif também conta como gif.
      const ehGif = !!(videoMsg?.gifPlayback) || (docFinal?.mimetype === 'image/gif')
      const tipoDownload = docFinal ? 'document' : 'video'
      const midiaAlvo = docFinal || videoMsg

      const buffer = await getFileBuffer(midiaAlvo, tipoDownload)

      // Salva nos dois caminhos que o bot usa
      if (!fs.existsSync('./arquivos/imagem')) fs.mkdirSync('./arquivos/imagem', { recursive: true })
      if (!fs.existsSync('./midias')) fs.mkdirSync('./midias', { recursive: true })

      fs.writeFileSync('./arquivos/imagem/menu.mp4', buffer)
      fs.writeFileSync('./midias/menu.mp4', buffer)

      // Remove imagem fixa pra o vídeo/gif ter prioridade
      if (fs.existsSync('./arquivos/imagem/menu.jpg')) fs.unlinkSync('./arquivos/imagem/menu.jpg')
      if (fs.existsSync('./midias/menu.jpg')) fs.unlinkSync('./midias/menu.jpg')

      // Guarda se é gif ou vídeo normal pro comando !menu saber como
      // reenviar (com gifPlayback:true ou não).
      donoState.menuGifPlayback = ehGif
      donoState.salvar()

      return reply(`✅ ${ehGif ? 'GIF' : 'Vídeo'} do menu atualizado com sucesso!\n\nAgora o ${prefix}menu vai exibir ess${ehGif ? 'e GIF' : 'e vídeo'}.`)
    } catch (e) {
      console.log('❌ ERRO (videomenu):', e?.message)
      return reply('❌ Não consegui trocar o vídeo/gif do menu agora.')
    }
  }
}
