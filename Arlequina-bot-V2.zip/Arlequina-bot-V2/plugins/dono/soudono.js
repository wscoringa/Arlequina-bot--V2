const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')
/*
 Comando: soudono (dono)
 Confirma pra quem está no chat que a pessoa que mandou o comando é
 reconhecida pela Arlequina como o dono/criador dela. Como o comando é
 da categoria "dono", só quem já é o dono configurado consegue rodar
 (qualquer outra pessoa é bloqueada antes mesmo de chegar aqui).
*/
module.exports = {
name: 'soudono',
description: 'Confirma que você é reconhecido como o dono da Arlequina',
category: 'dono',
aliases: ['meudono', 'eusouodono'],
async execute({ isDono, arlequina, columbina, from, info, reply, reagir, sender }) {
if (!isDono()) return reply('❌ Este comando é exclusivo do dono do bot!')

const sock = arlequina || columbina

try {
  await reagir('👑')
  await sock.sendMessage(from, {
    text: `╭─━━─🃏💜「 👑💜 *RECONHECIMENTO* 💜👑 」💜🃏─━━─╮\n┃ ✅ Confirmado!\n┃ @${sender.split('@')[0]} é o(a) meu(minha) dono(a)/criador(a).\n┃ Obedeço de olhos fechados. 😈\n╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯\n💜🃏 _Ninguém manda em mim além de você... 👑_`,
    mentions: [sender]
  }, { quoted: info })
} catch (e) {
  await reply(`${caixaArlequina("soudono", `❌ Erro: ${e?.message}`)}`)
}
}
}
