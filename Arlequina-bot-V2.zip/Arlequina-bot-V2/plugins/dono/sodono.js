/*
 !so_dono / !sodono on/off (só dono)
 Enquanto ligado NESSE GRUPO, SÓ o dono do bot consegue usar comandos
 aqui dentro. Outros grupos continuam funcionando normal — é por grupo,
 não afeta o bot inteiro. Todo mundo mais é ignorado em silêncio.
*/
const donoState = require('../../arquivos/js/donoState.js')

module.exports = {
  name: 'sodono',
  description: 'Liga/desliga o modo "só o dono usa o bot" NESSE grupo (só dono)',
  category: 'dono',
  aliases: ['so_dono'],

  async execute({ reply, reagir, args, isDono, isGroup, from }) {
    try {
      if (!isDono()) return reply('❌ Apenas o dono pode usar esse comando!')
      if (!isGroup) return reply('❌ Esse comando só funciona dentro de um grupo (ele ativa só pro grupo atual).')

      const ativoAqui = !!donoState.botStatus.soDonoGrupos[from]
      const modo = (args[0] || '').toLowerCase()

      if (!['on', 'off', '1', '0', 'ligar', 'desligar'].includes(modo)) {
        return reply(`🃏💜 *SÓ DONO (nesse grupo)* 💜🃏\n\nStatus aqui: *${ativoAqui ? 'Ligado ✅' : 'Desligado ❌'}*\n\n*!sodono on* — Só o dono usa o bot NESSE grupo\n*!sodono off* — Volta ao normal NESSE grupo`)
      }

      const ligar = modo === 'on' || modo === '1' || modo === 'ligar'

      if (ligar && ativoAqui) return reply('👑 O modo "só dono" já está ligado nesse grupo, senhor(a)!')
      if (!ligar && !ativoAqui) return reply('🔓 O modo "só dono" já está desligado nesse grupo, senhor(a)!')

      if (ligar) donoState.botStatus.soDonoGrupos[from] = true
      else delete donoState.botStatus.soDonoGrupos[from]
      donoState.salvar()

      await reagir(ligar ? '👑' : '🔓')

      return reply(ligar
        ? `👑💜 *MODO SÓ DONO ATIVADO NESSE GRUPO* 💜👑\n\n🚫 Só o dono consegue usar meus comandos aqui.\nOutros grupos continuam normais.\n\nPra desligar: *!sodono off*`
        : `🔓💜 *MODO SÓ DONO DESATIVADO NESSE GRUPO* 💜🔓\n\n✅ Todo mundo já pode voltar a usar meus comandos aqui.`)

    } catch (e) {
      console.log('❌ ERRO DONO (sodono):', e?.message)
      await reply('❌ Não consegui executar esse comando agora.')
    }
  }
}
