const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
  name: 'sair',
  description: 'Faz o bot sair do grupo',
  category: 'dono',
  aliases: ['leave'],

  async execute({ columbina, from, reply, isGroup, isDono }) {

    // 🔐 Apenas o dono
    if (!isDono()) {
      return reply(
        caixaArlequina(
          'sair',
          '❌ Apenas o dono pode usar este comando!'
        )
      )
    }

    // 👥 Apenas em grupos
    if (!isGroup) {
      return reply('❌ Este comando só pode ser usado em grupos!')
    }

    // 🃏💜 Mensagem de despedida
    await reply(
      `🃏💜 *ARLEQUINA ESTÁ INDO EMBORA...* 💜🃏

A Arlequina já fez sua bagunça por aqui... 😈

Agora ela vai embora.
Não sintam saudades, eu posso voltar. 🃏💜

🎭 *Foi divertido enquanto durou...*

_Arlequina saindo do grupo..._`
    )

    // ⏳ Dá tempo para o WhatsApp entregar a mensagem
    await new Promise(resolve => setTimeout(resolve, 2500))

    // 🚪 Agora sim sai do grupo
    await columbina.groupLeave(from)
  }
}