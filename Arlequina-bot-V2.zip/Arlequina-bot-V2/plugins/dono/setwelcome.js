/*
 Atalho de !bemvindo legenda <texto>, agora restrito ao dono.
 Comando original: setwelcome, bemvindo, legendabv.
 A aliás 'bemvindo' foi removida daqui pra não colidir com o comando
 principal plugins/admin/bemvindo.js (que já tem esse nome e continua
 liberado pra admin normal).
*/
const welcomeDB = require('../../arquivos/js/welcomeDB.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'setwelcome',
description: "(Dono) Define a legenda de entrada (atalho de !bemvindo legenda)",
category: 'dono',
aliases: ['legendabv', 'legendaentrada'],
async execute({ isDono, from, args, q, qOriginal, reply, reagir, isGroup, prefix }) {
if (!isDono()) return reply('❌ Este comando é exclusivo do dono do bot!')


if (!isGroup) return reply('❌ Este comando só pode ser usado em grupos!')

const textoWelcome = qOriginal || q || args.join(' ')

if (!textoWelcome || !textoWelcome.trim()) {
  return reply(`${caixaArlequina("setwelcome", `❌ Digite a mensagem de boas-vindas.\n\nPlaceholders: {usuario} {grupo} {membros}\n\nEx: ${prefix}legendabv Bem-vindo(a) {usuario} ao {grupo}! 🤡`)}`)
}

welcomeDB.setConfig(from, { entrada: textoWelcome })
await reagir('✅')
return reply('✅ Mensagem de boas-vindas configurada para este grupo.')

}
}
