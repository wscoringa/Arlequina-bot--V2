const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')
/*
 Publica a mídia citada como status do grupo (o "recado"/história
 compartilhada do grupo no WhatsApp).

 Uso dentro do próprio grupo: responda (quote) uma imagem, vídeo,
 áudio, figurinha ou documento e use !statusgp — publica automático
 nesse mesmo grupo, sem precisar informar ID nenhum.

 Uso remoto (de fora do grupo, ex: no privado): !statusgp <id_do_grupo>
*/
module.exports = {
name: 'statusgp',
description: "Publica a mídia citada como status do grupo (atual, ou outro se informar o ID)",
category: 'dono',
aliases: [],
async execute({ isDono, arlequina, from, info, args, sender, isGroup, reply, reagir, prefix }) {
if (!isDono()) return reply('❌ Este comando é exclusivo do dono do bot!')


try {
  // Se já tiver dentro de um grupo, usa ele automaticamente — só
  // precisa informar o ID na mão se estiver postando de fora (ex: DM)
  const groupId = args[0] || (isGroup ? from : null)
  if (!groupId) {
    return reply(`${caixaArlequina("statusgp", `Use dentro do grupo (sem precisar de ID) ou informe o ID de outro grupo.\nEx: ${prefix}statusgp 1203xxxx@g.us`)}`)
  }

  const quotedMsg = info.message?.extendedTextMessage?.contextInfo?.quotedMessage
  if (!quotedMsg) {
    return reply('Marque uma imagem, vídeo, áudio, figurinha ou documento.')
  }

  const TIPOS_ACEITOS = ['imageMessage', 'videoMessage', 'audioMessage', 'stickerMessage', 'documentMessage']
  const type = TIPOS_ACEITOS.find(t => quotedMsg[t]) || Object.keys(quotedMsg)[0]
  if (!TIPOS_ACEITOS.includes(type)) {
    return reply('Tipo de mídia não suportado pro status. Marque imagem, vídeo, áudio, figurinha ou documento.')
  }

  const media = { ...quotedMsg[type] }
  media.contextInfo = {
    ...(media.contextInfo || {}),
    isGroupStatus: true,
    statusSourceType: type === 'imageMessage' ? 'IMAGE' : type === 'videoMessage' ? 'VIDEO' : 'GENERIC',
    statusAttributions: [
      {
        type: "GROUP_STATUS",
        groupStatus: {
          authorJid: sender
        }
      }
    ],
    pairedMediaType: "NOT_PAIRED_MEDIA"
  }
  delete media.viewOnce

  await arlequina.relayMessage(groupId, {
    groupStatusMessageV2: {
      message: {
        [type]: media
      }
    }
  }, {})

  await reagir('✅')
  return reply('✅ | Status enviado!')
} catch (e) {
  console.log('❌ ERRO DONO (statusgp):', e?.message)
  await reply('❌ Erro ao criar status no grupo.')
}

}
}
