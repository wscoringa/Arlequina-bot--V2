const fs = require('fs')
const path = require('path')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'setprefix',
description: 'Altera o prefixo global do bot no config.json',
category: 'dono',
aliases: ['prefixo', 'spx'],
async execute({ q, reply, isDono, prefix }) {
// BUGFIX SEGURANÇA: "isDono" chega aqui como uma FUNÇÃO (() => isDono(sender)), não como true/false. "if (!isDono)" checava se a FUNÇÃO existia (sempre existe = nunca bloqueava ninguém!) em vez de checar o RESULTADO dela. Isso deixava esse comando de dono liberado pra qualquer pessoa usar. Corrigido chamando isDono().
if (!isDono()) return reply('❌ Apenas o dono pode usar este comando!')

const novoPrefix = q.trim()
if (!novoPrefix || novoPrefix.length !== 1) {
return reply('❌ Informe um único caractere para ser o novo prefixo global!\n\nExemplo: `!setprefix #`')
}

if (novoPrefix === prefix) {
return reply('❌ Este já é o prefixo global atual!')
}

try {
const configPath = path.resolve('./database/config.json')
const config = JSON.parse(fs.readFileSync(configPath, 'utf-8'))

config.prefix = novoPrefix
fs.writeFileSync(configPath, JSON.stringify(config, null, 2))

return reply(`✅ *PREFIXO GLOBAL ALTERADO!*\n\n• Novo Prefixo: \`${novoPrefix}\`\n\nO bot será reiniciado em instantes para aplicar a mudança em todos os comandos.`)
} catch (e) {
return reply(`${caixaArlequina("setprefix", `❌ Erro ao alterar o config.json: ${e.message}`)}`)
}
}
}
