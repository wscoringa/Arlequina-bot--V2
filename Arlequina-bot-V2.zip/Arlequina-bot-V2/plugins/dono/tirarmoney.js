const { carregarUsuarios, salvarUsuarios, getUsuario } = require('../../arquivos/js/rpgDB.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'tirarmoney',
description: "(Dono) Remove dinheiro de você ou de quem marcar",
category: 'dono',
aliases: ['tirargrana', 'removemoney', 'delmoney'],
async execute({ isDono, arlequina, from, info, args, q, reply, prefix, sender }) {
if (!isDono()) return reply('❌ Este comando é exclusivo do dono do bot!')


const sock = arlequina
const msg = info
const usuarios = carregarUsuarios()

const enviar = async (conteudo) => {
  try { return await sock.sendMessage(from, conteudo, { quoted: info }) }
  catch (e) { return reply(conteudo?.text || '✅') }
}

try {
  const mencionado = msg.message?.extendedTextMessage?.contextInfo?.participant || msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]
  const alvo = mencionado || sender

  const valor = Number(args.find(a => /^\d+(\.\d+)?$/.test(a)))

  if (!valor || isNaN(valor) || valor <= 0) {
    return reply(`${caixaArlequina("tirarmoney", `❌ Use: *${prefix}tirarmoney <valor>*\n\nEx: *${prefix}tirarmoney 5000*\nOu: *${prefix}tirarmoney 5000 @membro*`)}`)
  }

  getUsuario(usuarios, alvo)
  usuarios[alvo].saldo = Math.max(0, usuarios[alvo].saldo - Math.floor(valor))
  salvarUsuarios(usuarios)

  const numAlvo = alvo.split('@')[0]

  if (mencionado) {
    await enviar({
      text: `╭─━━─🃏💜「 *TIRARMONEY* 」💜🃏─━━─╮\n\n🧨 *-R$ ${Math.floor(valor).toLocaleString('pt-BR')}* removido!\n\n👤 De: @${numAlvo}\n👛 Novo saldo: *R$ ${usuarios[alvo].saldo.toLocaleString('pt-BR')}*\n\n╰─━━━━━━━━━━━━━━━━━━━━━━━━─╯`,
      mentions: [alvo]
    })
  } else {
    await enviar({
      text: `╭─━━─🃏💜「 *TIRARMONEY* 」💜🃏─━━─╮\n\n🧨 *-R$ ${Math.floor(valor).toLocaleString('pt-BR')}* removido!\n\n👤 De: você mesmo\n👛 Novo saldo: *R$ ${usuarios[alvo].saldo.toLocaleString('pt-BR')}*\n\n╰─━━━━━━━━━━━━━━━━━━━━━━━━─╯`
    })
  }
} catch (e) {
  console.log('❌ ERRO (tirarmoney):', e?.message)
  await reply('❌ Não consegui executar agora.')
}

}
}
