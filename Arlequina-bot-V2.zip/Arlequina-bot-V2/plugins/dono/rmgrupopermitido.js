/*
 Convertido automaticamente do connect.js (bot antigo monolitico) para
 o sistema de plugins da Arlequina Bot. Comando original: rmgrupopermitido
*/
const donoState = require('../../arquivos/js/donoState.js')
const adminState = require('../../arquivos/js/adminState.js')
const fs = require('fs')
const { dbPath } = require('../../arquivos/js/rpgDB.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'rmgrupopermitido',
description: "Remove o grupo atual da lista de permitidos",
category: 'dono',
aliases: [],
async execute({ isDono, arlequina, from, info, args, q, reply, reagir, prefix, sender, pushname, isGroup, donoJid, commandManager, config }) {
if (!isDono()) return reply('❌ Este comando é exclusivo do dono do bot!')


const sock = arlequina
const msg = info
const jid = sender
const jidReal = sender
const numeroReal = String(sender || '').split('@')[0]
const isGrupo = isGroup
const nome = pushname
const texto = q || args.join(' ')

const enviar = async (conteudo, _opcoes) => {
if (typeof conteudo === 'string') return reply(conteudo)
try {
return await sock.sendMessage(from, conteudo, { quoted: info })
} catch (e) {
const fallback = conteudo?.caption || conteudo?.text || '✅'
return reply(fallback)
}
}

try {
  if (!isGrupo) {
  await reply(caixaArlequina("rmgrupopermitido", `❌ Use esse comando dentro do grupo que deseja remover.`))
  return
  }
  
  if (!donoState.gruposPermitidos || !donoState.gruposPermitidos.includes(from)) {
  await reply('Este grupo não está na lista de permitidos.')
  return
  }
  
  donoState.gruposPermitidos = donoState.gruposPermitidos.filter(g => g !== from)
  await reply('✅ Este grupo foi removido da lista de grupos permitidos.')
} catch (e) {
console.log('❌ ERRO DONO (rmgrupopermitido):', e?.message)
await reply('❌ Não consegui executar esse comando.')
}

}
}
