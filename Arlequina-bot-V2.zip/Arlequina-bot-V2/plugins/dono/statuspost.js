/*
 Convertido/adaptado para o sistema de plugins da Arlequina Bot.
 Comando original: statuspost, poststatus (bot antigo monolitico,
 baseado em switch-case dentro do index.js).

 A Arlequina não usa switch-case: cada comando é um arquivo de plugin
 em plugins/<categoria>/*.js. Esse plugin posta texto/mídia no status
 (stories) do bot, ou envia em um canal (@newsletter) se o JID do
 canal for passado como primeiro argumento.

 category: 'dono' -> o próprio dispatcher do index.js já bloqueia esse
 comando pra quem não é o dono, então nem precisa checar isDono() aqui.
*/
const crypto = require('crypto')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')
const {
  prepareWAMessageMedia,
  generateWAMessageFromContent
} = require('@whiskeysockets/baileys')

module.exports = {
name: 'statuspost',
description: "(Dono) Posta texto/mídia no status do bot ou em um canal",
category: 'dono',
aliases: ['poststatus'],
async execute({ columbina, from, info, args, q, qOriginal, reply, reagir, getFileBuffer }) {

const sock = columbina

try {
  await reagir('⏳')

  let argsTemp = [...args]

  const canalJid = argsTemp[0]?.includes('@newsletter')
    ? argsTemp.shift()
    : null

  const caption = argsTemp.join(' ') || qOriginal || q || ''
  const messageSecret = crypto.randomBytes(32)
  let innerMsg = {}
  let mediaBuffer = null
  let mediaType = null
  let mediaMime = null
  let mediaPtt = false

  const quotedMsg = info.message?.extendedTextMessage?.contextInfo?.quotedMessage || null

  if (quotedMsg) {
    const type = Object.keys(quotedMsg)[0]
    mediaType = type

    if (type === 'imageMessage' || type === 'videoMessage' || type === 'audioMessage') {
      const media = quotedMsg[type]

      if (!media?.mediaKey || !media?.url) {
        await reagir('❌')
        return reply(`${caixaArlequina("statuspost", `❌ Essa mídia não pode ser baixada.\n\n📌 Se for mídia de canal/status, envie ela primeiro no PV do bot e use o comando respondendo ela.`)}`)
      }

      const tipoDownload = type === 'imageMessage' ? 'image' : type === 'videoMessage' ? 'video' : 'audio'
      const buffer = await getFileBuffer(media, tipoDownload)
      if (!buffer) throw new Error('Falha ao baixar mídia.')

      mediaBuffer = buffer
      mediaMime = media.mimetype || 'application/octet-stream'
      mediaPtt = media.ptt || false

      if (type === 'imageMessage') {
        const prep = await prepareWAMessageMedia(
          { image: buffer },
          { upload: sock.waUploadToServer }
        )

        innerMsg = {
          imageMessage: {
            ...prep.imageMessage,
            caption: caption || quotedMsg.imageMessage?.caption || '',
            messageContextInfo: { messageSecret }
          }
        }
      }

      if (type === 'videoMessage') {
        const prep = await prepareWAMessageMedia(
          { video: buffer },
          { upload: sock.waUploadToServer }
        )

        innerMsg = {
          videoMessage: {
            ...prep.videoMessage,
            caption: caption || quotedMsg.videoMessage?.caption || '',
            messageContextInfo: { messageSecret }
          }
        }
      }

      if (type === 'audioMessage') {
        const prep = await prepareWAMessageMedia(
          {
            audio: buffer,
            mimetype: quotedMsg.audioMessage?.mimetype || 'audio/mp4',
            ptt: quotedMsg.audioMessage?.ptt || false
          },
          { upload: sock.waUploadToServer }
        )

        innerMsg = {
          audioMessage: {
            ...prep.audioMessage,
            messageContextInfo: { messageSecret }
          }
        }
      }
    } else {
      innerMsg = {
        extendedTextMessage: {
          text: caption || quotedMsg.extendedTextMessage?.text || quotedMsg.conversation || '',
          messageContextInfo: { messageSecret }
        }
      }
    }
  } else {
    if (!caption) {
      await reagir('❌')
      return reply(`❌ Use assim:\n\n!statuspost seu texto\n\n!statuspost 120363xxxxxxxxxx@newsletter seu texto\n\nOu responda uma imagem/vídeo/áudio com legenda.`)
    }

    innerMsg = {
      extendedTextMessage: {
        text: caption,
        messageContextInfo: { messageSecret }
      }
    }
  }

  if (canalJid) {
    if (mediaType === 'imageMessage') {
      await sock.sendMessage(canalJid, {
        image: mediaBuffer,
        caption: caption || quotedMsg?.imageMessage?.caption || ''
      })
    } else if (mediaType === 'videoMessage') {
      await sock.sendMessage(canalJid, {
        video: mediaBuffer,
        caption: caption || quotedMsg?.videoMessage?.caption || ''
      })
    } else if (mediaType === 'audioMessage') {
      await sock.sendMessage(canalJid, {
        audio: mediaBuffer,
        mimetype: mediaMime || 'audio/mp4',
        ptt: mediaPtt
      })
    } else {
      await sock.sendMessage(canalJid, {
        text: caption || quotedMsg?.extendedTextMessage?.text || quotedMsg?.conversation || ''
      })
    }

    await reagir('✅')
    return reply('✅ Enviado no canal com sucesso!')
  }

  const msgType = Object.keys(innerMsg)[0]

  if (!msgType || !innerMsg[msgType]) {
    throw new Error('Mensagem inválida para status.')
  }

  innerMsg[msgType].contextInfo = {
    isGroupStatus: true
  }

  const msg = generateWAMessageFromContent(
    from,
    {
      messageContextInfo: { messageSecret },
      groupStatusMessageV2: {
        message: {
          ...innerMsg,
          messageContextInfo: { messageSecret }
        }
      }
    },
    {
      userJid: sock.user.id
    }
  )

  await sock.relayMessage(from, msg.message, {
    messageId: msg.key.id
  })

  await reagir('✅')
  reply('✅ Status enviado com sucesso!')
} catch (e) {
  console.log('ERRO STATUS:', e)
  await reagir('❌')
  reply('❌ Erro ao enviar status/canal.')
}

}
}
