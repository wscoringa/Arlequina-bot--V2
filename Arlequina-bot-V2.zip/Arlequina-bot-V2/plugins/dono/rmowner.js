/*
 Convertido automaticamente do connect.js (bot antigo monolitico) para
 o sistema de plugins da Arlequina Bot. Comando original: rmowner
*/
const donoState = require('../../arquivos/js/donoState.js')
const adminState = require('../../arquivos/js/adminState.js')
const fs = require('fs')
const { dbPath } = require('../../arquivos/js/rpgDB.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'rmowner',
description: "Remove um dono extra do bot",
category: 'dono',
aliases: [],
async execute({ isDono, arlequina, from, info, args, q, reply, reagir, prefix, sender, pushname, isGroup, donoJid, commandManager, config }) {
if (!isDono()) return reply('❌ Este comando é exclusivo do dono do bot!')


const sock = arlequina
const msg = info
const jid = sender
const jidReal = sender
const numeroReal = String(sender || '').split('@')[0]
const isGrupo = isGroup
const nome = pushname
const texto = q || args.join(' ')

const enviar = async (conteudo, _opcoes) => {
if (typeof conteudo === 'string') return reply(conteudo)
try {
return await sock.sendMessage(from, conteudo, { quoted: info })
} catch (e) {
const fallback = conteudo?.caption || conteudo?.text || '✅'
return reply(fallback)
}
}

try {
  const alvo = msg.message?.extendedTextMessage?.contextInfo?.participant || msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]
  
  if (!alvo) {
  await reply('Marque o usuário (@) que deseja remover de dono.')
  return
  }
  
  const numeroAlvo = alvo.split('@')[0]
  
  if (!donoState.donosExtras || !donoState.donosExtras.includes(numeroAlvo)) {
  await reply('Esse usuário não é um dono extra.')
  return
  }
  
  donoState.donosExtras = donoState.donosExtras.filter(n => n !== numeroAlvo)
  
  await enviar({
  text: `${caixaArlequina("rmowner", `✅ @${numeroAlvo} não é mais dono do bot.`)}`,
  mentions: [alvo]
  }, { quoted: msg })
} catch (e) {
console.log('❌ ERRO DONO (rmowner):', e?.message)
await reply('❌ Não consegui executar esse comando.')
}

}
}
