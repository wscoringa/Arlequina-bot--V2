/*
 Comando: sermbm (dono)
 O dono usa esse comando dentro de um grupo pra se auto-rebaixar e
 voltar a ser membro comum, sem precisar mencionar a si mesmo.
*/
const { convertWhatsAppUser } = require('../../arquivos/js/userManager.js')
const modLogDB = require('../../arquivos/js/modLogDB.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

const frases = [
  'Descendo do trono por vontade própria... 😏🃏',
  'Às vezes é bom só curtir a festa sem responsabilidade! 💜😈',
  'Coroa guardada na gaveta por enquanto... 👑💤',
  'Virou povo de novo, bem-vindo(a) de volta à plateia! 🃏💜'
]

module.exports = {
name: 'sermbm',
description: 'O dono se auto-rebaixa para membro comum do grupo',
category: 'dono',
aliases: ['eumbm', 'sermembro'],
async execute({ isDono, arlequina, columbina, from, info, reply, reagir, isGroup, isBotAdm, sender }) {
if (!isDono()) return reply('❌ Este comando é exclusivo do dono do bot!')

const sock = arlequina || columbina

if (!isGroup) return reply('❌ Este comando só pode ser usado em grupos!')
if (!isBotAdm) return reply('❌ A Arlequina precisa ser administradora do grupo pra fazer isso!')

const senderJid = convertWhatsAppUser(sender, 'jid')

try {
  await reagir('🎭')
  modLogDB.marcarAcaoBot(from, senderJid, 'demote')
  await sock.groupParticipantsUpdate(from, [senderJid], 'demote')

  const frase = frases[Math.floor(Math.random() * frases.length)]
  await sock.sendMessage(from, {
    text: `╭─━━─🃏💜「 🎭💜 *SER MEMBRO* 💜🎭 」💜🃏─━━─╮\n┃ ✅ @${senderJid.split('@')[0]} voltou a ser membro comum!\n╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯\n💜🃏 _${frase}_`,
    mentions: [senderJid]
  }, { quoted: info })
  await reagir('✅')
} catch (e) {
  await reagir('❌')
  await reply(`${caixaArlequina("sermbm", `❌ Erro ao tentar te rebaixar: ${e?.message}`)}`)
}
}
}
