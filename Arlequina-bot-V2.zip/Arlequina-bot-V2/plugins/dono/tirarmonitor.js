const { carregarUsuarios, salvarUsuarios } = require('../../arquivos/js/rpgDB.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'tirarmonitor',
description: "Remove um usuário da lista de monitores",
category: 'dono',
aliases: [],
async execute({ arlequina, from, info, reply, reagir, isDono, prefix, groupMembers, isGroup }) {
if (!isDono()) return reply('❌ Apenas o dono pode usar este comando.')

try {
  const alvoRaw = info.message?.extendedTextMessage?.contextInfo?.participant
          || info.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]

  if (!alvoRaw) return reply(`❌ Marque alguém com @\nEx: ${prefix}tirarmonitor @pessoa`)

  // Mesma resolução de @lid do !monitor — sem isso, pode não achar o
  // registro de monitor certo pra remover.
  let alvo = alvoRaw
  if (alvoRaw.endsWith('@lid')) {
    if (global.lidParaNumero?.[alvoRaw]) {
      alvo = global.lidParaNumero[alvoRaw]
    } else {
      const participante = isGroup ? groupMembers?.find(p => p.id === alvoRaw) : null
      if (participante?.phoneNumber) {
        alvo = participante.phoneNumber
        if (!global.lidParaNumero) global.lidParaNumero = {}
        global.lidParaNumero[alvoRaw] = alvo
      } else {
        try {
          const pn = await arlequina.signalRepository?.lidMapping?.getPNForLID(alvoRaw)
          if (pn) {
            alvo = pn.includes('@') ? pn : `${pn}@s.whatsapp.net`
            if (!global.lidParaNumero) global.lidParaNumero = {}
            global.lidParaNumero[alvoRaw] = alvo
          }
        } catch (eLid) {
          console.log('Erro ao resolver LID do marcado (tirarmonitor):', eLid?.message)
        }
      }
    }
  }

  const usuarios = carregarUsuarios()
  if (!usuarios[alvo] || !usuarios[alvo].monitor) {
    await reagir('❗')
    return arlequina.sendMessage(from, {
      text: `${caixaArlequina("tirarmonitor", `❗ @${alvo.split('@')[0]} já não é Monitor.`)}`,
      mentions: [alvo]
    }, { quoted: info })
  }

  usuarios[alvo].monitor = false
  salvarUsuarios(usuarios)

  await reagir('🛡️')
  await arlequina.sendMessage(from, {
    text: `╭─━━─🃏💜「 🛡️💜 *MONITOR* 💜🛡️ 」💜🃏─━━─╮\n┃ ❌ @${alvo.split('@')[0]} não é mais\n┃ Monitor do grupo.\n╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯\n💜🃏 _Monitor removido com sucesso!_`,
    mentions: [alvo]
  }, { quoted: info })
} catch (e) {
  console.log('❌ ERRO DONO (tirarmonitor):', e?.message)
  await reply('❌ Não consegui executar esse comando.')
}

}
}
