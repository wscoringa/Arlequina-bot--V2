/*
 Comando: tirarlevel (dono)
 #tirarlevel               -> remove 1 nível de você mesmo (dono)
 #tirarlevel <quantidade>            -> remove X níveis de você mesmo (dono)
 #tirarlevel <quantidade> @usuario   -> remove X níveis do usuário marcado
 (marcando/respondendo também funciona sem precisar digitar @)
 O level nunca fica menor que 1, e os status voltam pro mínimo padrão.
*/
const { carregarUsuarios, salvarUsuarios, getUsuario } = require('../../arquivos/js/rpgDB.js')
const { convertWhatsAppUser } = require('../../arquivos/js/userManager.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'tirarlevel',
description: 'Remove nível(is) de você (dono) ou de um usuário marcado',
category: 'dono',
aliases: ['tirarlvl', 'tirarnivel', 'dellevel'],
async execute({ isDono, arlequina, columbina, from, info, args, reply, reagir, sender, prefix }) {
if (!isDono()) return reply('❌ Este comando é exclusivo do dono do bot!')

const sock = arlequina || columbina

const quoted = info.message?.extendedTextMessage?.contextInfo
const mencionado = quoted?.participant || quoted?.mentionedJid?.[0]
const alvo = mencionado ? convertWhatsAppUser(mencionado, 'jid') : sender

const numArg = args.find(a => /^\d+$/.test(a))
const quantidade = numArg ? parseInt(numArg) : 1

try {
  const usuarios = carregarUsuarios()
  const u = getUsuario(usuarios, alvo)

  let removidos = 0
  for (let i = 0; i < quantidade; i++) {
    if (u.level <= 1) break
    u.level--
    u.vidaMax = Math.max(100, u.vidaMax - 20); u.vida = Math.min(u.vida, u.vidaMax)
    u.manaMax = Math.max(50, u.manaMax - 10); u.mana = Math.min(u.mana, u.manaMax)
    u.staminaMax = Math.max(100, u.staminaMax - 10); u.stamina = Math.min(u.stamina, u.staminaMax)
    u.forca = Math.max(10, u.forca - 3); u.defesa = Math.max(10, u.defesa - 2)
    u.agilidade = Math.max(10, u.agilidade - 2); u.sorte = Math.max(10, u.sorte - 1)
    removidos++
  }

  salvarUsuarios(usuarios)

  await reagir('📉')

  const quemMsg = mencionado ? `@${alvo.split('@')[0]}` : 'você'
  const texto = `╭─━━─🃏💜「 📉💜 *TIRAR LEVEL* 💜📉 」💜🃏─━━─╮\n┃ -${removidos} nível(is) de ${quemMsg}\n┃ 🏅 Level atual: ${u.level}\n╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯\n💜🃏 _Caiu do trono por ordem da dona... 😈_`

  await sock.sendMessage(from, { text: texto, mentions: mencionado ? [alvo] : [] }, { quoted: info })
} catch (e) {
  console.log('❌ ERRO tirarlevel:', e?.message)
  await reply(caixaArlequina("tirarlevel", `❌ Não consegui remover o nível agora.`))
}
}
}
