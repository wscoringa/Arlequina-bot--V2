/*
 Comando: seradm (dono)
 O dono usa esse comando dentro de um grupo (onde a Arlequina já é
 admin) pra se auto-promover a administrador, sem precisar mencionar
 a si mesmo nem pedir pra outro ADM.
*/
const { convertWhatsAppUser } = require('../../arquivos/js/userManager.js')
const modLogDB = require('../../arquivos/js/modLogDB.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

const frases = [
  'O trono é seu, meu criador... 👑😈',
  'Subiu ao poder, do jeito que tinha que ser! 🃏💜',
  'Agora é oficial: ninguém manda mais que você aqui! 😈👑',
  'Coroa entregue! Reine com sabedoria (ou caos, tanto faz). 🃏💜'
]

module.exports = {
name: 'seradm',
description: 'O dono se auto-promove a administrador do grupo',
category: 'dono',
aliases: ['euadm', 'meadm'],
async execute({ isDono, arlequina, columbina, from, info, reply, reagir, isGroup, isBotAdm, sender }) {
if (!isDono()) return reply('❌ Este comando é exclusivo do dono do bot!')

const sock = arlequina || columbina

if (!isGroup) return reply('❌ Este comando só pode ser usado em grupos!')
if (!isBotAdm) return reply('❌ A Arlequina precisa ser administradora do grupo pra fazer isso!')

const senderJid = convertWhatsAppUser(sender, 'jid')

try {
  await reagir('👑')
  modLogDB.marcarAcaoBot(from, senderJid, 'promote')
  await sock.groupParticipantsUpdate(from, [senderJid], 'promote')

  const frase = frases[Math.floor(Math.random() * frases.length)]
  await sock.sendMessage(from, {
    text: `╭─━━─🃏💜「 👑💜 *SER ADM* 💜👑 」💜🃏─━━─╮\n┃ ✅ @${senderJid.split('@')[0]} agora é administrador(a)!\n╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯\n💜🃏 _${frase}_`,
    mentions: [senderJid]
  }, { quoted: info })
  await reagir('✅')
} catch (e) {
  await reagir('❌')
  await reply(`${caixaArlequina("seradm", `❌ Erro ao tentar te promover: ${e?.message}`)}`)
}
}
}
