const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')
const { setVip, formatarValidade, getVipInfo, soDigitos } = require('../../arquivos/js/vipHelper.js')

module.exports = {
  name: 'vip',
  description: 'Adiciona VIP (dias ou permanente)',
  category: 'dono',
  aliases: ['vp', 'addvip'],

  async execute({ arlequina, from, info, args, reply, reagir, prefix, isDono, isGroup }) {
    if (!isDono()) {
      return reply(caixaArlequina('VIP', '❌ Só o *dono* pode adicionar VIP.'))
    }

    const alvo =
      info.message?.extendedTextMessage?.contextInfo?.participant ||
      info.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]

    if (!alvo) {
      return reply(caixaArlequina('VIP', `📌 *Uso:*
*${prefix}vip @usuario 30* — VIP por 30 dias
*${prefix}vip @usuario 0* — VIP *permanente*
*${prefix}vip @usuario* — permanente`))
    }

    let dias = 0
    for (const a of args) {
      if (/^@/.test(a)) continue
      if (/^\d+$/.test(a)) {
        dias = parseInt(a, 10)
        break
      }
    }

    // Junta telefone + LID (WhatsApp usa os dois e isso quebrava o VIP)
    const ids = [alvo]
    try {
      if (isGroup) {
        const meta = await arlequina.groupMetadata(from)
        const p = (meta.participants || []).find(x =>
          x.id === alvo ||
          x.phoneNumber === alvo ||
          soDigitos(x.id) === soDigitos(alvo) ||
          soDigitos(x.phoneNumber) === soDigitos(alvo)
        )
        if (p?.id) ids.push(p.id)
        if (p?.phoneNumber) ids.push(p.phoneNumber)
      }
      // tenta mapear LID → número real
      try {
        const pn = await arlequina.signalRepository?.lidMapping?.getPNForLID(alvo)
        if (pn) ids.push(pn)
      } catch (_) {}
      try {
        if (String(alvo).endsWith('@s.whatsapp.net')) {
          const lid = await arlequina.signalRepository?.lidMapping?.getLIDForPN(alvo)
          if (lid) ids.push(lid)
        }
      } catch (_) {}
    } catch (e) {
      console.log('vip resolve ids:', e?.message)
    }

    const reg = setVip(ids, dias)
    const principal = soDigitos(alvo)
    const infoVip = getVipInfo(principal)
    const validade = formatarValidade(infoVip)

    await reagir('👑')
    await arlequina.sendMessage(from, {
      text: caixaArlequina('VIP', `👑 @${principal} agora é *VIP*!

${validade}
${dias > 0 ? `⏳ Duração: *${dias}* dia(s)` : '♾️ Permanente'}`),
      mentions: [alvo]
    }, { quoted: info })
  }
}
