const fs = require('fs')
const path = require('path')
const os = require('os')
const zlib = require('zlib')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

/**
 * ZIP LIMPO da Arlequina:
 * - código, plugins, menus, mídias base
 * - pastas database vazias (sem RPG, adv, sessão, atividade…)
 * - novo usuário começa do zero
 */

// Pastas inteiras que NÃO entram (dados de uso)
const PASTAS_BLOQUEADAS = new Set([
  'node_modules',
  '.git',
  'temp',
  'Arlequina-QR',
  'users',
  'atividade',
  'quiz',
  'reputacao',
  '.wwebjs_auth',
  '.wwebjs_cache'
])

// Arquivos de runtime que NÃO entram (mesmo fora das pastas acima)
const ARQUIVOS_BLOQUEADOS = new Set([
  'advertencias.json',
  'avisos.json',
  'usuarios.json',
  'donoState.json',
  'eventos.json',
  'missoes_ativas.json',
  'modlog.json',
  'clans.json',
  'agendaGrupo.json',
  'figComandos.json',
  'tabelasgp.json',
  'modobn.json',
  'arlequina-bot-v1.zip'
])

// Pastas que devem existir no zip limpo (com .gitkeep)
const PASTAS_LIMPA = [
  'database',
  'database/users',
  'database/atividade',
  'database/quiz',
  'database/reputacao',
  'database/Arlequina-QR',
  'temp',
  'midias/fundos',
  'midias/brincadeiras',
  'midias/rpg',
  'midias/rank',
  'midias/figurinhas'
]

function nomeBase(p) {
  return path.basename(p)
}

function devePularArquivo(full, rel) {
  const base = nomeBase(full)
  if (base.startsWith('.trashed')) return true
  if (base.endsWith('.zip')) return true
  if (ARQUIVOS_BLOQUEADOS.has(base)) return true

  const partes = rel.split('/')
  for (const p of partes) {
    if (PASTAS_BLOQUEADAS.has(p)) return true
  }

  // sessão / qr em qualquer lugar
  if (rel.includes('Arlequina-QR/')) return true
  // dados de grupo gerados
  if (/database\/atividade\//.test(rel)) return true
  if (/database\/users\//.test(rel)) return true
  if (/database\/quiz\//.test(rel)) return true
  if (/database\/reputacao\//.test(rel)) return true

  return false
}

function listarArquivos(dir, base = dir, lista = []) {
  let entries
  try {
    entries = fs.readdirSync(dir, { withFileTypes: true })
  } catch {
    return lista
  }
  for (const ent of entries) {
    if (PASTAS_BLOQUEADAS.has(ent.name)) continue
    if (ent.name.startsWith('.trashed')) continue
    const full = path.join(dir, ent.name)
    const rel = path.relative(base, full).split(path.sep).join('/')
    if (ent.isDirectory()) {
      listarArquivos(full, base, lista)
    } else if (ent.isFile()) {
      if (devePularArquivo(full, rel)) continue
      lista.push({ full, rel, data: null })
    }
  }
  return lista
}

// CRC32
const CRC_TABLE = (() => {
  const t = new Uint32Array(256)
  for (let i = 0; i < 256; i++) {
    let c = i
    for (let j = 0; j < 8; j++) c = (c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1)
    t[i] = c >>> 0
  }
  return t
})()

function crc32(buf) {
  let c = 0xffffffff
  for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8)
  return (c ^ 0xffffffff) >>> 0
}

function u16(n) {
  const b = Buffer.alloc(2)
  b.writeUInt16LE(n, 0)
  return b
}
function u32(n) {
  const b = Buffer.alloc(4)
  b.writeUInt32LE(n >>> 0, 0)
  return b
}

function criarZip(entries) {
  const partes = []
  const centrais = []
  let offset = 0

  for (const item of entries) {
    const data = item.data != null ? item.data : fs.readFileSync(item.full)
    const nameBuf = Buffer.from(item.rel, 'utf8')
    const crc = crc32(data)
    const compressed = zlib.deflateRawSync(data)
    const method = 8

    const local = Buffer.concat([
      u32(0x04034b50),
      u16(20),
      u16(0),
      u16(method),
      u16(0),
      u16(0),
      u32(crc),
      u32(compressed.length),
      u32(data.length),
      u16(nameBuf.length),
      u16(0),
      nameBuf,
      compressed
    ])

    const central = Buffer.concat([
      u32(0x02014b50),
      u16(20),
      u16(20),
      u16(0),
      u16(method),
      u16(0),
      u16(0),
      u32(crc),
      u32(compressed.length),
      u32(data.length),
      u16(nameBuf.length),
      u16(0),
      u16(0),
      u16(0),
      u16(0),
      u32(0),
      u32(offset),
      nameBuf
    ])

    partes.push(local)
    centrais.push(central)
    offset += local.length
  }

  const centralDir = Buffer.concat(centrais)
  const end = Buffer.concat([
    u32(0x06054b50),
    u16(0),
    u16(0),
    u16(centrais.length),
    u16(centrais.length),
    u32(centralDir.length),
    u32(offset),
    u16(0)
  ])

  return Buffer.concat([...partes, centralDir, end])
}

// config no zip: limpo (só campos principais) MAS com o número do dono atual
function configLimpo(root) {
  const cfgPath = path.join(root, 'database', 'config.json')
  let cfg = {
    NumeroDoDono: '',
    NomeDoDono: '',
    NomeDoBot: 'Arlequina',
    prefix: '!',
    canal: ''
  }
  try {
    if (fs.existsSync(cfgPath)) {
      const atual = JSON.parse(fs.readFileSync(cfgPath, 'utf8'))
      cfg = {
        NumeroDoDono: String(atual.NumeroDoDono || atual.numeroDono || '').replace(/\D/g, ''),
        NomeDoDono: atual.NomeDoDono || atual.nomeDono || '',
        NomeDoBot: atual.NomeDoBot || atual.nomeBot || 'Arlequina',
        prefix: atual.prefix || atual.prefixo || '!',
        canal: atual.canal || atual.linkcanal || ''
      }
    }
  } catch (_) {}
  return Buffer.from(JSON.stringify(cfg, null, 2), 'utf8')
}

module.exports = {
  name: 'zipbot',
  description: 'Dono: envia zip LIMPO do bot (sem dados de uso)',
  category: 'dono',
  aliases: ['backupbot', 'botzip', 'ziparbot'],

  async execute({ arlequina, from, info, reply, reagir, isDono }) {
    if (!isDono()) {
      return reply(caixaArlequina('ZIPBOT', '❌ Só o *dono* pode usar este comando.'))
    }

    const root = path.join(__dirname, '../..')
    const zipName = 'arlequina-bot-v1.zip'

    await reagir('📦')
    await reply(caixaArlequina('ZIPBOT', `📦 Gerando *zip limpo*…

Sem advertências, RPG, sessão, atividade de grupo…
Só o bot pronto pra outro usuário configurar.`))

    try {
      const lista = listarArquivos(root)

      // config limpa (substitui se existir na lista)
      const relConfig = 'database/config.json'
      const entries = lista
        .filter(a => a.rel !== relConfig)
        .map(a => ({ full: a.full, rel: a.rel, data: null }))

      entries.push({
        full: null,
        rel: relConfig,
        data: configLimpo(root)
      })

      // garante pastas vazias
      const empty = Buffer.from('', 'utf8')
      for (const pasta of PASTAS_LIMPA) {
        const relKeep = `${pasta}/.gitkeep`
        if (!entries.some(e => e.rel === relKeep)) {
          entries.push({ full: null, rel: relKeep, data: empty })
        }
      }

      // donoState e usuarios vazios de exemplo
      entries.push({
        full: null,
        rel: 'database/donoState.json',
        data: Buffer.from('{}', 'utf8')
      })
      entries.push({
        full: null,
        rel: 'database/usuarios.json',
        data: Buffer.from('{}', 'utf8')
      })
      entries.push({
        full: null,
        rel: 'database/advertencias.json',
        data: Buffer.from('{}', 'utf8')
      })
      entries.push({
        full: null,
        rel: 'database/eventos.json',
        data: Buffer.from('{}', 'utf8')
      })

      const buffer = criarZip(entries)
      const sizeMb = (buffer.length / (1024 * 1024)).toFixed(2)

      await reagir('📤')
      await arlequina.sendMessage(from, {
        document: buffer,
        mimetype: 'application/zip',
        fileName: zipName,
        caption: caixaArlequina('ZIPBOT', `✅ *Zip limpo pronto*

📦 *${zipName}*
💾 ${sizeMb} MB
📁 ${entries.length} itens

🧹 *Removido:*
• advertências, avisos
• RPG / eventos / missões
• atividade de grupos
• sessão (QR)
• usuários e donoState antigos

📱 Config vai com *seu número/nome* (campos limpos).
✨ Outro usuário pode trocar com *!configbot*.
🐙 GitHub: https://github.com/wscoringa/Arlequina-bot--v1`)
      }, { quoted: info })

      await reagir('✅')
    } catch (e) {
      console.log('❌ zipbot:', e?.message || e)
      await reagir('❌')
      return reply(caixaArlequina('ZIPBOT', `❌ Falha ao gerar o zip.\n\n_${e?.message || 'erro'}_`))
    }
  }
}
