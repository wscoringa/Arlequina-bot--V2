/*
 !sairgrupo
 Lista todos os grupos que o bot participa, numerados. Depois é só
 mandar o comando de novo com os números dos grupos que quer que o
 bot saia (pode ser um só ou vários juntos).

 !sairgrupo          → mostra a lista numerada
 !sairgrupo 1 3 5    → sai dos grupos 1, 3 e 5 dessa lista

 Antes de sair de cada grupo, manda uma mensagem de despedida nele.
 Só o dono do bot pode usar.
*/
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Guarda a última lista numerada mostrada pra cada dono, pra saber a
// qual grupo cada número se referia quando ele mandar os números depois.
const ultimaListaPorDono = new Map()

module.exports = {
  name: 'sairgrupo',
  description: '🚪 Lista os grupos do bot (numerados) e sai dos que você escolher',
  category: 'dono',
  aliases: ['sairgrupos', 'saidosgrupos'],
  async execute({ arlequina, from, reply, reagir, args, sender, isDono, prefix }) {
    try {
      if (!isDono()) return reply(caixaArlequina('sairgrupo', `❌ Apenas o dono pode usar este comando!`))

      const sock = arlequina
      const numeros = args.filter(a => /^\d+$/.test(a)).map(Number)

      // ── Sem números: mostra a lista ──
      if (numeros.length === 0) {
        const grupos = await sock.groupFetchAllParticipating()
        const lista = Object.values(grupos)

        if (!lista.length) return reply('📋 O bot não está em nenhum grupo.')

        ultimaListaPorDono.set(sender, lista.map(g => g.id))

        const texto = lista
          .map((g, i) => `${i + 1}. ${g.subject} (${g.participants.length} membros)`)
          .join('\n')

        return reply(caixaArlequina('sairgrupo', `🚪💜 *SAIR DE GRUPOS* 💜🚪\n\n${texto}\n\n📌 *Como usar:*\nMande *${prefix}sairgrupo* com os números dos grupos que quer sair.\n\n📝 Exemplo: *${prefix}sairgrupo 1 3 5*\n\n⚠️ Essa lista expira se você pedir uma nova antes de escolher.`))
      }

      // ── Com números: sai dos grupos escolhidos ──
      const listaSalva = ultimaListaPorDono.get(sender)
      if (!listaSalva) {
        return reply(caixaArlequina('sairgrupo', `❌ Nenhuma lista de grupos pendente.\n\nMande *${prefix}sairgrupo* sozinho primeiro pra ver a lista numerada.`))
      }

      await reagir('🚪')

      const saidas = []
      const falhas = []

      for (const n of numeros) {
        const groupJid = listaSalva[n - 1]
        if (!groupJid) {
          falhas.push(`${n} (número inválido)`)
          continue
        }
        try {
          let nomeGrupo = groupJid
          try {
            const meta = await sock.groupMetadata(groupJid)
            nomeGrupo = meta.subject
          } catch {}

          await sock.sendMessage(groupJid, {
            text: caixaArlequina('sairgrupo', `👋💜 *ATÉ MAIS!* 💜👋\n\nMe despeço desse grupo por aqui...\nFoi bom enquanto durou! 🃏\n\n_Saindo agora..._`)
          })
          await sock.groupLeave(groupJid)
          saidas.push(`${n}. ${nomeGrupo}`)
        } catch (e) {
          falhas.push(`${n} (erro: ${e?.message})`)
        }
      }

      ultimaListaPorDono.delete(sender)

      let resposta = `🚪💜 *SAÍDA DE GRUPOS* 💜🚪\n\n`
      if (saidas.length) resposta += `✅ Saiu de:\n${saidas.join('\n')}\n\n`
      if (falhas.length) resposta += `❌ Não conseguiu:\n${falhas.join('\n')}`

      await reply(caixaArlequina('sairgrupo', resposta.trim()))
    } catch (e) {
      console.log('❌ ERRO DONO (sairgrupo):', e?.message)
      await reply('❌ Não consegui executar esse comando agora.')
    }
  }
}
