
const fs = require('fs')
const axios = require('axios')
const { execFile } = require('child_process')
const crypto = require('crypto')
const {
  prepareWAMessageMedia,
  generateWAMessageFromContent,
  generateMessageIDV2,
  isJidGroup
} = require('@whiskeysockets/baileys')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

function nodeDoBotao(jid) {
  const nodes = [{
    tag: 'biz',
    attrs: {},
    content: [{
      tag: 'interactive',
      attrs: { type: 'native_flow', v: '1' },
      content: [{ tag: 'native_flow', attrs: { v: '9', name: 'mixed' } }]
    }]
  }]
  if (!isJidGroup(jid)) nodes.push({ tag: 'bot', attrs: { biz_bot: '1' } })
  return nodes
}

function ytRun(args, ms = 45000) {
  return new Promise((resolve, reject) => {
    execFile('yt-dlp', args, { timeout: ms, maxBuffer: 20 * 1024 * 1024 }, (err, stdout, stderr) => {
      if (err) {
        const detail = (stderr || stdout || err.message || '').trim()
        reject(new Error(detail.split('\n').filter(Boolean).slice(0, 3).join('\n')))
      } else resolve((stdout || '').trim())
    })
  })
}

function ytOk() {
  return new Promise(resolve =>
    execFile('yt-dlp', ['--version'], { timeout: 5000 }, err => resolve(!err))
  )
}

function unwrapMessage(m) {
  let msg = m?.message
  while (msg?.ephemeralMessage?.message || msg?.viewOnceMessage?.message ||
         msg?.viewOnceMessageV2?.message || msg?.documentWithCaptionMessage?.message) {
    msg = msg.ephemeralMessage?.message || msg.viewOnceMessage?.message ||
      msg.viewOnceMessageV2?.message || msg.documentWithCaptionMessage?.message
  }
  return msg || {}
}

function getSelectedRowId(msg) {
  const content = unwrapMessage(msg)
  const rowId = content.listResponseMessage?.singleSelectReply?.selectedRowId
  if (rowId) return String(rowId)
  const buttonId = content.buttonsResponseMessage?.selectedButtonId
  if (buttonId) return String(buttonId)
  const params = content.interactiveResponseMessage?.nativeFlowResponseMessage?.paramsJson
  if (params) {
    try {
      const parsed = JSON.parse(params)
      return String(parsed.id || parsed.row_id || parsed.selectedId || parsed.selectedRowId || '')
    } catch {}
  }
  return ''
}

async function getImage(url) {
  if (!url) return null
  try {
    const r = await axios.get(url, { responseType: 'arraybuffer', timeout: 12000 })
    return Buffer.from(r.data)
  } catch { return null }
}

function safeName(s) {
  return String(s || 'musica').replace(/[\\/:*?"<>|]/g, '').slice(0, 90)
}

async function sendAudio(arlequina, from, quoted, item, reply, reagir) {
  const tmpDir = './temp'
  if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true })
  const base = `${tmpDir}/play3_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`
  const output = `${base}.mp3`
  try {
    await reagir?.('⬇️')
    await reply(caixaArlequina('play', `╭─━━ 🃏💜 PLAY3 ━━─╮
┃ 🎵 *${item.title}*
┃ 🎤 *${item.channel}*
┃ ⬇️ Preparando áudio MP3...
╰━━━━━━━━━━━━━━━━╯`))
    await ytRun([
      '--no-warnings', '--no-playlist', '-x', '--audio-format', 'mp3',
      '--audio-quality', '128K', '-o', output, item.url
    ], 20 * 60 * 1000)
    if (!fs.existsSync(output)) throw new Error('O yt-dlp não gerou o MP3.')
    const stat = fs.statSync(output)
    if (stat.size > 64 * 1024 * 1024) throw new Error('O áudio ficou maior que o limite de 64 MB.')
    const buffer = fs.readFileSync(output)
    await arlequina.sendMessage(from, {
      audio: buffer,
      mimetype: 'audio/mpeg',
      ptt: false,
      fileName: `${safeName(item.title)}.mp3`
    }, { quoted })
    await reagir?.('✅')
  } catch (e) {
    await reply(`❌ Não consegui baixar essa música.\n${e.message}`)
  } finally {
    if (fs.existsSync(output)) try { fs.unlinkSync(output) } catch {}
    for (const ext of ['webm', 'm4a', 'opus', 'mp4']) {
      const f = `${base}.${ext}`
      if (fs.existsSync(f)) try { fs.unlinkSync(f) } catch {}
    }
  }
}

module.exports = {
  name: 'play3',
  description: '🎵 Pesquisa 10 músicas e envia a escolhida em áudio MP3',
  category: 'downloads',
  aliases: ['p3'],

  async execute({ arlequina, columbina, from, info, q, args, reply, reagir, sender }) {
    const pesquisa = String(q || (args || []).join(' ') || '').trim()
    if (!pesquisa) {
      return reply(caixaArlequina('play', '❌ Digite o nome do cantor ou artista.\n💡 Exemplo: *play3 MC Saci*'))
    }
    if (!await ytOk()) return reply('❌ yt-dlp não está instalado. Instale/atualize com: pip install -U yt-dlp')

    await reagir?.('🎵')
    await reply(caixaArlequina('play', `🔍 Pesquisando 10 músicas de *${pesquisa}*...\n💜🃏 Aguarde um instante.`))

    try {
      const term = `ytsearch10:${pesquisa.replace(/["\\]/g, '')}`
      const raw = await ytRun(['--no-warnings', '--dump-single-json', '--flat-playlist', term], 60000)
      let data
      try { data = JSON.parse(raw) } catch {
        const a = raw.indexOf('{'), b = raw.lastIndexOf('}')
        if (a < 0 || b <= a) throw new Error('Resposta de pesquisa inválida.')
        data = JSON.parse(raw.slice(a, b + 1))
      }

      const entries = (data.entries || []).filter(x => x && (x.id || x.url)).slice(0, 10)
      if (!entries.length) return reply(caixaArlequina('play', '❌ Não encontrei músicas para essa pesquisa.'))

      const items = entries.map((x, i) => ({
        id: x.id,
        url: x.url?.startsWith('http') ? x.url : `https://www.youtube.com/watch?v=${x.id}`,
        title: String(x.title || `Resultado ${i + 1}`).trim(),
        channel: String(x.channel || x.uploader || pesquisa).trim(),
        duration: Number(x.duration || 0),
        thumbnail: x.thumbnails?.slice(-1)[0]?.url || x.thumbnail || ''
      }))

      const artistImage = await getImage(items[0].thumbnail)
      const conn = columbina || arlequina
      const imageMedia = artistImage ? await prepareWAMessageMedia(
        { image: artistImage }, { upload: conn.waUploadToServer }
      ) : null

      const sessionId = crypto.randomBytes(8).toString('hex')
      const rows = items.map((item, i) => ({
        header: `🎧 FAIXA ${String(i + 1).padStart(2, '0')}`,
        title: item.title.slice(0, 72),
        description: `${item.channel}${item.duration ? ` • ${Math.floor(item.duration / 60)}:${String(item.duration % 60).padStart(2, '0')}` : ''}`.slice(0, 72),
        id: `arlequina_play3_${sessionId}_${i}`
      }))

      const body =
        `╭━━〔 🃏💜 *ARLEQUINA PLAY3* 💜🃏 〕━━╮\n` +
        `┃ 🎤 *ARTISTA PESQUISADO:*\n` +
        `┃ ${pesquisa}\n` +
        `┃ 🎶 *RESULTADOS:* ${items.length} músicas\n` +
        `┃ 🎧 *FORMATO:* Áudio MP3\n` +
        `┃ 🔊 *QUALIDADE:* 128 kbps\n` +
        `┃ 🌐 *FONTE:* YouTube\n` +
        `┃ 👥 *SELEÇÃO:* todos do grupo\n` +
        `┃ 🔁 *ESCOLHAS:* quantas quiser\n` +
        `┃\n` +
        `┃ 💜 Escolha uma faixa no botão abaixo.\n` +
        `┃ O menu permanece disponível por 30 min.\n` +
        `╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯`

      const payload = {
        interactiveMessage: {
          contextInfo: {
            stanzaId: info.key.id,
            participant: info.key.participant || info.key.remoteJid,
            quotedMessage: info.message
          },
          header: {
            hasMediaAttachment: !!imageMedia,
            ...(imageMedia ? { imageMessage: imageMedia.imageMessage } : {})
          },
          body: { text: body },
          footer: { text: '🃏💜 Arlequina Bot • Escolha sua música' },
          nativeFlowMessage: {
            buttons: [{
              name: 'single_select',
              buttonParamsJson: JSON.stringify({
                title: '🎵 ESCOLHA SUA MÚSICA',
                sections: [{ title: '10 músicas encontradas', rows }]
              })
            }]
          }
        }
      }

      // Mantém o listener ativo para múltiplas escolhas.
      const emitters = [...new Set([arlequina?.ev, columbina?.ev, conn?.ev].filter(Boolean))]
      const processadas = new Set()
      const emProcessamento = new Set()
      let timeout

      const cleanup = () => {
        clearTimeout(timeout)
        for (const emitter of emitters) {
          try { emitter.off('messages.upsert', onMessages) } catch {}
        }
      }

      const onMessages = async ({ messages }) => {
        for (const m of (messages || [])) {
          if (!m?.message || m.key?.remoteJid !== from || m.key?.fromMe) continue
          const selected = getSelectedRowId(m)
          const match = selected.match(/^arlequina_play3_([a-f0-9]+)_(\d+)$/i)
          if (!match || match[1] !== sessionId) continue

          const index = Number(match[2])
          if (!Number.isInteger(index) || !items[index]) continue

          const messageId = m.key?.id || `${selected}:${m.messageTimestamp || Date.now()}`
          if (processadas.has(messageId) || emProcessamento.has(messageId)) continue

          emProcessamento.add(messageId)
          try {
            await sendAudio(columbina || arlequina, from, m, items[index], reply, reagir)
            processadas.add(messageId)
          } catch (downloadError) {
            console.log('[play3] ERRO AO ENVIAR FAIXA:', downloadError?.message)
            await reply(`❌ Não consegui enviar *${items[index].title}*. Tente escolher novamente.`)
          } finally {
            emProcessamento.delete(messageId)
          }
        }
      }

      for (const emitter of emitters) emitter.on('messages.upsert', onMessages)
      timeout = setTimeout(cleanup, 30 * 60 * 1000)

      const generated = generateWAMessageFromContent(from, payload, {
        userJid: conn.user.id,
        messageId: generateMessageIDV2(conn.user.id)
      })

      try {
        await conn.relayMessage(from, generated.message, {
          messageId: generated.key.id,
          additionalNodes: nodeDoBotao(from)
        })
      } catch (sendError) {
        cleanup()
        throw sendError
      }
    } catch (e) {
      console.log('[play3] ERRO:', e?.message)
      await reply(`❌ Erro no PLAY3: ${e?.message || 'falha desconhecida'}`)
    }
  }
}

