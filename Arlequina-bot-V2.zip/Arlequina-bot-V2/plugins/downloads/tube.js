// ============================================================
//  plugins/download/tube.js
//  ARLEQUINA TUBE — busca, player, mp3 e vídeo (estilo YouTube)
//
//  !arlequinatube           abre o app: busca, lista e player DENTRO do card
//  !tube <busca>            lista os resultados (card roxo com abas, rolagem e ações)
//  !tube play <n ou nome>   player interativo (toca dentro do card)
//  !tube mp3 <n ou nome>    manda a música como áudio no chat
//  !tube baixar <n ou nome> manda como arquivo .mp3 (salvar / tocar em segundo plano)
//  !tube video <n ou nome>  manda o vídeo (até ~360p)
//  (botões)                 tocar na lista/botões faz tudo isso sem digitar
//  !tube teste              diagnóstico: o que o card e os botões conseguem fazer
//
//  Precisa no sistema:  yt-dlp  +  ffmpeg   |   Node 18 ou mais novo
// ============================================================

const { execFile, spawn } = require('child_process')
const http = require('http')
const crypto = require('crypto')
const { promisify } = require('util')
const fs = require('fs')
const os = require('os')
const path = require('path')

const execFileP = promisify(execFile)

// ---------- configurações ----------
const BOT_NAME = 'ARLEQUINA TUBE'
const VERSAO = 'v17'                 // aparece na mensagem "Abrindo..." para você conferir se o arquivo novo está rodando
const PREFIXO = '!'                  // prefixo mostrado nas dicas (se o bot informar o dele, usa o do bot)
const RESULTADOS = 10                // quantos resultados na lista

// ----- limites (0 = sem limite) -----
const MAX_SECONDS = 12 * 60          // só o PLAYER DO CARD: até 12 min toca no card (acima disso o bot manda o áudio no chat). Esse é o teto real: com o áudio no piso de qualidade (KBPS_MIN_CARD) o card já fica pertinho do CARD_MAX_KB; subir muito mais faz o WhatsApp descartar o card sem avisar.
const MAX_MP3_SECONDS = 0            // mp3 / baixar
const MAX_VIDEO_SECONDS = 0          // vídeo
const MAX_DOWNLOAD_MB = 0            // tamanho máximo que o yt-dlp baixa
const MAX_VIDEO_MB = 0               // tamanho máximo do vídeo
const AUDIO_INLINE_MB = 16           // até isso vai como áudio; acima vai como arquivo (sem recusar)
const VIDEO_INLINE_MB = 64           // até isso vai como vídeo; acima vai como arquivo (sem recusar)
const VIDEO_ALTURA_MAX = 720         // qualidade máxima do vídeo (360 / 480 / 720 / 1080)
const VIDEO_BUSCA_MAX_SECONDS = 30 * 60 // nas buscas por nome (!tubevd / !p2vd) prefere o 1º resultado com até isso; se não tiver, usa o 1º mesmo
const FILTRAR_MIXES = false          // true = esconde mixes/compilações muito longas das listas
const excede = (valor, limite) => limite > 0 && valor > limite

const TARGET_MB = 0.65               // peso do áudio dentro do card do player
const CARD_MAX_KB = 1250             // se o card final passar disso, o bot manda o áudio no chat (o WhatsApp descarta card pesado)
const KBPS_MIN_CARD = 9                // qualidade mínima do áudio no card (faixas de ~10 min ficam com som mais simples; o !tube mp3 continua em alta qualidade)
const CODEC_CARD = 'opus'            // 'opus' = mais leve e com som melhor (Android). 'mp3' = toca em qualquer aparelho, mas fica mais pesado
const EXIBICAO = 'inline'            // 'inline' = card na mensagem | 'sheet' = folha que sobe
// ----- modo APP: o "YouTube" inteiro dentro do card (busca, lista, player) -----
const APP_ATIVO = false              // false = modo lista + botões (funciona). true = app dentro do card (o WhatsApp está bloqueando a conexão; veja !tube teste2)
const APP_URL_PUBLICA = ''           // já tem uma URL https pública apontando para este bot? coloque aqui (sem / no fim)
const APP_PORTA = 0                  // 0 = escolhe uma porta livre
const APP_HOME = 'músicas mais tocadas'   // o que aparece ao abrir o app
const APP_LINK_DEBUG = true          // manda um link de teste do servidor no chat (para conferir no navegador)
const HOME_ALTURA = 620              // altura do card estilo YouTube (px)
const APP_WEB = false                // link do app no navegador (desligado)
const APP_ALTURA = 540               // altura do app dentro da mensagem (em px). Muito pequeno? aumente
const MAX_APP_SECONDS = 0            // música mais longa que o app toca (0 = sem limite)
const BOTOES_APOS_ACAO = true        // depois de cada ação, manda botões com as outras opções
const DEBUG = false                  // true = avisa no chat quando o card é enviado

// mesmos domínios confiáveis do plugin piano
const TRUSTED = ['columbina-apis.onrender.com']

// O YouTube exige um runtime JavaScript no yt-dlp (senão dá erro 403).
const YTDLP_BASE = [
  '--js-runtimes', 'node:' + process.execPath,
  '--remote-components', 'ejs:github',
  '--no-warnings',
]

// Se o YouTube responder "Sign in to confirm you're not a bot", exporte os cookies do navegador
// (formato Netscape, extensão "Get cookies.txt") e salve como cookies.txt na MESMA pasta deste arquivo.
// Depois é só reiniciar o bot. (Ou coloque o caminho do arquivo em COOKIES_ARQ.)
const COOKIES_ARQ = ''
const cookiesPath = COOKIES_ARQ || path.join(__dirname, 'cookies.txt')
if (fs.existsSync(cookiesPath)) {
  YTDLP_BASE.push('--cookies', cookiesPath)
  console.log('[tube] usando cookies do YouTube: ' + cookiesPath)
}

// últimos resultados de busca por chat (para o "!tube play 1")
// Estado compartilhado: se o bot carregar este arquivo mais de uma vez (ou trocar o objeto da conexão
// a cada comando), tudo continua num lugar só e o ouvinte não é instalado em duplicidade.
const G = (globalThis.__arltube = globalThis.__arltube || {
  ultimas: new Map(),
  cacheVideos: new Map(),
  homeCache: { ts: 0, dados: null },
  ouvinte: { ev: null, handler: null, sock: null, ativo: false, pendentes: new Map(), esperando: new Map(), vistos: new Set() },
})
const ultimas = G.ultimas
const VALIDADE_MS = 30 * 60 * 1000

// vídeos já vistos (os botões usam o ID do vídeo, que não muda entre buscas)
const cacheVideos = G.cacheVideos
function guardarVideo(v) {
  cacheVideos.set(v.id, { ...v, ts: Date.now() })
  if (cacheVideos.size > 300) cacheVideos.delete(cacheVideos.keys().next().value)
}
function pegarVideo(id) {
  const v = cacheVideos.get(id)
  return v && Date.now() - v.ts < 2 * 60 * 60 * 1000 ? v : null
}

// ---------- utilidades ----------
const esc = (s) =>
  String(s ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')

const jsStr = (s) => JSON.stringify(String(s ?? '')).replace(/</g, '\\u003c')

function fmtTime(sec) {
  sec = Math.max(0, Math.floor(sec || 0))
  return Math.floor(sec / 60) + ':' + String(sec % 60).padStart(2, '0')
}

function pickQuery(ctx) {
  const cands = [
    ctx.text,
    ctx.q,
    ctx.query,
    ctx.texto,
    Array.isArray(ctx.args) ? ctx.args.join(' ') : ctx.args,
  ]
  const found = cands.find((v) => typeof v === 'string' && v.trim())
  if (found) return found.trim()

  // último recurso: tira a 1ª palavra (o comando) do corpo da mensagem
  if (typeof ctx.body === 'string' && ctx.body.trim()) {
    return ctx.body.trim().split(/\s+/).slice(1).join(' ').trim()
  }
  return ''
}

// bitrate escolhido para o áudio caber no peso alvo
function pickKbps(seconds) {
  if (!seconds) return 64
  const k = Math.floor((TARGET_MB * 1024 * 1024 * 8) / seconds / 1000)
  return Math.max(32, Math.min(96, k))
}

// ---------- busca / download ----------
async function searchVideos(query, n = 1) {
  const { stdout } = await execFileP(
    'yt-dlp',
    [...YTDLP_BASE, `ytsearch${n}:` + query, '--flat-playlist', '--dump-json'],
    { timeout: 60000, maxBuffer: 50 * 1024 * 1024 }
  )
  const lista = stdout
    .split('\n')
    .filter((l) => l.trim().startsWith('{'))
    .map((l) => {
      try {
        const j = JSON.parse(l)
        if (!j.id) return null
        return {
          id: j.id,
          title: j.title || 'Sem título',
          author: j.uploader || j.channel || 'YouTube',
          seconds: j.duration ? Math.round(j.duration) : 0,
          views: Number.isFinite(j.view_count) ? j.view_count : null,
          url: j.webpage_url || j.url || 'https://www.youtube.com/watch?v=' + j.id,
        }
      } catch {
        return null
      }
    })
    .filter(Boolean)
  lista.forEach(guardarVideo)
  return lista
}

// formata visualizações reais (nunca inventa número); null/indisponível = não mostra nada
function fmtViews(v) {
  if (!Number.isFinite(v) || v < 0) return ''
  if (v >= 1000000) return (v / 1000000).toFixed(v >= 10000000 ? 0 : 1).replace('.0', '') + 'mi visualizações'
  if (v >= 1000) return Math.round(v / 1000) + 'mil visualizações'
  return v + ' visualizações'
}

// Quando o YouTube pede "Sign in to confirm you're not a bot", trocar o "cliente" do yt-dlp costuma resolver.
// Cada tentativa usa um cliente diferente (null = o padrão do yt-dlp).
const CLIENTES_YT = [null, 'android_vr', 'tv', 'mweb']
const clienteArgs = (c) => (c ? ['--extractor-args', `youtube:player_client=${c}`] : [])
const ehBloqueio = (e) => /sign in to confirm|not a bot|confirm you.?re not/i.test(String((e && e.stderr) || (e && e.message) || e))

function limparArquivos(dir, prefixo) {
  try {
    for (const f of fs.readdirSync(dir)) if (f.startsWith(prefixo)) fs.rmSync(path.join(dir, f), { force: true })
  } catch {}
}

async function baixarAudioBruto(url, dir) {
  const tentativas = [
    ...CLIENTES_YT.map((c) => ({ c, f: 'bestaudio/best' })),
    { c: null, f: 'bestaudio[ext=m4a]/bestaudio/best' },
  ]
  let ultimoErro
  for (const t of tentativas) {
    try {
      limparArquivos(dir, 'raw.')
      await execFileP(
        'yt-dlp',
        [
          ...YTDLP_BASE,
          ...clienteArgs(t.c),
          '-f', t.f,
          '--no-playlist',
          ...(MAX_DOWNLOAD_MB > 0 ? ['--max-filesize', MAX_DOWNLOAD_MB + 'M'] : []),
          '-o', path.join(dir, 'raw.%(ext)s'),
          url,
        ],
        { timeout: 3600000, maxBuffer: 20 * 1024 * 1024 }
      )
      ultimoErro = null
      if (t.c) console.log('[tube] download ok com o cliente ' + t.c)
      break
    } catch (e) {
      ultimoErro = e
      console.error(`[tube] tentativa (${t.c || 'padrão'}) falhou: ${String((e && e.stderr) || e.message).split('\n').filter((l) => /error/i.test(l)).pop() || e.message}`)
    }
  }
  if (ultimoErro) throw ultimoErro
  const raw = fs.readdirSync(dir).find((f) => f.startsWith('raw.'))
  if (!raw) throw new Error('Áudio não foi baixado')
  return path.join(dir, raw)
}

// converte para mp3 (com capa e tags, se pedir)
async function encodeMp3(rawFile, out, { kbps, mono, ar, title, artist, coverFile }) {
  const comCapa = coverFile && fs.existsSync(coverFile)
  const args = ['-y', '-i', rawFile]
  if (comCapa) args.push('-i', coverFile)
  args.push('-map', '0:a:0')
  if (comCapa) {
    args.push('-map', '1:v:0', '-c:v', 'mjpeg', '-id3v2_version', '3',
      '-metadata:s:v', 'title=Capa', '-metadata:s:v', 'comment=Cover (front)')
  } else {
    args.push('-vn')
  }
  args.push('-ac', mono ? '1' : '2', '-ar', String(ar), '-c:a', 'libmp3lame', '-b:a', kbps + 'k')
  if (title) args.push('-metadata', 'title=' + title)
  if (artist) args.push('-metadata', 'artist=' + artist)
  args.push(out)
  await execFileP('ffmpeg', args, { timeout: 3600000, maxBuffer: 20 * 1024 * 1024 })
  return out
}

// áudio do card: opus em ogg (bem menor que mp3 na mesma qualidade); se o ffmpeg não tiver opus, cai no mp3
async function audioParaCard(raw, dir, seconds) {
  if (CODEC_CARD === 'opus') {
    const kbps = Math.max(KBPS_MIN_CARD, Math.min(32, Math.floor((TARGET_MB * 1024 * 1024 * 8) / Math.max(1, seconds || 180) / 1000)))
    const out = path.join(dir, 'small.ogg')
    try {
      await execFileP(
        'ffmpeg',
        ['-y', '-i', raw, '-vn', '-ac', '1', '-ar', '48000', '-c:a', 'libopus', '-b:a', kbps + 'k', '-vbr', 'on', '-application', 'audio', '-f', 'ogg', out],
        { timeout: 3600000, maxBuffer: 20 * 1024 * 1024 }
      )
      if (fs.existsSync(out) && fs.statSync(out).size > 1000) return out
    } catch (e) {
      console.error('[tube] opus indisponível, usando mp3:', String((e && e.stderr) || e.message).split('\n').pop())
    }
  }
  return mp3Pequeno(raw, dir, seconds)
}

// mp3 leve para ir dentro do card
async function mp3Pequeno(raw, dir, seconds) {
  const kbps = pickKbps(seconds)
  return encodeMp3(raw, path.join(dir, 'small.mp3'), {
    kbps,
    mono: true,
    ar: kbps >= 64 ? 44100 : 32000,
  })
}

// mp3 bom (128k estéreo, com capa) para mandar/baixar
async function mp3Completo(raw, dir, video, coverFile) {
  const out = path.join(dir, 'full.mp3')
  const opts = { kbps: 128, mono: false, ar: 44100, title: video.title, artist: video.author }
  try {
    return await encodeMp3(raw, out, { ...opts, coverFile })
  } catch (e) {
    console.error('[tube] falhou com capa, refazendo sem capa:', e.message)
    return encodeMp3(raw, out, opts)
  }
}

// vídeo mp4 (qualidade limitada só por VIDEO_ALTURA_MAX)
async function baixarVideo(url, dir) {
  const h = VIDEO_ALTURA_MAX
  // do melhor (H.264 + AAC) para o mais permissivo; o WhatsApp só toca H.264, então o que vier diferente é convertido depois
  const F1 = `bv*[height<=${h}][vcodec^=avc1]+ba[ext=m4a]/b[height<=${h}][ext=mp4]`
  const F2 = '18'
  const F3 = `bv*[height<=${h}]+ba/b[height<=${h}]`
  const F4 = 'b'
  const tentativas = []
  for (const f of [F1, F2, F3, F4]) tentativas.push({ c: null, f })
  for (const c of CLIENTES_YT.filter(Boolean)) for (const f of [F1, F4]) tentativas.push({ c, f })

  const linhaErro = (e) =>
    String((e && e.stderr) || (e && e.message) || e)
      .split('\n')
      .filter((l) => /error/i.test(l))
      .pop() || String((e && e.message) || e).split('\n')[0]

  let ultimoErro
  for (const t of tentativas) {
    try {
      limparArquivos(dir, 'video.')
      await execFileP(
        'yt-dlp',
        [
          ...YTDLP_BASE,
          ...clienteArgs(t.c),
          '-f', t.f,
          '--merge-output-format', 'mp4',
          '--no-playlist',
          ...(MAX_VIDEO_MB > 0 ? ['--max-filesize', MAX_VIDEO_MB + 'M'] : []),
          '-o', path.join(dir, 'video.%(ext)s'),
          url,
        ],
        { timeout: 3600000, maxBuffer: 20 * 1024 * 1024 }
      )
      ultimoErro = null
      break
    } catch (e) {
      ultimoErro = e
      console.error(`[tube] vídeo: tentativa (${t.c || 'padrão'} | ${t.f.slice(0, 28)}) falhou: ${linhaErro(e).slice(0, 160)}`)
      // vídeo privado/removido: não adianta tentar de novo
      if (/video unavailable|private video|members-only|not available in your country|has been removed|copyright/i.test(linhaErro(e))) break
    }
  }
  if (ultimoErro) throw ultimoErro
  const f = fs.readdirSync(dir).find((x) => x.startsWith('video.'))
  if (!f) throw new Error('Vídeo não foi baixado')
  let file = path.join(dir, f)

  // se não veio em mp4, converte para um formato que o WhatsApp toca
  if (!/\.mp4$/i.test(file)) {
    const out = path.join(dir, 'video_wa.mp4')
    await execFileP(
      'ffmpeg',
      ['-y', '-i', file, '-vf', `scale=-2:'min(ih,${h})'`, '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '26',
        '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-b:a', '128k', '-movflags', '+faststart', out],
      { timeout: 3600000, maxBuffer: 20 * 1024 * 1024 }
    )
    file = out
  }
  return file
}

// miniatura pequena (168x94) em base64 para a lista
async function makeThumb(id, dir, w = 168, h = 94, q = 7) {
  const src = path.join(dir, `t_${id}.jpg`)
  const out = path.join(dir, `t_${id}_s.jpg`)
  try {
    const res = await fetch(`https://i.ytimg.com/vi/${id}/mqdefault.jpg`)
    if (!res.ok) return null
    fs.writeFileSync(src, Buffer.from(await res.arrayBuffer()))
    await execFileP('ffmpeg', ['-y', '-i', src, '-vf', `scale=${w}:${h}`, '-q:v', String(q), out])
    return 'data:image/jpeg;base64,' + fs.readFileSync(out).toString('base64')
  } catch {
    return null
  }
}

async function probeSeconds(file) {
  try {
    const { stdout } = await execFileP('ffprobe', [
      '-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', file,
    ])
    return Math.round(parseFloat(stdout) || 0)
  } catch {
    return 0
  }
}

// capa quadrada 480x480 em base64 (recorte do centro da miniatura)
async function makeCover(id, dir) {
  const urls = [
    `https://i.ytimg.com/vi/${id}/maxresdefault.jpg`,
    `https://i.ytimg.com/vi/${id}/hq720.jpg`,
    `https://i.ytimg.com/vi/${id}/mqdefault.jpg`,
  ]
  const src = path.join(dir, 'cover_src.jpg')
  const out = path.join(dir, 'cover.jpg')
  for (const u of urls) {
    try {
      const res = await fetch(u)
      if (!res.ok) continue
      fs.writeFileSync(src, Buffer.from(await res.arrayBuffer()))
      break
    } catch {}
  }
  if (!fs.existsSync(src)) return null
  try {
    await execFileP('ffmpeg', [
      '-y', '-i', src,
      '-vf', "crop='min(iw,ih)':'min(iw,ih)',scale=400:400",
      '-q:v', '6', out,
    ])
    return 'data:image/jpeg;base64,' + fs.readFileSync(out).toString('base64')
  } catch {
    return null
  }
}

// ---------- HTML do player ----------
function buildHtml({ title, author, seconds, cover, audioB64, inline }) {
  const grad = 'repeating-linear-gradient(45deg, rgba(255,255,255,.035) 0 22px, transparent 22px 44px), repeating-linear-gradient(-45deg, rgba(255,255,255,.035) 0 22px, transparent 22px 44px), linear-gradient(180deg, #4b1a7a 0%, #21093f 55%, #0d0219 100%)'
  const bodyBg = inline ? '#202c33' : '#0d0219'
  const cardCss = inline
    ? `width: 88%; margin: 14px auto; padding: 16px 16px 20px; border-radius: 22px; background: ${grad};`
    : `min-height: 100vh; padding: 18px 20px 22px; background: ${grad};`
  const idle = BOT_NAME + ' • toque em ▶ para iniciar'
  const playing = BOT_NAME + ' • tocando'

  return `<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<style>
  * { box-sizing: border-box; -webkit-tap-highlight-color: transparent; }
  html, body { margin: 0; padding: 0; background: ${bodyBg}; color: #fff; font-family: Arial, Helvetica, sans-serif; overflow-x: hidden; }
  .card { ${cardCss} }
  svg { display: block; }
  .top { display: flex; align-items: center; justify-content: space-between; height: 40px; }
  .top .mid { text-align: center; line-height: 1.3; }
  .top small { display: block; font-size: 10px; letter-spacing: 1.6px; color: #cdb6f0; }
  .top b { font-size: 14px; }
  .cover { width: 100%; aspect-ratio: 1 / 1; border-radius: 14px; overflow: hidden; margin: 16px 0 22px; background: #2a0f4a; box-shadow: 0 12px 30px rgba(0,0,0,.5); }
  .cover img { width: 100%; height: 100%; object-fit: cover; display: block; }
  .info { display: flex; align-items: center; justify-content: space-between; gap: 12px; }
  .info .t { min-width: 0; }
  .title { font-size: 22px; font-weight: bold; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .sub { font-size: 14px; color: #b9a2e0; margin-top: 4px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .lyric { font-size: 12px; color: #cbb6ee; margin: 40px 0 20px; }
  .bar { position: relative; height: 24px; touch-action: none; cursor: pointer; }
  .track { position: absolute; left: 0; right: 0; top: 10px; height: 4px; border-radius: 2px; background: rgba(255,255,255,.3); }
  .fill { position: absolute; left: 0; top: 10px; height: 4px; border-radius: 2px; background: #fff; width: 0; }
  .knob { position: absolute; top: 5px; left: 0; width: 14px; height: 14px; border-radius: 50%; background: #fff; transform: translateX(-50%); }
  .times { display: flex; justify-content: space-between; font-size: 12px; color: #e0d3f7; margin-top: 2px; }
  .ctrl { display: flex; align-items: center; justify-content: space-between; margin-top: 20px; }
  .ib { background: none; border: 0; padding: 8px; color: #cdb6f0; }
  .play { width: 68px; height: 68px; border-radius: 50%; background: #fff; border: 0; display: flex; align-items: center; justify-content: center; padding: 0; }
  .foot { text-align: center; font-size: 11px; color: #a58ad6; margin-top: 18px; min-height: 14px; }
</style>
</head>
<body>
<div class="card">
  <div class="top">
    <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
    <div class="mid"><small>ARLEQUINA TUBE</small><b>Tocando agora</b></div>
    <svg width="26" height="26" viewBox="0 0 24 24" fill="#fff"><circle cx="12" cy="5" r="2"/><circle cx="12" cy="12" r="2"/><circle cx="12" cy="19" r="2"/></svg>
  </div>

  <div class="cover">${cover ? '<img src="' + cover + '" alt="">' : ''}</div>

  <div class="info">
    <div class="t">
      <div class="title">${esc(title)}</div>
      <div class="sub">${esc(author)}</div>
    </div>
    <button class="ib" id="hb" style="color:#fff">
      <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linejoin="round" id="hp"><path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1-1.1a5.5 5.5 0 0 0-7.8 7.8l1 1.1L12 21l7.8-7.5 1-1.1a5.5 5.5 0 0 0 0-7.8z"/></svg>
    </button>
  </div>

  <div class="lyric">Letra ainda não disponível para esta música.</div>

  <div class="bar" id="bar">
    <div class="track"></div>
    <div class="fill" id="fill"></div>
    <div class="knob" id="knob"></div>
  </div>
  <div class="times"><span id="cur">0:00</span><span id="tot">${fmtTime(seconds)}</span></div>

  <div class="ctrl">
    <button class="ib" tabindex="-1">
      <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg>
    </button>
    <button class="ib" id="back">
      <svg width="34" height="34" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"/><text x="12" y="15.2" font-size="7" font-weight="bold" text-anchor="middle" fill="currentColor" stroke="none">10</text></svg>
    </button>
    <button class="play" id="pb"><span id="ic"></span></button>
    <button class="ib" id="fwd">
      <svg width="34" height="34" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/><text x="12" y="15.2" font-size="7" font-weight="bold" text-anchor="middle" fill="currentColor" stroke="none">10</text></svg>
    </button>
    <button class="ib" id="rp">
      <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="17 1 21 5 17 9"/><path d="M3 11V9a4 4 0 0 1 4-4h14"/><polyline points="7 23 3 19 7 15"/><path d="M21 13v2a4 4 0 0 1-4 4H3"/></svg>
    </button>
  </div>

  <div class="foot" id="foot">${esc(idle)}</div>
</div>

<script>
(function () {
  var TOTAL = ${Number(seconds) || 0};
  var B64 = "${audioB64}";

  var pb = document.getElementById('pb');
  var ic = document.getElementById('ic');
  var fill = document.getElementById('fill');
  var knob = document.getElementById('knob');
  var cur = document.getElementById('cur');
  var tot = document.getElementById('tot');
  var bar = document.getElementById('bar');
  var foot = document.getElementById('foot');
  var FOOT_IDLE = ${jsStr(idle)};
  var FOOT_PLAY = ${jsStr(playing)};
  var PLAY = '<svg width="32" height="32" viewBox="0 0 24 24"><polygon points="8 4 20 12 8 20" fill="#1a0533"/></svg>';
  var PAUSE = '<svg width="32" height="32" viewBox="0 0 24 24"><rect x="6" y="4" width="4" height="16" rx="1" fill="#1a0533"/><rect x="14" y="4" width="4" height="16" rx="1" fill="#1a0533"/></svg>';

  var ctx = null, buf = null, src = null, loading = null;
  var playing = false, offset = 0, startedAt = 0, loop = false;

  function fmt(s) {
    s = Math.max(0, Math.floor(s || 0));
    var r = s % 60;
    return Math.floor(s / 60) + ':' + (r < 10 ? '0' : '') + r;
  }
  function dur() { return buf ? buf.duration : TOTAL; }
  function pos() {
    if (!playing) return offset;
    var d = dur() || 1;
    var t = offset + (ctx.currentTime - startedAt);
    if (loop) t = t % d;
    return Math.min(t, d);
  }
  function upd() {
    var t = pos();
    var d = dur() || 1;
    var p = Math.min(100, Math.max(0, (t / d) * 100));
    fill.style.width = p + '%';
    knob.style.left = p + '%';
    cur.textContent = fmt(t);
    tot.textContent = fmt(d);
  }
  function icon() {
    ic.innerHTML = playing ? PAUSE : PLAY;
    foot.textContent = playing ? FOOT_PLAY : FOOT_IDLE;
  }

  function getCtx() {
    if (!ctx) {
      var AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return null;
      ctx = new AC();
    }
    return ctx;
  }

  // decodifica o áudio embutido (1x)
  function load() {
    if (loading) return loading;
    loading = new Promise(function (resolve, reject) {
      var c = getCtx();
      if (!c) { reject(new Error('sem suporte a áudio')); return; }
      var bin = atob(B64);
      var n = bin.length;
      var u8 = new Uint8Array(n);
      for (var i = 0; i < n; i++) u8[i] = bin.charCodeAt(i);
      var done = false;
      function ok(b) { if (done) return; done = true; buf = b; resolve(b); }
      function bad(e) { if (done) return; done = true; reject(e || new Error('falha ao decodificar')); }
      var p = c.decodeAudioData(u8.buffer, ok, bad);
      if (p && p.then) p.then(ok, bad);
    });
    return loading;
  }

  function stopSrc() {
    if (src) {
      src.onended = null;
      try { src.stop(); } catch (e) {}
      try { src.disconnect(); } catch (e) {}
      src = null;
    }
  }

  function startAt(t) {
    stopSrc();
    var s = ctx.createBufferSource();
    s.buffer = buf;
    s.loop = loop;
    s.connect(ctx.destination);
    s.onended = function () {
      if (src === s) { src = null; playing = false; offset = 0; upd(); icon(); }
    };
    src = s;
    offset = t;
    startedAt = ctx.currentTime;
    s.start(0, t);
    playing = true;
    icon();
  }

  function seekTo(t) {
    var d = dur();
    t = Math.max(0, t);
    if (d) t = Math.min(t, Math.max(0, d - 0.05));
    if (playing && buf) { startAt(t); } else { offset = t; }
    upd();
  }

  pb.addEventListener('click', function () {
    if (playing) {
      offset = pos();
      stopSrc();
      playing = false;
      icon();
      upd();
      return;
    }
    var c = getCtx();
    if (!c) { foot.textContent = 'Áudio não suportado neste aparelho'; return; }
    if (c.state === 'suspended' && c.resume) c.resume();
    foot.textContent = 'Carregando áudio...';
    load().then(function () {
      if (c.state === 'suspended' && c.resume) c.resume();
      startAt(buf && offset >= buf.duration - 0.1 ? 0 : offset);
    }).catch(function (e) {
      loading = null;
      foot.textContent = 'Erro no áudio: ' + (e && e.message ? e.message : 'falha');
    });
  });

  document.getElementById('back').addEventListener('click', function () { seekTo(pos() - 10); });
  document.getElementById('fwd').addEventListener('click', function () { seekTo(pos() + 10); });

  var rp = document.getElementById('rp');
  rp.addEventListener('click', function () {
    loop = !loop;
    if (src) src.loop = loop;
    rp.style.color = loop ? '#ffffff' : '#cdb6f0';
  });

  var liked = false;
  var hp = document.getElementById('hp');
  document.getElementById('hb').addEventListener('click', function () {
    liked = !liked;
    hp.setAttribute('fill', liked ? '#ff4fd8' : 'none');
    hp.setAttribute('stroke', liked ? '#ff4fd8' : '#ffffff');
  });

  var drag = false;
  function seekEvent(e) {
    var r = bar.getBoundingClientRect();
    var p = Math.min(1, Math.max(0, (e.clientX - r.left) / r.width));
    seekTo(p * dur());
  }
  bar.addEventListener('pointerdown', function (e) {
    drag = true;
    if (bar.setPointerCapture) bar.setPointerCapture(e.pointerId);
    seekEvent(e);
  });
  bar.addEventListener('pointermove', function (e) { if (drag) seekEvent(e); });
  bar.addEventListener('pointerup', function () { drag = false; });
  bar.addEventListener('pointercancel', function () { drag = false; });

  setInterval(upd, 250);
  icon();
  upd();

  // já vai decodificando em segundo plano para começar rápido ao tocar
  setTimeout(function () { load().catch(function () { loading = null; }); }, 300);
})();
</script>
</body>
</html>`
}

// ---------- home estilo YouTube: dados ----------
async function mapLimit(arr, limite, fn) {
  const out = new Array(arr.length)
  let i = 0
  await Promise.all(
    Array.from({ length: Math.min(limite, arr.length) }, async () => {
      while (i < arr.length) {
        const k = i++
        out[k] = await fn(arr[k], k)
      }
    })
  )
  return out
}

// tira mixes/compilações enormes e vídeos curtíssimos (só se sobrar coisa boa)
function filtrarMusicas(items) {
  if (!FILTRAR_MIXES) return items
  const ok = items.filter((v) => !v.seconds || (v.seconds >= 45 && v.seconds <= 15 * 60))
  return ok.length >= 3 ? ok : items
}

const HOME_SECOES = [
  { nome: 'Em alta', q: APP_HOME, n: 10 },
  { nome: 'Funk', q: 'funk músicas mais tocadas', n: 6 },
  { nome: 'Sertanejo', q: 'sertanejo músicas mais tocadas', n: 6 },
  { nome: 'Pop', q: 'pop músicas mais tocadas', n: 6 },
  { nome: 'Rap', q: 'rap nacional músicas mais tocadas', n: 6 },
  { nome: 'Pagode', q: 'pagode músicas mais tocadas', n: 6 },
]

async function carregarHome(dir) {
  if (G.homeCache.dados && Date.now() - G.homeCache.ts < 20 * 60 * 1000) return G.homeCache.dados
  const secoes = await mapLimit(HOME_SECOES, 3, async (sec) => {
    const bruto = await searchVideos(sec.q, sec.n + 8)
    return { nome: sec.nome, items: filtrarMusicas(bruto).slice(0, sec.n) }
  })
  const ids = [...new Set(secoes.flatMap((sec) => sec.items.map((v) => v.id)))]
  const thumbs = {}
  await mapLimit(ids, 6, async (id) => {
    thumbs[id] = await makeThumb(id, dir, 288, 162, 8)
  })
  G.homeCache = { ts: Date.now(), dados: { secoes, thumbs } }
  return G.homeCache.dados
}

// ---------- card estilo YouTube (feed, prateleiras, tela do vídeo, busca) ----------
function buildYouTubeHtml({ secoes, thumbs, inline, prefixo, titulo, busca, consulta }) {
  const bodyBg = inline ? '#202c33' : '#0d0219'
  const altura = inline ? HOME_ALTURA + 'px' : '100vh'
  const dados = secoes.map((sec) => ({
    nome: sec.nome,
    itens: sec.items.map((v) => ({ id: v.id, t: v.title, a: v.author, d: v.seconds || 0, vw: v.views ?? null })),
  }))
  const seguro = (obj) => JSON.stringify(obj).replace(/</g, '\\u003c')

  return `<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<style>
  * { box-sizing: border-box; -webkit-tap-highlight-color: transparent; }
  html, body { margin: 0; padding: 0; background: ${bodyBg}; color: #fff; font-family: -apple-system, "Segoe UI", Roboto, Arial, sans-serif; overflow: hidden; }
  button { font-family: inherit; }
  @keyframes rise { from { opacity: 0; transform: translateY(12px); } to { opacity: 1; transform: none; } }
  .app { position: relative; height: ${altura}; display: flex; flex-direction: column; background: ${GRAD_NEON}; overflow: hidden; }
  .fab { position: absolute; right: 10px; bottom: 66px; display: flex; flex-direction: column; gap: 8px; z-index: 6; }
  .fab button { width: 40px; height: 40px; border-radius: 50%; border: 1px solid rgba(255,255,255,.35); background: linear-gradient(135deg, #7b2ff7, #c13cff); color: #fff; font-size: 15px; box-shadow: 0 0 16px rgba(193,60,255,.7), 0 4px 10px rgba(0,0,0,.4); }
  .fab button:active { transform: scale(.92); }
  .top { display: flex; align-items: center; gap: 10px; padding: 12px 14px 2px; flex: none; }
  .top svg { filter: drop-shadow(0 0 7px #c13cff); flex: none; }
  .top b { flex: 1; font-size: 15px; font-weight: 800; letter-spacing: 1.4px; background: linear-gradient(90deg, #f0d4ff, #ff7ad9); -webkit-background-clip: text; background-clip: text; -webkit-text-fill-color: transparent; color: transparent; }
  .tagline { padding: 0 14px 8px 44px; margin-top: -4px; font-size: 10px; letter-spacing: .4px; color: #d9c2ff; flex: none; }
  .ib { background: rgba(255,255,255,.08); border: 1px solid rgba(193,60,255,.35); color: #e9d7ff; font-size: 16px; padding: 6px 12px; border-radius: 12px; }
  .chips { display: flex; gap: 8px; overflow-x: auto; white-space: nowrap; padding: 2px 14px 10px; flex: none; }
  .chip { flex: none; padding: 7px 14px; border: 1px solid rgba(193,60,255,.4); border-radius: 999px; background: rgba(255,255,255,.07); color: #ead9ff; font-size: 12px; font-weight: 600; }
  .chip.on { background: linear-gradient(90deg, #7b2ff7, #ff2d75); border-color: transparent; color: #fff; box-shadow: 0 0 16px rgba(193,60,255,.7); }
  .ttl { font-size: 12px; color: #d9c2ff; padding: 0 14px 8px; flex: none; letter-spacing: .3px; }
  .sbar { display: flex; gap: 8px; padding: 0 14px 8px; flex: none; }
  .sbar input { flex: 1; min-width: 0; padding: 11px 14px; border-radius: 999px; }
  .go { width: 44px; border: 0; border-radius: 999px; background: linear-gradient(90deg, #7b2ff7, #c13cff); color: #fff; font-size: 16px; box-shadow: 0 0 14px rgba(193,60,255,.6); }
  .pane { display: none; flex: 1; min-height: 0; flex-direction: column; }
  .pane.on { display: flex; }
  .scroll { flex: 1; overflow-y: auto; -webkit-overflow-scrolling: touch; overscroll-behavior: contain; padding-bottom: 14px; scroll-behavior: smooth; }
  .vc { margin: 0 14px 16px; border-radius: 18px; overflow: hidden; background: rgba(255,255,255,.05); border: 1px solid rgba(193,60,255,.30); box-shadow: 0 8px 24px rgba(0,0,0,.35); animation: rise .45s ease both; }
  .vc:active { transform: scale(.985); }
  .vc.hero { border-color: rgba(255,122,217,.6); box-shadow: 0 0 24px rgba(193,60,255,.5), 0 10px 28px rgba(0,0,0,.45); display: flex; align-items: stretch; }
  .vc.hero .vt { width: 42%; flex: none; aspect-ratio: auto; }
  .vc.hero .vi { flex: 1; min-width: 0; padding: 12px 12px 12px 0; display: flex; flex-direction: column; justify-content: center; gap: 3px; }
  .vc.hero .vtt { font-size: 15px; -webkit-line-clamp: 3; }
  .vc.hero .vw { font-size: 11px; color: #b9a2e0; }
  .heroplay { width: 40px; height: 40px; border-radius: 50%; border: 0; background: linear-gradient(135deg, #7b2ff7, #ff2d75); color: #fff; font-size: 15px; display: flex; align-items: center; justify-content: center; padding-left: 2px; margin-top: 6px; box-shadow: 0 0 14px rgba(255,45,117,.6); }
  .vt { position: relative; width: 100%; aspect-ratio: 16 / 9; background: #2a0f4a; overflow: hidden; }
  .vt img { position: relative; width: 100%; height: 100%; object-fit: cover; display: block; }
  .vc .vt::before { content: ""; position: absolute; left: 0; right: 0; bottom: 0; height: 45%; background: linear-gradient(transparent, rgba(13,2,25,.78)); z-index: 1; pointer-events: none; }
  .vc .vt::after { content: "▶"; position: absolute; left: 50%; top: 50%; transform: translate(-50%, -50%); width: 52px; height: 52px; border-radius: 50%; background: rgba(20,4,40,.55); border: 1px solid rgba(255,255,255,.4); display: flex; align-items: center; justify-content: center; font-size: 19px; padding-left: 3px; box-shadow: 0 0 18px rgba(193,60,255,.6); z-index: 2; pointer-events: none; }
  #w-vt::after, #w-vt::before { display: none; }
  .dur { position: absolute; right: 8px; bottom: 8px; background: rgba(0,0,0,.72); border: 1px solid rgba(255,255,255,.18); font-size: 11px; font-weight: 700; padding: 2px 7px; border-radius: 999px; z-index: 3; }
  .tag { position: absolute; left: 10px; top: 10px; padding: 4px 10px; border-radius: 999px; font-size: 10px; font-weight: 800; letter-spacing: .6px; background: linear-gradient(90deg, #ff2d75, #c13cff); box-shadow: 0 0 14px rgba(255,45,117,.7); z-index: 3; }
  .vi { padding: 10px 12px 12px; }
  .vtt { font-size: 14px; font-weight: 700; line-height: 1.28; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
  .vch { font-size: 12px; color: #c4a9f2; margin-top: 4px; }
  .sh { font-size: 14px; font-weight: 800; padding: 6px 14px 10px; letter-spacing: .3px; }
  .sh::before { content: "◆"; color: #ff7ad9; margin-right: 8px; text-shadow: 0 0 10px #ff2d75; }
  .mut { font-weight: 400; font-size: 11px; color: #b9a2e0; }
  .car { display: flex; gap: 12px; overflow-x: auto; padding: 0 14px 16px; }
  .sc { flex: none; width: 132px; animation: rise .45s ease both; }
  .sc:active { transform: scale(.97); }
  .sc .st { position: relative; width: 132px; height: 74px; border-radius: 14px; overflow: hidden; background: #2a0f4a; border: 1px solid rgba(193,60,255,.4); box-shadow: 0 6px 16px rgba(0,0,0,.4); }
  .sc.tall .st { height: 178px; }
  .sc .st img { width: 100%; height: 100%; object-fit: cover; display: block; }
  .stt { font-size: 12px; font-weight: 700; line-height: 1.25; margin-top: 6px; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
  .wt { font-size: 17px; font-weight: 800; line-height: 1.3; }
  .wact { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; padding: 14px; }
  .act { padding: 13px 8px; border: 0; border-radius: 16px; background: linear-gradient(90deg, #7b2ff7, #c13cff); color: #fff; font-size: 13px; font-weight: 800; box-shadow: 0 0 16px rgba(123,47,247,.55); }
  .act:active { transform: scale(.97); }
  .act.dl { background: linear-gradient(90deg, #ff2d75, #c13cff); box-shadow: 0 0 16px rgba(255,45,117,.55); }
  .cmd { margin: 0 14px; padding: 11px; border-radius: 12px; background: rgba(0,0,0,.4); border: 1px dashed rgba(193,60,255,.6); font-family: monospace; font-size: 13px; word-break: break-all; -webkit-user-select: text; user-select: text; min-height: 20px; }
  .msg { margin: 8px 14px 0; font-size: 12px; color: #e0d3f7; }
  .rel { display: flex; gap: 12px; padding: 8px 14px; align-items: center; }
  .rel .st { position: relative; width: 116px; height: 65px; flex: none; border-radius: 12px; overflow: hidden; background: #2a0f4a; border: 1px solid rgba(193,60,255,.35); }
  .rel .st img { width: 100%; height: 100%; object-fit: cover; display: block; }
  .nav { display: flex; flex: none; background: rgba(13,2,25,.82); -webkit-backdrop-filter: blur(10px); backdrop-filter: blur(10px); border-top: 1px solid rgba(193,60,255,.4); }
  .nb { flex: 1; background: none; border: 0; color: #b9a2e0; padding: 8px 0 9px; font-size: 10px; display: flex; flex-direction: column; align-items: center; gap: 2px; }
  .nb span { font-size: 19px; }
  .nb.on { color: #fff; font-weight: 800; text-shadow: 0 0 10px #c13cff; box-shadow: inset 0 2px 0 #c13cff; }
  input { width: 100%; padding: 12px 14px; border-radius: 14px; border: 1px solid rgba(193,60,255,.45); background: rgba(0,0,0,.4); color: #fff; font-size: 14px; outline: none; }
  input:focus { box-shadow: 0 0 14px rgba(193,60,255,.6); }
  .box { padding: 8px 14px; }
  .help { padding: 10px 16px; font-size: 13px; line-height: 1.7; color: #e0d3f7; }
</style>
</head>
<body>
<div class="app">

  <div class="top">
    <svg width="26" height="26" viewBox="0 0 30 30"><polygon points="15 1 29 15 15 29 1 15" fill="#b14cff"/><polygon points="12 9 12 21 21 15" fill="#ffffff"/></svg>
    <b>${esc(BOT_NAME)}</b>
    <button class="ib" id="tb-search">🔎</button>
  </div>
  <div class="tagline">SUA MÚSICA, DO SEU JEITO 💜</div>

  <div class="pane on" id="p-home">
    <div class="sbar" id="sbar" style="display:none"><input id="q2" type="text" placeholder="Pesquisar no Arlequina Tube" autocomplete="off"><button class="go" id="bq2">🔎</button></div>
    <div class="msg" id="s-msg" style="display:none;margin:0 12px 6px"></div>
    <div class="chips" id="chips"></div>
    <div class="ttl" id="ttl"></div>
    <div class="scroll" id="feed"></div>
  </div>

  <div class="pane" id="p-watch">
    <div class="scroll" id="watch">
      <div style="padding:0 4px 6px"><button class="ib" id="back">‹ Voltar</button></div>
      <div class="vt" id="w-vt"><img id="w-img" alt=""><div class="ov">▶</div></div>
      <div class="vi"><div class="wt" id="w-t"></div><div class="vch" id="w-a"></div></div>
      <div class="wact">
        <button class="act" data-a="play">▶  Tocar aqui</button>
        <button class="act dl" data-a="baixar">⬇  Baixar MP3</button>
        <button class="act" data-a="mp3">🎵  Áudio no chat</button>
        <button class="act" data-a="video">🎬  Vídeo</button>
      </div>
      <div class="cmd" id="w-cmd"></div>
      <div class="msg" id="w-msg">Toque numa ação: o comando é copiado. Cole no chat e envie.</div>
      <div class="sh" style="margin-top:14px">Mais como este</div>
      <div id="w-rel"></div>
    </div>
  </div>

  <div class="pane" id="p-busca">
    <div class="scroll" id="sc-busca">
      <div class="box">
        <div class="vch" style="margin:6px 0 8px">Digite o nome da música ou artista</div>
        <input id="q" type="text" placeholder="ex.: MC Gabzin" autocomplete="off">
        <button class="act" id="bq" style="width:100%;margin-top:10px">🔎  Copiar busca</button>
        <div class="cmd" id="b-cmd" style="margin:10px 0 0"></div>
        <div class="msg" id="b-msg" style="margin:6px 0 0">Cole no chat e envie para ver os resultados.</div>
      </div>
    </div>
  </div>

  <div class="pane" id="p-ajuda">
    <div class="scroll" id="sc-ajuda">
      <div class="help">
        <b>Como usar</b><br>
        Use os botões logo abaixo do card:<br>
        🔎 <b>Pesquisar</b>: toque e responda com o nome da música.<br>
        🔥 <b>Em alta</b>: lista de músicas.<br>
        📂 <b>Categorias</b>: Funk, Sertanejo, Pop...<br><br>
        Depois de escolher, toque em ▶ Tocar, 🎵 Áudio, ⬇ Baixar MP3 ou 🎬 Vídeo.<br><br>
        <b>Atalho:</b> ${esc(prefixo)}tube nome da música
      </div>
    </div>
  </div>

  <div class="nav">
    <button class="nb on" id="n-home"><span>🏠</span>Início</button>
    <button class="nb" id="n-busca"><span>🔎</span>Buscar</button>
    <button class="nb" id="n-ajuda"><span>❔</span>Ajuda</button>
  </div>
  <div class="fab"><button id="up">▲</button><button id="dn">▼</button></div>
</div>

<script>
(function () {
  var P = ${jsStr(prefixo)};
  var TITULO = ${jsStr(titulo || '')};
  var CONS = ${jsStr(consulta || '')};
  var BUSCA = ${busca ? 'true' : 'false'};
  var SECS = ${seguro(dados)};
  var TH = ${seguro(thumbs)};

  var BY = {}, SECOF = {};
  SECS.forEach(function (s, k) { s.itens.forEach(function (v) { if (!BY[v.id]) { BY[v.id] = v; SECOF[v.id] = k; } }); });
  var sec = 0, atual = null;

  function $(id) { return document.getElementById(id); }
  function esc(s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }
  function fmt(s) { s = Math.max(0, Math.floor(s || 0)); var r = s % 60; return Math.floor(s / 60) + ':' + (r < 10 ? '0' : '') + r; }
  function fmtV(v) {
    if (v == null) return '';
    if (v >= 1000000) return (Math.round((v / 1000000) * 10) / 10) + 'mi visualizações';
    if (v >= 1000) return Math.round(v / 1000) + 'mil visualizações';
    return v + ' visualizações';
  }
  function th(v) { return TH[v.id] || ''; }

  function cardG(v, hero) {
    var tag = '';
    if (hero) tag = '<span class="tag">' + (BUSCA ? '⭐ TOP RESULTADO' : (SECS[sec].nome === 'Em alta' ? '🔥 EM ALTA' : '✨ ' + esc(SECS[sec].nome).toUpperCase())) + '</span>';
    var vw = v.vw != null ? '<div class="vw">' + fmtV(v.vw) + '</div>' : '';
    if (hero) {
      return '<div class="vc hero" data-id="' + v.id + '"><div class="vt"><img alt="" src="' + th(v) + '">' + tag +
        (v.d ? '<span class="dur">' + fmt(v.d) + '</span>' : '') + '</div><div class="vi"><div class="vtt">' + esc(v.t) +
        '</div><div class="vch">' + esc(v.a) + '</div>' + vw + '<button class="heroplay">▶</button></div></div>';
    }
    return '<div class="vc" data-id="' + v.id + '"><div class="vt"><img alt="" src="' + th(v) + '">' + tag +
      (v.d ? '<span class="dur">' + fmt(v.d) + '</span>' : '') + '</div><div class="vi"><div class="vtt">' + esc(v.t) +
      '</div><div class="vch">' + esc(v.a) + (v.vw != null ? ' • ' + fmtV(v.vw) : '') + '</div></div></div>';
  }
  function cardP(v, tall) {
    return '<div class="sc' + (tall ? ' tall' : '') + '" data-id="' + v.id + '"><div class="st"><img alt="" src="' + th(v) + '">' +
      (v.d ? '<span class="dur">' + fmt(v.d) + '</span>' : '') + '</div><div class="stt">' + esc(v.t) + '</div></div>';
  }
  function linha(v) {
    return '<div class="rel" data-id="' + v.id + '"><div class="st"><img alt="" src="' + th(v) + '"></div><div class="vi" style="padding:0"><div class="vtt">' +
      esc(v.t) + '</div><div class="vch">' + esc(v.a) + '</div></div></div>';
  }

  function renderChips() {
    if (SECS.length < 2) { $('chips').style.display = 'none'; return; }
    var h = '';
    for (var i = 0; i < SECS.length; i++) h += '<button class="chip' + (i === sec ? ' on' : '') + '" data-s="' + i + '">' + esc(SECS[i].nome) + '</button>';
    $('chips').innerHTML = h;
  }
  function renderFeed() {
    var it = SECS[sec].itens, h = '', i;
    if (!it.length) { $('feed').innerHTML = '<div class="help">Nada encontrado.</div>'; return; }
    h += cardG(it[0], true);
    if (it.length > 1) {
      h += '<div class="sh">Você também pode gostar <span class="mut">deslize →</span></div><div class="car">';
      for (i = 1; i < Math.min(6, it.length); i++) h += cardP(it[i], true);
      h += '</div>';
    }
    for (i = 6; i < it.length; i++) h += cardG(it[i]);
    if (SECS.length > 1) {
      for (var k = 0; k < SECS.length; k++) {
        if (k === sec) continue;
        h += '<div class="sh">' + esc(SECS[k].nome) + ' <span class="mut">deslize →</span></div><div class="car">';
        for (i = 0; i < SECS[k].itens.length; i++) h += cardP(SECS[k].itens[i], false);
        h += '</div>';
      }
    }
    $('feed').innerHTML = h;
    $('feed').scrollTop = 0;
  }

  var panes = ['home', 'watch', 'busca', 'ajuda'];
  var curPane = 'home';
  var SCR = { home: 'feed', watch: 'watch', busca: 'sc-busca', ajuda: 'sc-ajuda' };
  function show(n) {
    curPane = n;
    panes.forEach(function (p) { $('p-' + p).className = 'pane' + (p === n ? ' on' : ''); });
    var alvo = n === 'watch' ? 'home' : n;
    ['home', 'busca', 'ajuda'].forEach(function (p) { $('n-' + p).className = 'nb' + (p === alvo ? ' on' : ''); });
  }

  function abrir(id) {
    var v = BY[id];
    if (!v) return;
    atual = v;
    $('w-img').src = th(v);
    $('w-t').textContent = v.t;
    $('w-a').textContent = v.a + (v.d ? ' • ' + fmt(v.d) : '');
    $('w-cmd').textContent = '';
    $('w-msg').textContent = 'Toque numa ação: o comando é copiado. Cole no chat e envie.';
    var lista = SECS[SECOF[id]].itens, h = '';
    for (var i = 0; i < lista.length; i++) if (lista[i].id !== id) h += linha(lista[i]);
    $('w-rel').innerHTML = h;
    show('watch');
    $('watch').scrollTop = 0;
  }

  function copiar(texto, cb) {
    function fallback() {
      try {
        var t = document.createElement('textarea');
        t.value = texto; t.style.position = 'fixed'; t.style.opacity = '0';
        document.body.appendChild(t); t.focus(); t.select();
        var ok = document.execCommand('copy');
        document.body.removeChild(t);
        cb(!!ok);
      } catch (e) { cb(false); }
    }
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(texto).then(function () { cb(true); }, fallback);
    } else { fallback(); }
  }
  function acao(a) {
    if (!atual) return;
    var cmd = P + 'tube ' + a + ' ' + atual.id;
    $('w-cmd').textContent = cmd;
    copiar(cmd, function (ok) {
      $('w-msg').textContent = ok ? '✅ Comando copiado! Cole no chat e envie.' : 'Segure o comando acima para copiar e cole no chat.';
    });
  }

  function achar(e, sel) { return e.target && e.target.closest ? e.target.closest(sel) : null; }
  function clicouVideo(e) {
    var el = achar(e, '[data-id]');
    if (el) abrir(el.getAttribute('data-id'));
  }
  $('feed').addEventListener('click', clicouVideo);
  $('w-rel').addEventListener('click', clicouVideo);
  $('chips').addEventListener('click', function (e) {
    var b = achar(e, '.chip');
    if (!b) return;
    sec = Number(b.getAttribute('data-s'));
    renderChips(); renderFeed();
  });
  $('w-vt').addEventListener('click', function () { acao('play'); });
  Array.prototype.slice.call(document.querySelectorAll('.act[data-a]')).forEach(function (b) {
    b.addEventListener('click', function () { acao(b.getAttribute('data-a')); });
  });
  $('back').addEventListener('click', function () { show('home'); });
  $('n-home').addEventListener('click', function () { show('home'); });
  $('n-busca').addEventListener('click', function () { show('busca'); });
  $('n-ajuda').addEventListener('click', function () { show('ajuda'); });
  $('tb-search').addEventListener('click', function () { show('busca'); });
  $('bq').addEventListener('click', function () {
    var v = ($('q').value || '').trim();
    if (!v) { $('b-msg').textContent = 'Digite algo para buscar.'; return; }
    var cmd = P + 'arlequinatube ' + v;
    $('b-cmd').textContent = cmd;
    copiar(cmd, function (ok) {
      $('b-msg').textContent = ok ? '✅ Busca copiada! Cole no chat e envie.' : 'Segure o comando acima para copiar e cole no chat.';
    });
  });

  function rolar(d) {
    var el = $(SCR[curPane]);
    if (!el) return;
    var dy = Math.round((el.clientHeight || 300) * 0.8) * d;
    try { if (el.scrollBy) { el.scrollBy({ top: dy, behavior: 'smooth' }); return; } } catch (e) {}
    el.scrollTop = (el.scrollTop || 0) + dy;
  }
  $('up').addEventListener('click', function () { rolar(-1); });
  $('dn').addEventListener('click', function () { rolar(1); });

  function buscar2() {
    var v = ($('q2').value || '').trim();
    var m = $('s-msg');
    m.style.display = 'block';
    if (!v) { m.textContent = 'Digite algo para buscar.'; return; }
    var cmd = P + 'arlequinatube ' + v;
    copiar(cmd, function (ok) {
      m.textContent = ok ? '✅ Busca copiada! Cole no chat e envie para ver os resultados.' : 'Cole no chat: ' + cmd;
    });
  }
  if (BUSCA) {
    $('sbar').style.display = 'flex';
    $('q2').value = CONS;
    $('bq2').addEventListener('click', buscar2);
    $('q2').addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.keyCode === 13) buscar2(); });
  }

  $('ttl').textContent = TITULO;
  $('ttl').style.display = TITULO ? 'block' : 'none';
  renderChips();
  renderFeed();
})();
</script>
</body>
</html>`
}

// ---------- HTML da lista de resultados (abas + rolagem + ações) ----------
const GRAD_ARLEQUINA =
  'repeating-linear-gradient(45deg, rgba(255,255,255,.035) 0 22px, transparent 22px 44px), ' +
  'repeating-linear-gradient(-45deg, rgba(255,255,255,.035) 0 22px, transparent 22px 44px), ' +
  'linear-gradient(180deg, #4b1a7a 0%, #21093f 55%, #0d0219 100%)'

const GRAD_NEON =
  'radial-gradient(circle at 88% 6%, rgba(193,60,255,.38), transparent 42%), ' +
  'radial-gradient(circle at 8% 92%, rgba(255,45,117,.20), transparent 46%), ' +
  GRAD_ARLEQUINA

function cssBase(inline, largura) {
  const bodyBg = inline ? '#202c33' : '#0d0219'
  const cardCss = inline
    ? `width: ${largura}; margin: 14px auto; padding: 16px 14px 18px; border-radius: 22px; background: ${GRAD_ARLEQUINA};`
    : `min-height: 100vh; padding: 18px 16px 22px; background: ${GRAD_ARLEQUINA};`
  return `
  * { box-sizing: border-box; -webkit-tap-highlight-color: transparent; }
  html, body { margin: 0; padding: 0; background: ${bodyBg}; color: #fff; font-family: Arial, Helvetica, sans-serif; overflow-x: hidden; }
  .card { ${cardCss} }
  button { font-family: inherit; }
  .logo { display: flex; align-items: center; gap: 10px; }
  .logo b { font-size: 16px; letter-spacing: .5px; }
  .tabs { display: flex; gap: 6px; margin: 12px 0 10px; }
  .tab { flex: 1; padding: 9px 4px; border: 0; border-radius: 999px; background: rgba(255,255,255,.08); color: #cdb6f0; font-size: 12px; font-weight: bold; }
  .tab.on { background: linear-gradient(90deg, #7b2ff7, #c13cff); color: #fff; }
  .q { font-size: 12px; color: #cdb6f0; margin: 4px 0 8px; }
  .list { max-height: 360px; overflow-y: auto; -webkit-overflow-scrolling: touch; overscroll-behavior: contain; }
  .row { display: flex; align-items: center; gap: 10px; padding: 8px 4px; border-top: 1px solid rgba(255,255,255,.08); border-radius: 10px; }
  .row:active { background: rgba(193,60,255,.18); }
  .n { width: 18px; text-align: center; font-size: 14px; font-weight: bold; color: #d98cff; flex: none; }
  .th { position: relative; width: 96px; height: 54px; flex: none; border-radius: 8px; overflow: hidden; background: #2a0f4a; }
  .th img { width: 100%; height: 100%; object-fit: cover; display: block; }
  .dur { position: absolute; right: 3px; bottom: 3px; background: rgba(0,0,0,.75); font-size: 10px; padding: 1px 4px; border-radius: 4px; }
  .tx { min-width: 0; }
  .tt { font-size: 13px; font-weight: bold; line-height: 1.25; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
  .ch { font-size: 11px; color: #b9a2e0; margin-top: 3px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .hint { margin-top: 10px; font-size: 11px; color: #cbb6ee; text-align: center; }
  .sel { display: flex; align-items: center; gap: 10px; margin: 6px 0 14px; }
  .sel img { width: 96px; height: 54px; border-radius: 8px; object-fit: cover; background: #2a0f4a; flex: none; }
  .act { display: block; width: 100%; margin: 8px 0; padding: 13px; border: 0; border-radius: 14px; background: linear-gradient(90deg, #7b2ff7, #c13cff); color: #fff; font-size: 14px; font-weight: bold; text-align: left; }
  .act.dl { background: linear-gradient(90deg, #ff2d75, #c13cff); }
  .cmd { margin-top: 10px; padding: 10px; border-radius: 10px; background: rgba(0,0,0,.35); font-family: monospace; font-size: 13px; color: #fff; -webkit-user-select: text; user-select: text; word-break: break-all; min-height: 18px; }
  .msg { margin-top: 8px; font-size: 12px; color: #e0d3f7; }
  .empty { padding: 26px 8px; text-align: center; font-size: 13px; color: #cbb6ee; }
  input { width: 100%; padding: 12px; border-radius: 12px; border: 1px solid rgba(255,255,255,.2); background: rgba(0,0,0,.35); color: #fff; font-size: 14px; outline: none; }
`
}

function buildListHtml({ query, items, thumbs, inline, prefixo, rotulo }) {
  const rows = items
    .map(
      (v, i) => `
    <div class="row" data-i="${i}">
      <div class="n">${i + 1}</div>
      <div class="th">${thumbs[i] ? '<img src="' + thumbs[i] + '" alt="">' : ''}${v.seconds ? '<span class="dur">' + fmtTime(v.seconds) + '</span>' : ''}</div>
      <div class="tx"><div class="tt">${esc(v.title)}</div><div class="ch">${esc(v.author)}</div></div>
    </div>`
    )
    .join('')

  const dados = items.map((v) => ({ t: v.title, a: v.author }))

  return `<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<style>${cssBase(inline, '92%')}</style>
</head>
<body>
<div class="card">
  <div class="logo">
    <svg width="30" height="30" viewBox="0 0 30 30"><polygon points="15 1 29 15 15 29 1 15" fill="#b14cff"/><polygon points="12 9 12 21 21 15" fill="#ffffff"/></svg>
    <b>${esc(BOT_NAME)}</b>
  </div>

  <div class="tabs">
    <button class="tab on" data-t="res">Resultados</button>
    <button class="tab" data-t="act">Ações</button>
    <button class="tab" data-t="bus">Buscar</button>
  </div>

  <div id="p-res">
    <div class="q">${rotulo ? esc(rotulo) : 'Resultados para “' + esc(query) + '”'}</div>
    <div class="list">${rows}</div>
  </div>

  <div id="p-act" style="display:none">
    <div class="empty" id="act-empty">Toque numa música em <b>Resultados</b> para ver as ações.</div>
    <div id="act-box" style="display:none">
      <div class="sel"><img id="sel-img" alt=""><div class="tx"><div class="tt" id="sel-t"></div><div class="ch" id="sel-a"></div></div></div>
      <button class="act" data-a="play">▶  Player interativo</button>
      <button class="act" data-a="mp3">🎵  Áudio no chat</button>
      <button class="act dl" data-a="baixar">⬇  Baixar MP3</button>
      <button class="act" data-a="video">🎬  Vídeo</button>
      <div class="cmd" id="cmd"></div>
      <div class="msg" id="msg"></div>
    </div>
  </div>

  <div id="p-bus" style="display:none">
    <div class="q">Digite o nome da música ou artista</div>
    <input id="q" type="text" placeholder="ex.: MC Gabzin">
    <button class="act" id="bq" style="margin-top:12px;text-align:center">🔎  Copiar busca</button>
    <div class="cmd" id="cmd2"></div>
    <div class="msg" id="msg2"></div>
  </div>

  <div class="hint">Para abrir uma música, toque em “Escolher música” logo abaixo do card.<br>Para pesquisar: <b>${esc(prefixo)}arlequinatube nome da música</b></div>
</div>

<script>
(function () {
  var P = ${jsStr(prefixo)};
  var ITEMS = ${JSON.stringify(dados).replace(/</g, '\\u003c')};
  var sel = -1;
  function $(id) { return document.getElementById(id); }
  var tabs = Array.prototype.slice.call(document.querySelectorAll('.tab'));
  var rows = Array.prototype.slice.call(document.querySelectorAll('.row'));

  function show(name) {
    ['res', 'act', 'bus'].forEach(function (n) { $('p-' + n).style.display = (n === name) ? 'block' : 'none'; });
    tabs.forEach(function (t) { t.className = 'tab' + (t.getAttribute('data-t') === name ? ' on' : ''); });
  }
  tabs.forEach(function (t) { t.addEventListener('click', function () { show(t.getAttribute('data-t')); }); });

  function copiar(texto, cb) {
    function fallback() {
      try {
        var t = document.createElement('textarea');
        t.value = texto; t.style.position = 'fixed'; t.style.opacity = '0';
        document.body.appendChild(t); t.focus(); t.select();
        var ok = document.execCommand('copy');
        document.body.removeChild(t);
        cb(!!ok);
      } catch (e) { cb(false); }
    }
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(texto).then(function () { cb(true); }, fallback);
    } else { fallback(); }
  }

  function escolher(i) {
    sel = i;
    var it = ITEMS[i];
    $('sel-t').textContent = (i + 1) + '. ' + it.t;
    $('sel-a').textContent = it.a;
    var im = rows[i].querySelector('img');
    $('sel-img').src = im ? im.src : '';
    $('act-empty').style.display = 'none';
    $('act-box').style.display = 'block';
    $('cmd').textContent = '';
    $('msg').textContent = '';
    show('act');
  }
  rows.forEach(function (r) { r.addEventListener('click', function () { escolher(Number(r.getAttribute('data-i'))); }); });

  Array.prototype.slice.call(document.querySelectorAll('.act[data-a]')).forEach(function (b) {
    b.addEventListener('click', function () {
      if (sel < 0) return;
      var cmd = P + 'tube ' + b.getAttribute('data-a') + ' ' + (sel + 1);
      $('cmd').textContent = cmd;
      copiar(cmd, function (ok) {
        $('msg').textContent = ok ? '✅ Comando copiado! Cole no chat e envie.' : 'Segure o comando acima para copiar e cole no chat.';
      });
    });
  });

  $('bq').addEventListener('click', function () {
    var v = $('q').value.replace(/^\\s+|\\s+$/g, '');
    if (!v) { $('msg2').textContent = 'Digite algo para buscar.'; return; }
    var cmd = P + 'arlequinatube ' + v;
    $('cmd2').textContent = cmd;
    copiar(cmd, function (ok) {
      $('msg2').textContent = ok ? '✅ Busca copiada! Cole no chat e envie.' : 'Segure o comando acima para copiar e cole no chat.';
    });
  });
})();
</script>
</body>
</html>`
}

// ---------- card de diagnóstico (descobre o que o card consegue fazer) ----------
function buildDiagHtml({ inline, prefixo }) {
  return `<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<style>${cssBase(inline, '92%')}
  .r { font-size: 12px; padding: 6px 8px; margin: 4px 0; border-radius: 8px; background: rgba(255,255,255,.07); word-break: break-word; }
  .r.ok { background: rgba(60,200,120,.25); }
  .r.bad { background: rgba(255,60,90,.28); }
  .t { margin: 10px 0; font-size: 13px; }
  .t a { color: #ffd0ff; }
  .t button { padding: 10px 12px; border: 0; border-radius: 10px; background: #7b2ff7; color: #fff; font-size: 13px; }
</style>
</head>
<body>
<div class="card">
  <div class="logo"><b>🔧 Diagnóstico do card</b></div>
  <div class="q" style="margin-top:8px">Faça os toques abaixo e mande um print desta tela.</div>
  <div id="out"></div>

  <div class="t"><a href="https://www.youtube.com" target="_blank" rel="noopener">1) Toque: abrir link externo</a></div>
  <div class="t"><a download="teste.txt" href="data:text/plain;base64,QXJsZXF1aW5h">2) Toque: baixar arquivo de teste</a></div>
  <div class="t"><button id="b3">3) window.open</button></div>
  <div class="t"><button id="b4">4) Compartilhar</button></div>
  <div class="t"><button id="b5">5) Enviar ao chat</button></div>
</div>

<script>
(function () {
  var P = ${jsStr(prefixo)};
  var out = document.getElementById('out');
  function add(k, v, ok) {
    var d = document.createElement('div');
    d.className = 'r ' + (ok === true ? 'ok' : ok === false ? 'bad' : '');
    d.textContent = k + ': ' + v;
    out.appendChild(d);
  }

  var keys = [];
  try {
    keys = Object.getOwnPropertyNames(window).filter(function (k) {
      return /whatsapp|^wa|bridge|native|android|webkit|react|flutter|post|prompt|share|send/i.test(k);
    });
  } catch (e) {}
  add('globais', keys.slice(0, 20).join(', ') || 'nenhuma', null);
  add('clipboard', navigator.clipboard ? 'sim' : 'não', !!navigator.clipboard);
  add('share', navigator.share ? 'sim' : 'não', !!navigator.share);
  add('WebAudio', (window.AudioContext || window.webkitAudioContext) ? 'sim' : 'não', !!(window.AudioContext || window.webkitAudioContext));

  function tf(label, url) {
    try {
      fetch(url).then(function (r) { add(label, 'OK (' + r.status + ')', true); })
        .catch(function (e) { add(label, 'BLOQUEADO (' + (e && e.message) + ')', false); });
    } catch (e) { add(label, 'ERRO ' + e.message, false); }
  }
  tf('fetch api.github.com (confiável)', 'https://api.github.com/zen');
  tf('fetch httpbin.org (confiável)', 'https://httpbin.org/get');
  tf('fetch api.ipify.org (NÃO confiável)', 'https://api.ipify.org?format=json');

  try {
    var au = new Audio();
    au.preload = 'auto';
    au.addEventListener('canplay', function () { add('áudio por link (soundhelix)', 'OK', true); });
    au.addEventListener('error', function () { add('áudio por link (soundhelix)', 'ERRO código ' + (au.error && au.error.code), false); });
    au.src = 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3';
    au.load();
  } catch (e) { add('áudio por link', 'ERRO ' + e.message, false); }

  document.getElementById('b3').addEventListener('click', function () {
    try { var w = window.open('https://www.youtube.com', '_blank'); add('window.open', w ? 'retornou janela' : 'retornou null', !!w); }
    catch (e) { add('window.open', 'ERRO ' + e.message, false); }
  });
  document.getElementById('b4').addEventListener('click', function () {
    if (!navigator.share) { add('share', 'indisponível', false); return; }
    navigator.share({ title: 'Arlequina', text: 'teste' }).then(function () { add('share', 'OK', true); }).catch(function (e) { add('share', 'ERRO ' + (e && e.name), false); });
  });
  document.getElementById('b5').addEventListener('click', function () {
    var msg = P + 'tube ping', usados = [];
    try { if (window.parent && window.parent !== window) { window.parent.postMessage(msg, '*'); usados.push('parent.postMessage'); } } catch (e) {}
    try { if (window.ReactNativeWebView) { window.ReactNativeWebView.postMessage(msg); usados.push('ReactNativeWebView'); } } catch (e) {}
    try { if (window.webkit && window.webkit.messageHandlers) { usados.push('webkit.messageHandlers: ' + Object.keys(window.webkit.messageHandlers).join(',')); } } catch (e) {}
    try { if (typeof window.sendPrompt === 'function') { window.sendPrompt(msg); usados.push('sendPrompt'); } } catch (e) {}
    add('enviar ao chat', usados.join(' | ') || 'nenhum canal encontrado', usados.length ? null : false);
  });
})();
</script>
</body>
</html>`
}

// ---------- player estilo YT Music (o do !play2, vermelho) ----------
const PLAY2_NOME = 'ARLEQUINA PLAY2'

function buildPlay2Html({ title, author, seconds, cover, audioB64, inline }) {
  const bodyBg = inline ? '#0d0219' : '#0d0219'
  const cardCss = inline
    ? `width: 90%; margin: 14px auto; padding: 16px 16px 20px; border-radius: 24px; background: ${GRAD_NEON};`
    : `min-height: 100vh; padding: 18px 16px 22px; background: ${GRAD_NEON};`
  const idle = PLAY2_NOME + ' • toque em ▶ para iniciar'
  const playing = PLAY2_NOME + ' • tocando'
  // barrinhas de equalizador decorativas (alturas variadas), uma tira de cada lado da capa
  const alturas = [10, 22, 14, 28, 18, 30, 12, 24, 16, 26]
  const ondas = (lado) =>
    alturas.map((h, i) => `<span style="height:${h}px;animation-delay:${(i * 0.09).toFixed(2)}s"></span>`).join('') +
    (lado === 'r' ? '' : '')

  return `<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<style>
  * { box-sizing: border-box; -webkit-tap-highlight-color: transparent; }
  html, body { margin: 0; padding: 0; background: ${bodyBg}; color: #fff; font-family: -apple-system, "Segoe UI", Roboto, Arial, sans-serif; overflow-x: hidden; }
  button { font-family: inherit; }
  @keyframes bounce { 0%, 100% { transform: scaleY(.4); } 50% { transform: scaleY(1); } }
  .card { ${cardCss} }
  svg { display: block; }
  .brand { text-align: center; margin-bottom: 14px; }
  .brand .word { font-size: 22px; font-weight: 900; letter-spacing: .5px; background: linear-gradient(90deg, #fff, #ff7ad9 55%, #c13cff); -webkit-background-clip: text; background-clip: text; -webkit-text-fill-color: transparent; color: transparent; }
  .brand .tag { font-size: 10px; letter-spacing: .5px; color: #d9c2ff; margin-top: 2px; }
  .panel { background: rgba(10,2,22,.55); border: 1px solid rgba(193,60,255,.35); border-radius: 20px; padding: 14px; box-shadow: 0 10px 30px rgba(0,0,0,.5); }
  .top { display: flex; align-items: center; justify-content: space-between; }
  .top .src { display: flex; align-items: center; gap: 6px; font-size: 12px; font-weight: 700; color: #ead9ff; }
  .top .src svg { filter: drop-shadow(0 0 6px #c13cff); }
  .pill { display: flex; align-items: center; gap: 5px; font-size: 9px; font-weight: 800; letter-spacing: .5px; padding: 4px 9px; border-radius: 999px; background: linear-gradient(90deg, #7b2ff7, #ff2d75); box-shadow: 0 0 12px rgba(255,45,117,.6); }
  .waves { display: flex; align-items: center; gap: 3px; width: 26px; }
  .waves span { display: block; flex: 1; height: 8px; border-radius: 2px; background: #fff; animation: bounce .9s ease-in-out infinite; }
  .stage { display: flex; align-items: center; gap: 8px; margin: 16px 0 14px; }
  .eq { display: flex; align-items: flex-end; gap: 3px; height: 34px; flex: none; width: 22px; }
  .eq span { display: block; width: 3px; border-radius: 2px; background: linear-gradient(180deg, #ff7ad9, #7b2ff7); animation: bounce 1.1s ease-in-out infinite; }
  .cover { flex: 1; aspect-ratio: 1 / 1; border-radius: 16px; overflow: hidden; background: #2a0f4a; box-shadow: 0 0 0 1px rgba(193,60,255,.4), 0 14px 32px rgba(0,0,0,.55); }
  .cover img { width: 100%; height: 100%; object-fit: cover; display: block; }
  .info { display: flex; align-items: flex-start; justify-content: space-between; gap: 10px; margin-top: 4px; }
  .info .t { min-width: 0; }
  .title { font-size: 19px; font-weight: 800; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .sub { font-size: 12px; color: #c4a9f2; margin-top: 3px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .lyric { font-size: 11px; color: #b9a2e0; margin: 18px 0 16px; }
  .bar { position: relative; height: 22px; touch-action: none; cursor: pointer; }
  .track { position: absolute; left: 0; right: 0; top: 9px; height: 4px; border-radius: 2px; background: rgba(255,255,255,.25); }
  .fill { position: absolute; left: 0; top: 9px; height: 4px; border-radius: 2px; background: linear-gradient(90deg, #7b2ff7, #ff2d75); box-shadow: 0 0 8px rgba(255,45,117,.7); width: 0; }
  .knob { position: absolute; top: 4px; left: 0; width: 14px; height: 14px; border-radius: 50%; background: #fff; box-shadow: 0 0 8px #ff7ad9; transform: translateX(-50%); }
  .times { display: flex; justify-content: space-between; font-size: 11px; color: #e0d3f7; margin-top: 2px; }
  .ctrl { display: flex; align-items: center; justify-content: space-between; margin-top: 18px; }
  .ib { background: none; border: 0; padding: 8px; color: #d9c2ff; opacity: .85; }
  .play { width: 62px; height: 62px; border-radius: 50%; border: 0; background: linear-gradient(135deg, #fff, #ffd8f2); display: flex; align-items: center; justify-content: center; padding: 0; box-shadow: 0 0 22px rgba(255,122,217,.6); }
  .chan { display: flex; align-items: center; gap: 10px; margin-top: 16px; padding-top: 14px; border-top: 1px solid rgba(193,60,255,.25); }
  .av { width: 32px; height: 32px; border-radius: 50%; background: linear-gradient(135deg, #7b2ff7, #ff2d75); display: flex; align-items: center; justify-content: center; font-weight: 800; font-size: 13px; flex: none; }
  .cn { flex: 1; min-width: 0; font-size: 12px; font-weight: 700; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .sub2 { padding: 6px 13px; border: 1px solid rgba(193,60,255,.5); border-radius: 999px; background: rgba(255,255,255,.06); color: #fff; font-size: 11px; font-weight: 700; }
  .sub2.on { background: linear-gradient(90deg, #7b2ff7, #c13cff); border-color: transparent; }
  .foot { text-align: center; font-size: 11px; color: #e0d3f7; margin-top: 16px; min-height: 14px; }
  .brandfoot { text-align: center; font-size: 10px; color: #9d7fc9; margin-top: 6px; letter-spacing: .3px; }
</style>
</head>
<body>
<div class="card">
  <div class="brand"><div class="word">🃏 ARLEQUINA TUBE</div><div class="tag">SUA MÚSICA, DO SEU JEITO 💜</div></div>

  <div class="panel">
    <div class="top">
      <div class="src">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="#ff2d55"><rect width="24" height="24" rx="6"/><polygon points="10 7 17 12 10 17" fill="#fff"/></svg>
        YouTube Music
      </div>
      <div class="pill"><div class="waves"><span style="height:5px"></span><span style="height:9px"></span><span style="height:6px"></span></div>TOCANDO AGORA</div>
    </div>

    <div class="stage">
      <div class="eq">${ondas('l')}</div>
      <div class="cover">${cover ? '<img src="' + cover + '" alt="">' : ''}</div>
    </div>

    <div class="info">
      <div class="t">
        <div class="title">${esc(title)}</div>
        <div class="sub">${esc(author)}</div>
      </div>
      <button class="ib" id="hb" style="padding:4px">
        <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linejoin="round" id="hp"><path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1-1.1a5.5 5.5 0 0 0-7.8 7.8l1 1.1L12 21l7.8-7.5 1-1.1a5.5 5.5 0 0 0 0-7.8z"/></svg>
      </button>
    </div>

    <div class="lyric">Letra ainda não disponível para esta música.</div>

    <div class="bar" id="bar">
      <div class="track"></div>
      <div class="fill" id="fill"></div>
      <div class="knob" id="knob"></div>
    </div>
    <div class="times"><span id="cur">0:00</span><span id="tot">${fmtTime(seconds)}</span></div>

    <div class="ctrl">
      <button class="ib" id="sh" tabindex="-1">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="16 3 21 3 21 8"/><line x1="4" y1="20" x2="21" y2="3"/><polyline points="21 16 21 21 16 21"/><line x1="15" y1="15" x2="21" y2="21"/><line x1="4" y1="4" x2="9" y2="9"/></svg>
      </button>
      <button class="ib" id="back">
        <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"/><text x="12" y="15.2" font-size="7" font-weight="bold" text-anchor="middle" fill="currentColor" stroke="none">10</text></svg>
      </button>
      <button class="play" id="pb"><span id="ic"></span></button>
      <button class="ib" id="fwd">
        <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/><text x="12" y="15.2" font-size="7" font-weight="bold" text-anchor="middle" fill="currentColor" stroke="none">10</text></svg>
      </button>
      <button class="ib" id="rp">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="17 1 21 5 17 9"/><path d="M3 11V9a4 4 0 0 1 4-4h14"/><polyline points="7 23 3 19 7 15"/><path d="M21 13v2a4 4 0 0 1-4 4H3"/></svg>
      </button>
    </div>

    <div class="chan">
      <div class="av">${esc((author || 'A').trim().charAt(0).toUpperCase() || 'A')}</div>
      <div class="cn">${esc(author)}</div>
      <button class="sub2" id="sub2">Inscrito</button>
    </div>
  </div>

  <div class="foot" id="foot">${esc(idle)}</div>
  <div class="brandfoot">ARLEQUINA TUBE • TUDO QUE VOCÊ GOSTA, EM UM SÓ LUGAR 🃏</div>
</div>

<script>
(function () {
  var TOTAL = ${Number(seconds) || 0};
  var B64 = "${audioB64}";

  var pb = document.getElementById('pb');
  var ic = document.getElementById('ic');
  var fill = document.getElementById('fill');
  var knob = document.getElementById('knob');
  var cur = document.getElementById('cur');
  var tot = document.getElementById('tot');
  var bar = document.getElementById('bar');
  var foot = document.getElementById('foot');
  var FOOT_IDLE = ${jsStr(idle)};
  var FOOT_PLAY = ${jsStr(playing)};
  var PLAY = '<svg width="26" height="26" viewBox="0 0 24 24"><polygon points="8 4 20 12 8 20" fill="#1a0533"/></svg>';
  var PAUSE = '<svg width="26" height="26" viewBox="0 0 24 24"><rect x="6" y="4" width="4" height="16" rx="1" fill="#1a0533"/><rect x="14" y="4" width="4" height="16" rx="1" fill="#1a0533"/></svg>';

  var ctx = null, buf = null, src = null, loading = null;
  var playing = false, offset = 0, startedAt = 0, loop = false;

  function fmt(s) {
    s = Math.max(0, Math.floor(s || 0));
    var r = s % 60;
    return Math.floor(s / 60) + ':' + (r < 10 ? '0' : '') + r;
  }
  function dur() { return buf ? buf.duration : TOTAL; }
  function pos() {
    if (!playing) return offset;
    var d = dur() || 1;
    var t = offset + (ctx.currentTime - startedAt);
    if (loop) t = t % d;
    return Math.min(t, d);
  }
  function upd() {
    var t = pos();
    var d = dur() || 1;
    var p = Math.min(100, Math.max(0, (t / d) * 100));
    fill.style.width = p + '%';
    knob.style.left = p + '%';
    cur.textContent = fmt(t);
    tot.textContent = fmt(d);
  }
  function icon() {
    ic.innerHTML = playing ? PAUSE : PLAY;
    foot.textContent = playing ? FOOT_PLAY : FOOT_IDLE;
    document.body.classList.toggle('tocando', playing);
  }

  function getCtx() {
    if (!ctx) {
      var AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return null;
      ctx = new AC();
    }
    return ctx;
  }

  // decodifica o áudio embutido (1x)
  function load() {
    if (loading) return loading;
    loading = new Promise(function (resolve, reject) {
      var c = getCtx();
      if (!c) { reject(new Error('sem suporte a áudio')); return; }
      var bin = atob(B64);
      var n = bin.length;
      var u8 = new Uint8Array(n);
      for (var i = 0; i < n; i++) u8[i] = bin.charCodeAt(i);
      var done = false;
      function ok(b) { if (done) return; done = true; buf = b; resolve(b); }
      function bad(e) { if (done) return; done = true; reject(e || new Error('falha ao decodificar')); }
      var p = c.decodeAudioData(u8.buffer, ok, bad);
      if (p && p.then) p.then(ok, bad);
    });
    return loading;
  }

  function stopSrc() {
    if (src) {
      src.onended = null;
      try { src.stop(); } catch (e) {}
      try { src.disconnect(); } catch (e) {}
      src = null;
    }
  }

  function startAt(t) {
    stopSrc();
    var s = ctx.createBufferSource();
    s.buffer = buf;
    s.loop = loop;
    s.connect(ctx.destination);
    s.onended = function () {
      if (src === s) { src = null; playing = false; offset = 0; upd(); icon(); }
    };
    src = s;
    offset = t;
    startedAt = ctx.currentTime;
    s.start(0, t);
    playing = true;
    icon();
  }

  function seekTo(t) {
    var d = dur();
    t = Math.max(0, t);
    if (d) t = Math.min(t, Math.max(0, d - 0.05));
    if (playing && buf) { startAt(t); } else { offset = t; }
    upd();
  }

  pb.addEventListener('click', function () {
    if (playing) {
      offset = pos();
      stopSrc();
      playing = false;
      icon();
      upd();
      return;
    }
    var c = getCtx();
    if (!c) { foot.textContent = 'Áudio não suportado neste aparelho'; return; }
    if (c.state === 'suspended' && c.resume) c.resume();
    foot.textContent = 'Carregando áudio...';
    load().then(function () {
      if (c.state === 'suspended' && c.resume) c.resume();
      startAt(buf && offset >= buf.duration - 0.1 ? 0 : offset);
    }).catch(function (e) {
      loading = null;
      foot.textContent = 'Este aparelho não conseguiu tocar aqui. Use o áudio no chat: !tube mp3 nome da música';
    });
  });

  document.getElementById('back').addEventListener('click', function () { seekTo(pos() - 10); });
  document.getElementById('fwd').addEventListener('click', function () { seekTo(pos() + 10); });

  var rp = document.getElementById('rp');
  rp.addEventListener('click', function () {
    loop = !loop;
    if (src) src.loop = loop;
    rp.style.color = loop ? '#ffffff' : '#d9c2ff';
    rp.style.opacity = loop ? '1' : '.85';
  });

  var liked = false;
  var hp = document.getElementById('hp');
  document.getElementById('hb').addEventListener('click', function () {
    liked = !liked;
    hp.setAttribute('fill', liked ? '#ff4d9e' : 'none');
    hp.setAttribute('stroke', liked ? '#ff4d9e' : '#ffffff');
  });

  // decorativo: alterna o destaque do embaralhar (não muda nada, é só 1 música)
  var shOn = false;
  document.getElementById('sh').addEventListener('click', function () {
    shOn = !shOn;
    this.style.color = shOn ? '#ff7ad9' : '#d9c2ff';
    this.style.opacity = shOn ? '1' : '.85';
  });

  // decorativo: inscrever-se local (não é uma inscrição de verdade)
  var inscrito = true;
  var sub2 = document.getElementById('sub2');
  sub2.addEventListener('click', function () {
    inscrito = !inscrito;
    sub2.textContent = inscrito ? 'Inscrito' : 'Inscrever-se';
    sub2.className = 'sub2' + (inscrito ? ' on' : '');
  });
  sub2.className = 'sub2 on';

  var drag = false;
  function seekEvent(e) {
    var r = bar.getBoundingClientRect();
    var p = Math.min(1, Math.max(0, (e.clientX - r.left) / r.width));
    seekTo(p * dur());
  }
  bar.addEventListener('pointerdown', function (e) {
    drag = true;
    if (bar.setPointerCapture) bar.setPointerCapture(e.pointerId);
    seekEvent(e);
  });
  bar.addEventListener('pointermove', function (e) { if (drag) seekEvent(e); });
  bar.addEventListener('pointerup', function () { drag = false; });
  bar.addEventListener('pointercancel', function () { drag = false; });

  setInterval(upd, 250);
  icon();
  upd();

  // já vai decodificando em segundo plano para começar rápido ao tocar
  setTimeout(function () { load().catch(function () { loading = null; }); }, 300);
})();
</script>
</body>
</html>`
}

// ---------- player estilo "página do vídeo" do YouTube (toca o áudio embutido) ----------
function buildWatchHtml({ title, author, seconds, cover, audioB64, inline, prefixo, videoId, rel, relThumbs }) {
  const bodyBg = inline ? '#202c33' : '#0d0219'
  const altura = inline ? HOME_ALTURA + 'px' : '100vh'
  const seguro = (obj) => JSON.stringify(obj).replace(/</g, '\\u003c')
  const relDados = (rel || []).map((v) => ({ id: v.id, t: v.title, a: v.author, d: v.seconds || 0 }))
  const svgPlay = `<svg width="30" height="30" viewBox="0 0 24 24"><polygon points="7 4 20 12 7 20" fill="#ffffff"/></svg>`
  const svgPause = `<svg width="30" height="30" viewBox="0 0 24 24"><rect x="6" y="4" width="4.5" height="16" rx="1" fill="#ffffff"/><rect x="13.5" y="4" width="4.5" height="16" rx="1" fill="#ffffff"/></svg>`
  const inicial = esc((author || 'A').trim().charAt(0).toUpperCase() || 'A')

  return `<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<style>
  * { box-sizing: border-box; -webkit-tap-highlight-color: transparent; }
  html, body { margin: 0; padding: 0; background: ${bodyBg}; color: #fff; font-family: -apple-system, "Segoe UI", Roboto, Arial, sans-serif; overflow: hidden; }
  button { font-family: inherit; }
  @keyframes rise { from { opacity: 0; transform: translateY(12px); } to { opacity: 1; transform: none; } }
  @keyframes pulse { 0%, 100% { box-shadow: 0 0 18px rgba(193,60,255,.7); } 50% { box-shadow: 0 0 32px rgba(255,45,117,.95); } }
  .app { position: relative; height: ${altura}; background: ${GRAD_NEON}; overflow: hidden; }
  .scroll { height: 100%; overflow-y: auto; -webkit-overflow-scrolling: touch; overscroll-behavior: contain; padding-bottom: 18px; scroll-behavior: smooth; }
  .stage { position: relative; width: 100%; aspect-ratio: 16 / 9; background: #000; overflow: hidden; border-radius: 0 0 22px 22px; box-shadow: 0 10px 30px rgba(123,47,247,.5); }
  .stage img { width: 100%; height: 100%; object-fit: cover; display: block; opacity: .92; }
  .shade { position: absolute; left: 0; right: 0; bottom: 0; height: 62%; background: linear-gradient(180deg, transparent, rgba(13,2,25,.85)); }
  .pp { position: absolute; left: 50%; top: 44%; transform: translate(-50%, -50%); width: 68px; height: 68px; border-radius: 50%; border: 2px solid rgba(255,255,255,.6); background: rgba(20,4,40,.55); display: flex; align-items: center; justify-content: center; padding: 0; animation: pulse 2.4s ease-in-out infinite; }
  .pp:active { transform: translate(-50%, -50%) scale(.94); }
  .sbot { position: absolute; left: 12px; right: 12px; bottom: 8px; }
  .seek { position: relative; height: 22px; touch-action: none; cursor: pointer; }
  .track { position: absolute; left: 0; right: 0; top: 9px; height: 4px; border-radius: 2px; background: rgba(255,255,255,.3); }
  .fill { position: absolute; left: 0; top: 9px; height: 4px; border-radius: 2px; background: linear-gradient(90deg, #7b2ff7, #ff2d75); box-shadow: 0 0 8px rgba(255,45,117,.8); width: 0; }
  .knob { position: absolute; top: 4px; left: 0; width: 14px; height: 14px; border-radius: 50%; background: #fff; box-shadow: 0 0 10px #ff7ad9; transform: translateX(-50%); }
  .times { display: flex; justify-content: space-between; font-size: 11px; font-weight: 700; color: #fff; }
  .body { padding: 12px 14px 0; }
  .wt { font-size: 17px; font-weight: 800; line-height: 1.3; }
  .meta { font-size: 12px; color: #c4a9f2; margin-top: 4px; }
  .chan { display: flex; align-items: center; gap: 12px; padding: 14px 0; border-bottom: 1px solid rgba(193,60,255,.25); }
  .av { width: 40px; height: 40px; border-radius: 50%; background: linear-gradient(135deg, #7b2ff7, #ff2d75); display: flex; align-items: center; justify-content: center; font-weight: 800; font-size: 16px; flex: none; box-shadow: 0 0 0 2px rgba(255,255,255,.25), 0 0 14px rgba(193,60,255,.7); }
  .cn { flex: 1; min-width: 0; }
  .cn b { display: block; font-size: 13px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .cn small { font-size: 11px; color: #c4a9f2; }
  .sub { border: 0; background: linear-gradient(90deg, #ff2d75, #c13cff); color: #fff; font-weight: 800; font-size: 12px; letter-spacing: .6px; padding: 9px 16px; border-radius: 999px; box-shadow: 0 0 16px rgba(255,45,117,.55); }
  .sub:active { transform: scale(.95); }
  .chips2 { display: flex; gap: 8px; overflow-x: auto; padding: 14px 0 6px; }
  .c2 { flex: none; padding: 9px 15px; border: 1px solid rgba(193,60,255,.4); border-radius: 999px; background: rgba(255,255,255,.08); color: #fff; font-size: 12px; font-weight: 700; }
  .c2:active { transform: scale(.96); }
  .c2.on { background: linear-gradient(90deg, #7b2ff7, #ff2d75); border-color: transparent; box-shadow: 0 0 14px rgba(193,60,255,.7); }
  .msg { font-size: 12px; color: #e0d3f7; min-height: 16px; padding: 6px 0; }
  .sh { font-size: 14px; font-weight: 800; padding: 10px 0 10px; letter-spacing: .3px; }
  .sh::before { content: "◆"; color: #ff7ad9; margin-right: 8px; text-shadow: 0 0 10px #ff2d75; }
  .vc { margin: 0 0 16px; border-radius: 18px; overflow: hidden; background: rgba(255,255,255,.05); border: 1px solid rgba(193,60,255,.30); box-shadow: 0 8px 24px rgba(0,0,0,.35); animation: rise .45s ease both; }
  .vc:active { transform: scale(.985); }
  .vt { position: relative; width: 100%; aspect-ratio: 16 / 9; background: #2a0f4a; overflow: hidden; }
  .vt img { position: relative; width: 100%; height: 100%; object-fit: cover; display: block; }
  .vt::before { content: ""; position: absolute; left: 0; right: 0; bottom: 0; height: 45%; background: linear-gradient(transparent, rgba(13,2,25,.78)); z-index: 1; pointer-events: none; }
  .vt::after { content: "▶"; position: absolute; left: 50%; top: 50%; transform: translate(-50%, -50%); width: 48px; height: 48px; border-radius: 50%; background: rgba(20,4,40,.55); border: 1px solid rgba(255,255,255,.4); display: flex; align-items: center; justify-content: center; font-size: 18px; padding-left: 3px; box-shadow: 0 0 16px rgba(193,60,255,.6); z-index: 2; pointer-events: none; }
  .stage::after, .stage::before { display: none; }
  .dur { position: absolute; right: 8px; bottom: 8px; background: rgba(0,0,0,.72); border: 1px solid rgba(255,255,255,.18); font-size: 11px; font-weight: 700; padding: 2px 7px; border-radius: 999px; z-index: 3; }
  .vi { padding: 10px 12px 12px; }
  .vtt { font-size: 14px; font-weight: 700; line-height: 1.28; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
  .vch { font-size: 12px; color: #c4a9f2; margin-top: 4px; }
  .fab { position: absolute; right: 10px; bottom: 14px; display: flex; flex-direction: column; gap: 8px; z-index: 6; }
  .fab button { width: 40px; height: 40px; border-radius: 50%; border: 1px solid rgba(255,255,255,.35); background: linear-gradient(135deg, #7b2ff7, #c13cff); color: #fff; font-size: 15px; box-shadow: 0 0 16px rgba(193,60,255,.7), 0 4px 10px rgba(0,0,0,.4); }
  .fab button:active { transform: scale(.92); }
</style>
</head>
<body>
<div class="app">
  <div class="scroll" id="sc">
    <div class="stage">
      ${cover ? '<img src="' + cover + '" alt="">' : ''}
      <div class="shade"></div>
      <button class="pp" id="pp"><span id="ic"></span></button>
      <div class="sbot">
        <div class="seek" id="seek"><div class="track"></div><div class="fill" id="fill"></div><div class="knob" id="knob"></div></div>
        <div class="times"><span id="cur">0:00</span><span id="tot">${fmtTime(seconds)}</span></div>
      </div>
    </div>

    <div class="body">
      <div class="wt">${esc(title)}</div>
      <div class="meta">${esc(author)} • ${fmtTime(seconds)}</div>

      <div class="chan">
        <div class="av">${inicial}</div>
        <div class="cn"><b>${esc(author)}</b><small>${esc(BOT_NAME)}</small></div>
        <button class="sub" id="dl">BAIXAR</button>
      </div>

      <div class="chips2">
        <button class="c2" id="b10">⏪ 10s</button>
        <button class="c2" id="f10">10s ⏩</button>
        <button class="c2" id="rp">🔁 Repetir</button>
        <button class="c2" id="like">👍 Curtir</button>
        <button class="c2" id="bg">🎧 Segundo plano</button>
        <button class="c2" id="share">↗ Partilhar</button>
      </div>
      <div class="msg" id="msg">Toque no ▶ para ouvir.</div>

      ${relDados.length ? '<div class="sh">A seguir</div><div id="rel"></div>' : ''}
    </div>
  </div>
  <div class="fab"><button id="up">▲</button><button id="dn">▼</button></div>
</div>

<script>
(function () {
  var VID = ${jsStr(videoId)};
  var P = ${jsStr(prefixo)};
  var TOTAL = ${Number(seconds) || 0};
  var B64 = "${audioB64}";
  var REL = ${seguro(relDados)};
  var TH = ${seguro(relThumbs || {})};
  var PLAY = ${jsStr(svgPlay)};
  var PAUSE = ${jsStr(svgPause)};

  function $(id) { return document.getElementById(id); }
  function esc(s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }
  function fmt(s) { s = Math.max(0, Math.floor(s || 0)); var r = s % 60; return Math.floor(s / 60) + ':' + (r < 10 ? '0' : '') + r; }
  function msg(t) { $('msg').textContent = t; }

  var E = { ctx: null, buf: null, src: null, loading: null, playing: false, offset: 0, startedAt: 0, loop: false };

  function ensureCtx() {
    if (!E.ctx) {
      var AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return null;
      try { E.ctx = new AC(); } catch (e) { return null; }
    }
    if (E.ctx.state === 'suspended' && E.ctx.resume) { try { E.ctx.resume(); } catch (e) {} }
    return E.ctx;
  }
  function decode(c, ab) {
    return new Promise(function (resolve, reject) {
      var done = false;
      function ok(b) { if (done) return; done = true; resolve(b); }
      function bad(e) { if (done) return; done = true; reject(e || new Error('falha ao decodificar')); }
      var p = c.decodeAudioData(ab, ok, bad);
      if (p && p.then) p.then(ok, bad);
    });
  }
  function load() {
    if (E.loading) return E.loading;
    E.loading = new Promise(function (resolve, reject) {
      var c = ensureCtx();
      if (!c) { reject(new Error('sem suporte a áudio')); return; }
      var bin = atob(B64), n = bin.length, u8 = new Uint8Array(n);
      for (var i = 0; i < n; i++) u8[i] = bin.charCodeAt(i);
      decode(c, u8.buffer).then(function (b) { E.buf = b; resolve(b); }, reject);
    });
    return E.loading;
  }
  function dur() { return E.buf ? E.buf.duration : TOTAL; }
  function pos() {
    if (!E.playing) return E.offset;
    var d = dur() || 1;
    var t = E.offset + (E.ctx.currentTime - E.startedAt);
    if (E.loop) t = t % d;
    return Math.min(t, d);
  }
  function icon() { $('ic').innerHTML = E.playing ? PAUSE : PLAY; }
  function upd() {
    var t = pos(), d = dur() || 1;
    var p = Math.min(100, Math.max(0, (t / d) * 100));
    $('fill').style.width = p + '%';
    $('knob').style.left = p + '%';
    $('cur').textContent = fmt(t);
    $('tot').textContent = fmt(dur());
  }
  function stopSrc() {
    if (E.src) {
      E.src.onended = null;
      try { E.src.stop(); } catch (e) {}
      try { E.src.disconnect(); } catch (e) {}
      E.src = null;
    }
  }
  function startAt(t) {
    stopSrc();
    var s = E.ctx.createBufferSource();
    s.buffer = E.buf; s.loop = E.loop; s.connect(E.ctx.destination);
    s.onended = function () { if (E.src === s) { E.src = null; E.playing = false; E.offset = 0; icon(); upd(); msg('Terminou. Toque no ▶ para ouvir de novo.'); } };
    E.src = s; E.offset = t; E.startedAt = E.ctx.currentTime;
    s.start(0, t);
    E.playing = true;
    icon();
  }
  function seekTo(t) {
    var d = dur();
    t = Math.max(0, t);
    if (d) t = Math.min(t, Math.max(0, d - 0.05));
    if (E.playing && E.buf) startAt(t); else E.offset = t;
    upd();
  }
  $('pp').addEventListener('click', function () {
    if (E.playing) { E.offset = pos(); stopSrc(); E.playing = false; icon(); upd(); msg('Pausado.'); return; }
    var c = ensureCtx();
    if (!c) { msg('Áudio não suportado neste aparelho.'); return; }
    msg('Carregando áudio...');
    load().then(function () {
      ensureCtx();
      startAt(E.buf && E.offset >= E.buf.duration - 0.1 ? 0 : E.offset);
      msg('Tocando.');
    }).catch(function (e) { E.loading = null; msg('Este aparelho não conseguiu tocar o áudio aqui. Use ⬇ BAIXAR ou mande: ' + P + 'tube mp3 ' + VID); });
  });
  $('b10').addEventListener('click', function () { seekTo(pos() - 10); });
  $('f10').addEventListener('click', function () { seekTo(pos() + 10); });
  $('rp').addEventListener('click', function () {
    E.loop = !E.loop;
    if (E.src) E.src.loop = E.loop;
    $('rp').className = 'c2' + (E.loop ? ' on' : '');
  });

  var drag = false;
  function seekEvent(e) {
    var r = $('seek').getBoundingClientRect();
    var p = Math.min(1, Math.max(0, (e.clientX - r.left) / r.width));
    seekTo(p * dur());
  }
  $('seek').addEventListener('pointerdown', function (e) {
    drag = true;
    if ($('seek').setPointerCapture) { try { $('seek').setPointerCapture(e.pointerId); } catch (x) {} }
    seekEvent(e);
  });
  $('seek').addEventListener('pointermove', function (e) { if (drag) seekEvent(e); });
  $('seek').addEventListener('pointerup', function () { drag = false; });
  $('seek').addEventListener('pointercancel', function () { drag = false; });

  // ---------- ações que precisam do bot (copiam o comando) ----------
  function copiar(texto, cb) {
    function fallback() {
      try {
        var t = document.createElement('textarea');
        t.value = texto; t.style.position = 'fixed'; t.style.opacity = '0';
        document.body.appendChild(t); t.focus(); t.select();
        var ok = document.execCommand('copy');
        document.body.removeChild(t);
        cb(!!ok);
      } catch (e) { cb(false); }
    }
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(texto).then(function () { cb(true); }, fallback);
    } else { fallback(); }
  }
  function comando(cmd, textoOk) {
    copiar(cmd, function (ok) { msg(ok ? '✅ ' + textoOk + ' (' + cmd + ')' : 'Copie e cole no chat: ' + cmd); });
  }
  $('dl').addEventListener('click', function () { comando(P + 'tube baixar ' + VID, 'Comando copiado! Cole no chat e o bot manda o MP3.'); });
  $('bg').addEventListener('click', function () { comando(P + 'tube baixar ' + VID, 'Para ouvir em segundo plano, baixe o MP3. Comando copiado, cole no chat.'); });
  $('share').addEventListener('click', function () {
    copiar('https://youtu.be/' + VID, function (ok) { msg(ok ? '✅ Link copiado!' : 'https://youtu.be/' + VID); });
  });
  var liked = false;
  $('like').addEventListener('click', function () {
    liked = !liked;
    $('like').className = 'c2' + (liked ? ' on' : '');
    $('like').textContent = liked ? '👍 Curtiu' : '👍 Curtir';
  });

  // ---------- A seguir ----------
  if (REL.length) {
    var h = '';
    for (var i = 0; i < REL.length; i++) {
      var v = REL[i];
      h += '<div class="vc" data-id="' + esc(v.id) + '"><div class="vt"><img alt="" src="' + (TH[v.id] || '') + '">' +
        (v.d ? '<span class="dur">' + fmt(v.d) + '</span>' : '') + '</div><div class="vi"><div class="vtt">' + esc(v.t) +
        '</div><div class="vch">' + esc(v.a) + '</div></div></div>';
    }
    $('rel').innerHTML = h;
    $('rel').addEventListener('click', function (e) {
      var el = e.target && e.target.closest ? e.target.closest('[data-id]') : null;
      if (el) comando(P + 'tube play ' + el.getAttribute('data-id'), 'Comando copiado! Cole no chat para tocar esta.');
    });
  }

  // ---------- rolagem por botões ----------
  function rolar(d) {
    var el = $('sc');
    var dy = Math.round((el.clientHeight || 300) * 0.8) * d;
    try { if (el.scrollBy) { el.scrollBy({ top: dy, behavior: 'smooth' }); return; } } catch (e) {}
    el.scrollTop = (el.scrollTop || 0) + dy;
  }
  $('up').addEventListener('click', function () { rolar(-1); });
  $('dn').addEventListener('click', function () { rolar(1); });

  setInterval(upd, 250);
  icon();
  upd();
  setTimeout(function () { load().catch(function () { E.loading = null; }); }, 300);
})();
</script>
</body>
</html>`
}

// ---------- diagnóstico 2: o que o card consegue carregar do servidor do bot ----------
function buildDiag2Html({ base, token, titulo, inline }) {
  return `<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<style>${cssBase(inline, '92%')}
  .r { font-size: 12px; padding: 6px 8px; margin: 4px 0; border-radius: 8px; background: rgba(255,255,255,.07); word-break: break-word; }
  .r.ok { background: rgba(60,200,120,.28); }
  .r.bad { background: rgba(255,60,90,.30); }
  .v { font-size: 14px; font-weight: bold; padding: 10px; margin-top: 10px; border-radius: 10px; }
  .v.ok { background: rgba(60,200,120,.45); }
  .v.bad { background: rgba(255,60,90,.5); }
</style>
</head>
<body>
<div class="card">
  <div class="logo"><b>🔧 ${esc(titulo)}</b></div>
  <div class="q" style="margin-top:8px">Aguarde uns 8 segundos e tire um print.</div>
  <div id="out"></div>
</div>
<script>
(function () {
  var API = ${jsStr(base)};
  var K = ${jsStr(token)};
  var out = document.getElementById('out');
  var rows = {};
  function linha(k) {
    var d = document.createElement('div');
    d.className = 'r'; d.textContent = k + ': ...';
    out.appendChild(d); rows[k] = { el: d, done: false };
  }
  var SERVIDOR = ['fetch (CORS) no servidor', 'fetch (no-cors) no servidor', 'XMLHttpRequest no servidor', 'imagem <img> do servidor', 'script <script> (JSONP) do servidor', 'áudio <audio> do servidor'];
  var funcionou = [];
  function res(k, ok, t) {
    var r = rows[k];
    if (!r || r.done) return;
    r.done = true;
    if (ok && SERVIDOR.indexOf(k) >= 0) funcionou.push(k);
    r.el.className = 'r ' + (ok ? 'ok' : 'bad');
    r.el.textContent = k + ': ' + (ok ? 'OK' : 'BLOQUEADO') + (t ? ' (' + t + ')' : '');
  }
  function teste(k, iniciar) {
    linha(k);
    try { iniciar(function (ok, t) { res(k, ok, t); }); } catch (e) { res(k, false, 'erro: ' + e.message); }
    setTimeout(function () { res(k, false, 'sem resposta em 7s'); }, 7000);
  }
  function msg(e) { return e && e.message ? e.message : String(e); }

  teste('fetch (CORS) no servidor', function (fim) {
    fetch(API + '/ping?k=' + K).then(function (r) { fim(r.ok, 'HTTP ' + r.status); }).catch(function (e) { fim(false, msg(e)); });
  });
  teste('fetch (no-cors) no servidor', function (fim) {
    fetch(API + '/ping?k=' + K, { mode: 'no-cors' }).then(function () { fim(true, 'resposta opaca'); }).catch(function (e) { fim(false, msg(e)); });
  });
  teste('XMLHttpRequest no servidor', function (fim) {
    var x = new XMLHttpRequest();
    x.open('GET', API + '/ping?k=' + K);
    x.onload = function () { fim(x.status === 200, 'HTTP ' + x.status); };
    x.onerror = function () { fim(false, 'erro de rede'); };
    x.send();
  });
  teste('imagem <img> do servidor', function (fim) {
    var im = new Image();
    im.onload = function () { fim(true, 'carregou'); };
    im.onerror = function () { fim(false, 'erro'); };
    im.src = API + '/pix?k=' + K + '&t=' + Date.now();
  });
  teste('script <script> (JSONP) do servidor', function (fim) {
    window.cbdiag = function (o) { fim(!!(o && o.ok), 'callback chamado'); };
    var s = document.createElement('script');
    s.onerror = function () { fim(false, 'erro ao carregar'); };
    s.src = API + '/jsonp?k=' + K + '&cb=cbdiag&t=' + Date.now();
    (document.head || document.body).appendChild(s);
  });
  teste('áudio <audio> do servidor', function (fim) {
    var a = new Audio();
    a.preload = 'auto';
    a.addEventListener('canplay', function () { fim(true, 'pronto para tocar'); });
    a.addEventListener('error', function () { fim(false, 'erro ' + (a.error && a.error.code)); });
    a.src = API + '/beep?k=' + K + '&t=' + Date.now();
    a.load();
  });
  teste('fetch api.github.com', function (fim) {
    fetch('https://api.github.com/zen').then(function (r) { fim(r.ok, 'HTTP ' + r.status); }).catch(function (e) { fim(false, msg(e)); });
  });
  setTimeout(function () {
    var d = document.createElement('div');
    if (funcionou.length) {
      d.className = 'v ok';
      d.textContent = '✅ VEREDITO: o card CONSEGUE falar com o servidor do bot por: ' + funcionou.join(', ') + '. Dá pra fazer o app!';
    } else {
      d.className = 'v bad';
      d.textContent = '❌ VEREDITO: o card NÃO consegue falar com o servidor do bot (nada abriu).';
    }
    out.appendChild(d);
  }, 8000);
  teste('script do cdnjs', function (fim) {
    var s = document.createElement('script');
    s.onload = function () { fim(true, 'carregou'); };
    s.onerror = function () { fim(false, 'erro'); };
    s.src = 'https://cdnjs.cloudflare.com/ajax/libs/lodash.js/4.17.21/lodash.min.js';
    (document.head || document.body).appendChild(s);
  });
})();
</script>
</body>
</html>`
}

// ---------- botões nativos do WhatsApp (quick_reply) ----------
async function enviarBotoes(columbina, from, { texto, rodape, botoes }) {
  await columbina.relayMessage(
    from,
    {
      viewOnceMessage: {
        message: {
          messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
          interactiveMessage: {
            body: { text: texto },
            footer: { text: rodape || BOT_NAME },
            header: { title: '', subtitle: '', hasMediaAttachment: false },
            nativeFlowMessage: {
              buttons: botoes.map((b) => ({
                name: 'quick_reply',
                buttonParamsJson: JSON.stringify({ display_text: b.texto, id: b.id }),
              })),
            },
          },
        },
      },
    },
    {}
  )
}

// ---------- lista nativa (single_select) ----------
async function enviarLista(columbina, from, { texto, botao, secao, linhas, rodape }) {
  await columbina.relayMessage(
    from,
    {
      viewOnceMessage: {
        message: {
          messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
          interactiveMessage: {
            body: { text: texto },
            footer: { text: rodape || BOT_NAME },
            header: { title: '', subtitle: '', hasMediaAttachment: false },
            nativeFlowMessage: {
              buttons: [
                {
                  name: 'single_select',
                  buttonParamsJson: JSON.stringify({
                    title: botao,
                    sections: [{ title: secao, rows: linhas }],
                  }),
                },
              ],
            },
          },
        },
      },
    },
    {}
  )
}

// ações que cada música pode ter (o botão manda "!tube <ação> <id do vídeo>")
const ACOES_BOTAO = [
  { acao: 'play', texto: '▶ Tocar aqui' },
  { acao: 'baixar', texto: '⬇ Baixar MP3' },
  { acao: 'mp3', texto: '🎵 Áudio no chat' },
  { acao: 'video', texto: '🎬 Vídeo' },
]

function botoesDoVideo(video, p, exceto = []) {
  return ACOES_BOTAO.filter((b) => !exceto.includes(b.acao))
    .slice(0, 3)
    .map((b) => ({ texto: b.texto, id: idBtn(p, b.acao, video.id) }))
}

// ---------- envio (mesmo formato do plugin piano) ----------
function montarDados(html, trusted = TRUSTED, modo = EXIBICAO) {
  const htmlPrimitive = {
    __typename: 'GenAIaeacdsnwHtmlPrimitive',
    payload: html,
    trusted_sources: trusted,
  }

  // card direto na mensagem
  if (modo === 'inline') {
    return {
      response_id: 'tube-player',
      sections: [
        {
          view_model: {
            primitive: htmlPrimitive,
            __typename: 'GenAISingleLayoutViewModel',
          },
        },
      ],
    }
  }

  // folha que sobe (igual ao piano)
  return {
    response_id: 'tube-player',
    sections: [
      {
        view_model: {
          primitive: {
            text: '> Player interativo</>',
            __typename: 'GenAIMarkdownTextUXPrimitive',
          },
          __typename: 'GenAISingleLayoutViewModel',
        },
      },
    ],
    embedded_screens: [
      {
        title: 'PLAY2',
        content: [
          {
            __typename: 'FOAIDNixelButtonSheets',
            tabs: [
              {
                id: 'tab_0',
                tab_header: 'Player',
                sections: [
                  {
                    __typename: 'GenAIUnifiedResponseSection',
                    view_model: {
                      __typename: 'GenAISingleLayoutViewModel',
                      primitive: htmlPrimitive,
                    },
                  },
                ],
              },
            ],
          },
        ],
      },
    ],
  }
}

async function enviarPlayer(columbina, from, html, trusted, modo) {
  await columbina.relayMessage(
    from,
    {
      messageContextInfo: {
        deviceListMetadata: {},
        deviceListMetadataVersion: 2,
      },
      botForwardedMessage: {
        message: {
          richResponseMessage: {
            messageType: 1,
            submessages: [
              {
                messageType: 2,
                messageText: BOT_NAME,
              },
            ],
            unifiedResponse: {
              data: Buffer.from(JSON.stringify(montarDados(html, trusted, modo))).toString('base64'),
            },
            contextInfo: {
              forwardingScore: 1,
              isForwarded: true,
              forwardedAiBotMessageInfo: {
                botJid: '867051314767696@bot',
              },
              forwardOrigin: 4,
            },
          },
        },
      },
    },
    {}
  )
}

// ============================================================
//  MODO APP — servidor local + túnel + página do "YouTube"
// ============================================================
const APP = { server: null, port: 0, token: '', url: '', tunnel: null, iniciando: null }
const CACHE_DIR = path.join(os.tmpdir(), 'tube_app_cache')
const buscasCache = new Map()
const thumbsCache = new Map()
const jobs = new Map()
const fila = []
let ativos = 0

let ATUALIZADO_EM = 0

const errCurto = (e) =>
  String((e && e.stderr) || (e && e.message) || e)
    .split('\n')
    .filter((l) => /error/i.test(l))
    .pop() || String((e && e.message) || e).split('\n')[0]

function limparCache() {
  try {
    const arqs = fs
      .readdirSync(CACHE_DIR)
      .map((f) => ({ f, t: fs.statSync(path.join(CACHE_DIR, f)).mtimeMs }))
      .sort((a, b) => b.t - a.t)
    arqs.forEach((a, k) => {
      if (k >= 40 || Date.now() - a.t > 3 * 3600 * 1000) fs.rmSync(path.join(CACHE_DIR, a.f), { force: true })
    })
  } catch {}
}

function rodarFila() {
  while (ativos < 2 && fila.length) {
    const job = fila.shift()
    ativos++
    job.run().catch(() => {}).finally(() => {
      ativos--
      rodarFila()
    })
  }
}

// prepara o áudio de um vídeo: variante 'st' (leve, para tocar) ou 'dl' (128k estéreo com capa, para baixar)
function prepararAudio(id, variante) {
  const chave = variante + ':' + id
  const antigo = jobs.get(chave)
  if (antigo && (antigo.status === 'pending' || (antigo.status === 'ready' && fs.existsSync(antigo.file)))) return antigo

  const job = { status: 'pending', file: path.join(CACHE_DIR, `${id}_${variante}.mp3`), seconds: 0, erro: '' }
  jobs.set(chave, job)
  job.run = async () => {
    let dir
    try {
      fs.mkdirSync(CACHE_DIR, { recursive: true })
      dir = fs.mkdtempSync(path.join(os.tmpdir(), 'tubeapp_'))
      const info = pegarVideo(id) || { id, title: 'Música', author: 'YouTube', seconds: 0 }
      if (excede(info.seconds, MAX_APP_SECONDS)) {
        throw new Error('Música muito longa (limite ' + fmtTime(MAX_APP_SECONDS) + ')')
      }
      const bruto = await baixarAudioBruto('https://www.youtube.com/watch?v=' + id, dir)
      job.seconds = info.seconds || (await probeSeconds(bruto))
      if (variante === 'dl') {
        await makeCover(id, dir)
        const out = await mp3Completo(bruto, dir, info, path.join(dir, 'cover.jpg'))
        fs.copyFileSync(out, job.file)
      } else {
        await encodeMp3(bruto, job.file, { kbps: 80, mono: true, ar: 32000 })
      }
      job.status = 'ready'
      limparCache()
    } catch (e) {
      job.status = 'error'
      job.erro = errCurto(e).slice(0, 160)
      console.error('[tube-app] falha ao preparar', id, job.erro)
    } finally {
      if (dir) fs.rm(dir, { recursive: true, force: true }, () => {})
    }
  }
  fila.push(job)
  rodarFila()
  return job
}

function enviarArquivo(req, res, file, headers) {
  const size = fs.statSync(file).size
  const base = { 'Content-Type': 'audio/mpeg', 'Accept-Ranges': 'bytes', 'Cache-Control': 'no-store', ...headers }
  const range = req.headers.range
  if (range) {
    const m = /bytes=(\d*)-(\d*)/.exec(range)
    let start = m && m[1] ? parseInt(m[1], 10) : 0
    let end = m && m[2] ? parseInt(m[2], 10) : size - 1
    if (isNaN(start) || start >= size) {
      res.writeHead(416, { ...base, 'Content-Range': `bytes */${size}` })
      return res.end()
    }
    end = Math.min(end, size - 1)
    res.writeHead(206, { ...base, 'Content-Range': `bytes ${start}-${end}/${size}`, 'Content-Length': end - start + 1 })
    return fs.createReadStream(file, { start, end }).pipe(res)
  }
  res.writeHead(200, { ...base, 'Content-Length': size })
  fs.createReadStream(file).pipe(res)
}

function criarServidor() {
  const cors = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': '*',
    'Access-Control-Allow-Methods': 'GET, OPTIONS',
    'Access-Control-Expose-Headers': 'Content-Range, Accept-Ranges, Content-Length',
  }

  return http.createServer(async (req, res) => {
    const json = (code, obj) => {
      res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...cors })
      res.end(JSON.stringify(obj))
    }
    try {
      if (req.method === 'OPTIONS') {
        res.writeHead(204, cors)
        return res.end()
      }
      const u = new URL(req.url, 'http://local')
      if (u.searchParams.get('k') !== APP.token) return json(403, { erro: 'acesso negado' })

      if (u.pathname === '/ping') return json(200, { ok: true })

      // página do app completo (abre no navegador do celular)
      if (u.pathname === '/app' || u.pathname === '/') {
        const html = buildAppHtml({
          base: APP.url || `https://${req.headers.host}`,
          token: APP.token,
          consulta: (u.searchParams.get('q') || '').trim().slice(0, 100),
          prefixo: PREFIXO,
          inline: false,
        })
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' })
        return res.end(html)
      }

      if (u.pathname === '/search') {
        const q = (u.searchParams.get('q') || APP_HOME).trim().slice(0, 100)
        const n = Math.min(30, Math.max(1, parseInt(u.searchParams.get('n') || '20', 10) || 20))
        const chave = q.toLowerCase() + '|' + n
        const c = buscasCache.get(chave)
        if (c && Date.now() - c.ts < 10 * 60 * 1000) return json(200, c.itens)
        const itens = (await searchVideos(q, n)).map((v) => ({ id: v.id, title: v.title, author: v.author, seconds: v.seconds }))
        buscasCache.set(chave, { ts: Date.now(), itens })
        if (buscasCache.size > 100) buscasCache.delete(buscasCache.keys().next().value)
        return json(200, itens)
      }

      // rotas usadas só pelo diagnóstico (!tube teste2)
      if (u.pathname === '/pix') {
        res.writeHead(200, { 'Content-Type': 'image/gif', 'Cache-Control': 'no-store', ...cors })
        return res.end(Buffer.from('R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7', 'base64'))
      }
      if (u.pathname === '/jsonp') {
        const cb = u.searchParams.get('cb') || ''
        if (!/^[A-Za-z_][A-Za-z0-9_]{0,30}$/.test(cb)) return json(400, { erro: 'cb inválido' })
        res.writeHead(200, { 'Content-Type': 'application/javascript; charset=utf-8', 'Cache-Control': 'no-store', ...cors })
        return res.end(`${cb}({"ok":true,"t":${Date.now()}});`)
      }
      if (u.pathname === '/beep') {
        const arq = path.join(CACHE_DIR, 'beep.mp3')
        if (!fs.existsSync(arq)) {
          fs.mkdirSync(CACHE_DIR, { recursive: true })
          await execFileP('ffmpeg', ['-y', '-f', 'lavfi', '-i', 'sine=frequency=440:duration=1', '-c:a', 'libmp3lame', '-b:a', '32k', arq], { timeout: 30000 })
        }
        return enviarArquivo(req, res, arq, cors)
      }

      const m = u.pathname.match(/^\/(thumb|prep|audio|dl)\/([A-Za-z0-9_-]{11})$/)
      if (!m) return json(404, { erro: 'não encontrado' })
      const [, tipo, id] = m

      if (tipo === 'thumb') {
        let buf = thumbsCache.get(id)
        if (!buf) {
          const r = await fetch(`https://i.ytimg.com/vi/${id}/mqdefault.jpg`)
          if (!r.ok) return json(404, { erro: 'sem capa' })
          buf = Buffer.from(await r.arrayBuffer())
          thumbsCache.set(id, buf)
          if (thumbsCache.size > 200) thumbsCache.delete(thumbsCache.keys().next().value)
        }
        res.writeHead(200, { 'Content-Type': 'image/jpeg', 'Cache-Control': 'public, max-age=86400', ...cors })
        return res.end(buf)
      }

      if (tipo === 'prep') {
        const job = prepararAudio(id, 'st')
        return json(200, { status: job.status, seconds: job.seconds, erro: job.erro })
      }

      if (tipo === 'audio') {
        const job = jobs.get('st:' + id)
        if (!job || job.status !== 'ready' || !fs.existsSync(job.file)) return json(404, { erro: 'áudio ainda não está pronto' })
        return enviarArquivo(req, res, job.file, cors)
      }

      // tipo === 'dl': espera ficar pronto e entrega como arquivo para baixar
      const job = prepararAudio(id, 'dl')
      let cancelado = false
      req.on('close', () => (cancelado = true))
      const limite = Date.now() + 85000
      while (job.status === 'pending' && !cancelado && Date.now() < limite) {
        await new Promise((ok) => setTimeout(ok, 500))
      }
      if (cancelado) return
      if (job.status !== 'ready') return json(job.status === 'error' ? 500 : 504, { erro: job.erro || 'demorou demais, tente de novo' })
      const info = pegarVideo(id)
      const nome = encodeURIComponent(limparNome(info ? info.title : id) + '.mp3')
      return enviarArquivo(req, res, job.file, { ...cors, 'Content-Disposition': `attachment; filename*=UTF-8''${nome}` })
    } catch (e) {
      console.error('[tube-app] erro no servidor:', e && e.message)
      try {
        json(500, { erro: errCurto(e).slice(0, 160) })
      } catch {}
    }
  })
}

// abre um túnel https público (cloudflared ou, se não tiver, ssh + localhost.run)
function iniciarTunel(porta) {
  return new Promise((resolve, reject) => {
    const tentativas = [
      { cmd: 'cloudflared', args: ['tunnel', '--no-autoupdate', '--url', `http://127.0.0.1:${porta}`] },
      {
        cmd: 'ssh',
        args: [
          '-o', 'StrictHostKeyChecking=no',
          '-o', 'ServerAliveInterval=30',
          '-o', 'ExitOnForwardFailure=yes',
          '-R', `80:127.0.0.1:${porta}`,
          'nokey@localhost.run',
        ],
      },
    ]
    const re = /https:\/\/(?!(?:api|admin|docs)\.)[a-z0-9-]+\.(?:trycloudflare\.com|lhr\.life|localhost\.run)/i
    let i = 0

    const motivos = []

    const tentar = () => {
      if (i >= tentativas.length) {
        return reject(new Error('nenhum túnel funcionou (' + motivos.join('; ') + '). Instale com: pkg install cloudflared'))
      }
      const t = tentativas[i++]
      let achou = false
      let seguiu = false
      let proc = null
      let ultimaLinha = ''

      const timer = setTimeout(() => falhou('sem resposta em 30s'), 30000)
      const seguir = () => {
        if (seguiu) return
        seguiu = true
        clearTimeout(timer)
        try {
          if (proc) proc.kill()
        } catch {}
        tentar()
      }
      const falhou = (motivo) => {
        if (achou || seguiu) return
        motivos.push(`${t.cmd}: ${motivo}` + (ultimaLinha ? ` [${ultimaLinha}]` : ''))
        seguir()
      }
      const ler = (d) => {
        const txt = String(d).trim()
        if (txt) ultimaLinha = txt.split('\n').pop().slice(0, 80)
        const m = re.exec(txt)
        if (m && !achou) {
          achou = true
          clearTimeout(timer)
          APP.tunnel = proc
          resolve(m[0])
        }
      }

      try {
        proc = spawn(t.cmd, t.args, { stdio: ['ignore', 'pipe', 'pipe'] })
      } catch (e) {
        return falhou(e.message)
      }
      proc.on('error', (e) => falhou(e && e.code === 'ENOENT' ? 'não instalado' : e.message))
      proc.stdout.on('data', ler)
      proc.stderr.on('data', ler)
      proc.on('exit', (code) => {
        if (achou) {
          APP.url = ''
          APP.tunnel = null
        } else {
          falhou(`encerrou (código ${code})`)
        }
      })
    }
    tentar()
  })
}

// o cloudflared mostra o endereço antes de ele estar realmente no ar: espera responder
async function aguardarNoAr(url, token) {
  for (let k = 0; k < 12; k++) {
    try {
      const r = await fetch(`${url}/ping?k=${token}`, { signal: AbortSignal.timeout(4000) })
      if (r.ok) return true
    } catch {}
    await new Promise((ok) => setTimeout(ok, 2000))
  }
  return false
}

async function iniciarApp() {
  if (APP.url && APP.server) return APP
  if (APP.iniciando) return APP.iniciando
  APP.iniciando = (async () => {
    if (!APP.server) {
      APP.token = crypto.randomBytes(9).toString('hex')
      APP.server = criarServidor()
      await new Promise((ok, erro) => {
        APP.server.once('error', erro)
        APP.server.listen(APP_PORTA, '127.0.0.1', ok)
      })
      APP.port = APP.server.address().port
    }
    APP.url = APP_URL_PUBLICA || (await iniciarTunel(APP.port))
    APP.noAr = await aguardarNoAr(APP.url, APP.token)
    console.log('[tube-app] ' + APP.url + (APP.noAr ? ' (respondendo)' : ' (NÃO respondeu ao teste local)'))
    return APP
  })().finally(() => {
    APP.iniciando = null
  })
  return APP.iniciando
}

if (!G.exitHook) {
  G.exitHook = true
  process.on('exit', () => {
    try {
      if (APP.tunnel) APP.tunnel.kill()
    } catch {}
  })
}

// ---------- página do app (o "YouTube") ----------
function buildAppHtml({ base, token, consulta, prefixo, inline }) {
  const bodyBg = inline ? '#202c33' : '#0d0219'
  const alturaApp = inline ? APP_ALTURA + 'px' : '100vh'
  const svgPlay = (cor) => `<svg width="30" height="30" viewBox="0 0 24 24"><polygon points="8 4 20 12 8 20" fill="${cor}"/></svg>`
  const svgPause = (cor) =>
    `<svg width="30" height="30" viewBox="0 0 24 24"><rect x="6" y="4" width="4" height="16" rx="1" fill="${cor}"/><rect x="14" y="4" width="4" height="16" rx="1" fill="${cor}"/></svg>`
  const svgSkip = (dir) =>
    `<svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${
      dir < 0
        ? '<polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"/>'
        : '<polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/>'
    }<text x="12" y="15.2" font-size="7" font-weight="bold" text-anchor="middle" fill="currentColor" stroke="none">10</text></svg>`

  return `<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover">
<meta name="theme-color" content="#21093f">
<title>${esc(BOT_NAME)}</title>
<style>
  * { box-sizing: border-box; -webkit-tap-highlight-color: transparent; }
  html, body { margin: 0; padding: 0; background: ${bodyBg}; color: #fff; font-family: Arial, Helvetica, sans-serif; overflow: hidden; }
  button { font-family: inherit; }
  .app { height: ${alturaApp}; background: ${GRAD_ARLEQUINA}; overflow: hidden; }
  ${inline ? '' : '.app { height: 100dvh; max-width: 560px; margin: 0 auto; }'}
  .view { height: 100%; display: flex; flex-direction: column; padding: 10px 12px 0; }
  .bar { display: flex; align-items: center; gap: 8px; height: 30px; flex: none; }
  .bar b { font-size: 14px; letter-spacing: .5px; }
  .ib { background: none; border: 0; color: #cdb6f0; padding: 6px; font-size: 18px; }
  .sb { display: flex; gap: 6px; margin: 6px 0; flex: none; }
  .sb input { flex: 1; min-width: 0; padding: 10px 12px; border-radius: 999px; border: 1px solid rgba(255,255,255,.2); background: rgba(0,0,0,.35); color: #fff; font-size: 14px; outline: none; }
  .go { width: 42px; border: 0; border-radius: 999px; background: linear-gradient(90deg, #7b2ff7, #c13cff); color: #fff; font-size: 16px; }
  .chips { display: flex; gap: 6px; overflow-x: auto; white-space: nowrap; padding: 2px 0 8px; flex: none; }
  .chip { flex: none; padding: 6px 12px; border: 0; border-radius: 999px; background: rgba(255,255,255,.1); color: #e0d3f7; font-size: 12px; }
  .status { font-size: 12px; color: #e0d3f7; padding: 4px 2px; }
  .dg { white-space: pre-wrap; font-size: 11px; color: #e0d3f7; padding: 6px 2px; word-break: break-all; }
  .retry { display: block; margin: 8px auto; padding: 10px 18px; border: 0; border-radius: 999px; background: #7b2ff7; color: #fff; font-size: 13px; }
  .list { flex: 1; overflow-y: auto; -webkit-overflow-scrolling: touch; overscroll-behavior: contain; }
  .row { display: flex; gap: 10px; align-items: center; padding: 7px 2px; border-top: 1px solid rgba(255,255,255,.08); }
  .row:active { background: rgba(193,60,255,.18); }
  .th { position: relative; width: 104px; height: 58px; flex: none; border-radius: 8px; overflow: hidden; background: #2a0f4a; }
  .th img { width: 100%; height: 100%; object-fit: cover; display: block; }
  .dur { position: absolute; right: 3px; bottom: 3px; background: rgba(0,0,0,.75); font-size: 10px; padding: 1px 4px; border-radius: 4px; }
  .tx { min-width: 0; flex: 1; }
  .tt { font-size: 13px; font-weight: bold; line-height: 1.25; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
  .ch { font-size: 11px; color: #b9a2e0; margin-top: 3px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .mini { flex: none; display: flex; align-items: center; gap: 10px; margin: 6px -12px 0; padding: 8px 12px; background: rgba(20,4,40,.92); border-top: 1px solid rgba(255,255,255,.12); }
  .mini img { width: 44px; height: 44px; border-radius: 8px; object-fit: cover; background: #2a0f4a; flex: none; }
  .mipp { background: none; border: 0; padding: 4px; }
  .pbody { flex: 1; display: flex; flex-direction: column; min-height: 0; padding-bottom: 8px; }
  .cov { height: 30vh; aspect-ratio: 1 / 1; object-fit: cover; border-radius: 12px; align-self: center; background: #2a0f4a; box-shadow: 0 10px 24px rgba(0,0,0,.5); }
  .pt { margin-top: 8px; font-size: 15px; font-weight: bold; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .pa { font-size: 12px; color: #b9a2e0; margin-top: 2px; }
  .seek { position: relative; height: 22px; margin-top: 6px; touch-action: none; cursor: pointer; }
  .track { position: absolute; left: 0; right: 0; top: 9px; height: 4px; border-radius: 2px; background: rgba(255,255,255,.3); }
  .fill { position: absolute; left: 0; top: 9px; height: 4px; border-radius: 2px; background: #fff; width: 0; }
  .knob { position: absolute; top: 4px; left: 0; width: 14px; height: 14px; border-radius: 50%; background: #fff; transform: translateX(-50%); }
  .times { display: flex; justify-content: space-between; font-size: 11px; color: #e0d3f7; }
  .ctrl { display: flex; align-items: center; justify-content: space-between; margin-top: 4px; }
  .ctrl .ib { color: #cdb6f0; }
  .play { width: 58px; height: 58px; border-radius: 50%; background: #fff; border: 0; display: flex; align-items: center; justify-content: center; padding: 0; }
  .ctrl2 { display: flex; gap: 8px; margin-top: 6px; }
  .chip2 { flex: 1; padding: 9px; border: 0; border-radius: 12px; background: rgba(255,255,255,.12); color: #fff; font-size: 12px; font-weight: bold; }
  .chip2.on { background: linear-gradient(90deg, #7b2ff7, #c13cff); }
  .chip2.dl { background: linear-gradient(90deg, #ff2d75, #c13cff); }
</style>
</head>
<body>
<div class="app">

  <div id="home" class="view">
    <div class="bar">
      <svg width="24" height="24" viewBox="0 0 30 30"><polygon points="15 1 29 15 15 29 1 15" fill="#b14cff"/><polygon points="12 9 12 21 21 15" fill="#ffffff"/></svg>
      <b>${esc(BOT_NAME)}</b>
    </div>
    <div class="sb"><input id="q" type="text" placeholder="Pesquisar no Arlequina Tube" autocomplete="off"><button id="go" class="go">🔎</button></div>
    <div class="chips" id="chips"></div>
    <div class="status" id="st"></div>
    <button id="retry" class="retry" style="display:none">Tentar de novo</button>
    <div class="dg" id="dg"></div>
    <div class="list" id="list"></div>
    <div class="mini" id="mini" style="display:none">
      <img id="mi-img" alt="">
      <div class="tx"><div class="tt" id="mi-t"></div></div>
      <button class="mipp" id="mi-pp"></button>
    </div>
  </div>

  <div id="pv" class="view" style="display:none">
    <div class="bar"><button class="ib" id="back">‹ Voltar</button></div>
    <div class="pbody">
      <img id="pv-img" class="cov" alt="">
      <div class="pt" id="pv-t"></div>
      <div class="pa" id="pv-a"></div>
      <div class="seek" id="seek"><div class="track"></div><div class="fill" id="fill"></div><div class="knob" id="knob"></div></div>
      <div class="times"><span id="cur">0:00</span><span id="tot">0:00</span></div>
      <div class="ctrl">
        <button class="ib" id="prev">⏮</button>
        <button class="ib" id="b10">${svgSkip(-1)}</button>
        <button class="play" id="pb"><span id="ic"></span></button>
        <button class="ib" id="f10">${svgSkip(1)}</button>
        <button class="ib" id="next">⏭</button>
      </div>
      <div class="ctrl2">
        <button class="chip2" id="rp">🔁 Repetir</button>
        <button class="chip2 dl" id="dl">⬇ Baixar MP3</button>
      </div>
      <div class="status" id="pst"></div>
    </div>
  </div>

</div>

<script>
(function () {
  var API = ${jsStr(base)};
  var K = ${jsStr(token)};
  var P = ${jsStr(prefixo)};
  var INICIAL = ${jsStr(consulta || APP_HOME)};
  var CHIPS = ['Funk', 'Sertanejo', 'Pop', 'Rap', 'Trap', 'Pagode', 'Forró', 'Eletrônica', 'Gospel', 'Rock'];
  var PLAY = ${jsStr(svgPlay('#1a0533'))};
  var PAUSE = ${jsStr(svgPause('#1a0533'))};
  var PLAYW = ${jsStr(svgPlay('#ffffff'))};
  var PAUSEW = ${jsStr(svgPause('#ffffff'))};

  var ITEMS = [], cur = -1, jobTok = 0, view = 'home';
  var E = { mode: '', ctx: null, buf: null, src: null, el: null, playing: false, offset: 0, startedAt: 0, loop: false };

  function $(id) { return document.getElementById(id); }
  function esc(s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }
  function fmt(s) { s = Math.max(0, Math.floor(s || 0)); var r = s % 60; return Math.floor(s / 60) + ':' + (r < 10 ? '0' : '') + r; }
  function api(path, extra) { return API + path + '?k=' + K + (extra || ''); }
  function msg(e) {
    var m = e && e.message ? String(e.message) : 'falha';
    if (/failed to fetch|networkerror|load failed|fetch/i.test(m)) return 'sem conexão com o servidor do bot (o WhatsApp pode ter bloqueado ou o túnel caiu)';
    return m;
  }
  function getJSON(url) { return fetch(url).then(function (r) { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); }); }
  function st(t) { $('st').textContent = t; }
  function pst(t) { $('pst').textContent = t; }

  // ---------- áudio ----------
  function ensureCtx() {
    if (!E.ctx) {
      var AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return null;
      try { E.ctx = new AC(); } catch (e) { return null; }
    }
    if (E.ctx.state === 'suspended' && E.ctx.resume) { try { E.ctx.resume(); } catch (e) {} }
    return E.ctx;
  }
  function decode(c, ab) {
    return new Promise(function (resolve, reject) {
      var done = false;
      function ok(b) { if (done) return; done = true; resolve(b); }
      function bad(e) { if (done) return; done = true; reject(e || new Error('falha ao decodificar')); }
      var p = c.decodeAudioData(ab, ok, bad);
      if (p && p.then) p.then(ok, bad);
    });
  }
  function dur() {
    if (E.mode === 'wa' && E.buf) return E.buf.duration;
    if (E.mode === 'el' && E.el && isFinite(E.el.duration) && E.el.duration > 0) return E.el.duration;
    var v = ITEMS[cur];
    return v ? v.seconds : 0;
  }
  function pos() {
    if (E.mode === 'wa') {
      if (!E.playing) return E.offset;
      var d = dur() || 1;
      var t = E.offset + (E.ctx.currentTime - E.startedAt);
      if (E.loop) t = t % d;
      return Math.min(t, d);
    }
    if (E.mode === 'el' && E.el) return E.el.currentTime;
    return 0;
  }
  function icons() {
    $('ic').innerHTML = E.playing ? PAUSE : PLAY;
    $('mi-pp').innerHTML = E.playing ? PAUSEW : PLAYW;
  }
  function tick() {
    if (cur < 0) return;
    var t = pos(), d = dur() || 1;
    var p = Math.min(100, Math.max(0, (t / d) * 100));
    $('fill').style.width = p + '%';
    $('knob').style.left = p + '%';
    $('cur').textContent = fmt(t);
    $('tot').textContent = fmt(dur());
  }
  function stopSrc() {
    if (E.src) {
      E.src.onended = null;
      try { E.src.stop(); } catch (e) {}
      try { E.src.disconnect(); } catch (e) {}
      E.src = null;
    }
  }
  function parar() {
    stopSrc();
    if (E.el) { try { E.el.pause(); } catch (e) {} E.el = null; }
    E.mode = ''; E.buf = null; E.playing = false; E.offset = 0;
    icons();
  }
  function startAt(t) {
    stopSrc();
    var s = E.ctx.createBufferSource();
    s.buffer = E.buf; s.loop = E.loop; s.connect(E.ctx.destination);
    s.onended = function () { if (E.src === s) { E.src = null; E.playing = false; E.offset = 0; icons(); fim(); } };
    E.src = s; E.offset = t; E.startedAt = E.ctx.currentTime;
    s.start(0, t);
    E.playing = true;
    icons();
  }
  function fim() { if (cur >= 0 && cur < ITEMS.length - 1) abrir(cur + 1); }
  function toggle() {
    if (cur < 0) return;
    if (E.playing) {
      if (E.mode === 'wa') { E.offset = pos(); stopSrc(); E.playing = false; }
      else if (E.el) { E.el.pause(); E.playing = false; }
      icons();
      return;
    }
    if (E.mode === 'wa' && E.buf) {
      ensureCtx();
      startAt(E.offset >= E.buf.duration - 0.1 ? 0 : E.offset);
    } else if (E.mode === 'el' && E.el) {
      var p = E.el.play();
      E.playing = true; icons();
      if (p && p.catch) p.catch(function () { E.playing = false; icons(); pst('Toque em ▶ para iniciar'); });
    }
  }
  function seekTo(t) {
    var d = dur();
    t = Math.max(0, t);
    if (d) t = Math.min(t, Math.max(0, d - 0.05));
    if (E.mode === 'wa' && E.buf) { if (E.playing) startAt(t); else E.offset = t; }
    else if (E.mode === 'el' && E.el) { E.el.currentTime = t; }
    tick();
  }

  // ---------- carregar a música ----------
  function usarElemento(url, tok, motivo) {
    try {
      var a = new Audio();
      a.preload = 'auto'; a.loop = E.loop;
      a.addEventListener('ended', function () { if (tok === jobTok && !E.loop) { E.playing = false; icons(); fim(); } });
      a.addEventListener('error', function () { if (tok === jobTok) pst('Não foi possível tocar o áudio. ' + (motivo ? msg(motivo) : '')); });
      a.src = url;
      E.mode = 'el'; E.el = a;
      var p = a.play();
      E.playing = true; icons();
      pst('Modo compatível');
      if (p && p.catch) p.catch(function () { E.playing = false; icons(); pst('Toque em ▶ para iniciar'); });
    } catch (e) { pst('Erro ao tocar: ' + msg(e)); }
  }
  function carregar(id, tok) {
    pst('Carregando áudio...');
    var url = api('/audio/' + id);
    var c = ensureCtx();
    if (!c) { usarElemento(url, tok, null); return; }
    fetch(url)
      .then(function (r) { if (!r.ok) throw new Error('HTTP ' + r.status); return r.arrayBuffer(); })
      .then(function (ab) { return decode(c, ab); })
      .then(function (buf) {
        if (tok !== jobTok) return;
        E.mode = 'wa'; E.buf = buf;
        pst('');
        ensureCtx();
        startAt(0);
      })
      .catch(function (e) { if (tok === jobTok) usarElemento(url, tok, e); });
  }
  function preparar(id, tok) {
    var tent = 0;
    function poll() {
      if (tok !== jobTok) return;
      getJSON(api('/prep/' + id)).then(function (r) {
        if (tok !== jobTok) return;
        if (r.status === 'ready') carregar(id, tok);
        else if (r.status === 'error') pst('Erro: ' + (r.erro || 'falha ao preparar o áudio'));
        else if (++tent > 120) pst('Demorou demais. Volte e tente de novo.');
        else setTimeout(poll, 1500);
      }).catch(function (e) { if (tok === jobTok) pst('Erro de conexão: ' + msg(e)); });
    }
    poll();
  }

  function showView(n) {
    view = n;
    $('home').style.display = n === 'home' ? 'flex' : 'none';
    $('pv').style.display = n === 'pv' ? 'flex' : 'none';
    $('mini').style.display = (cur >= 0 && n === 'home') ? 'flex' : 'none';
  }
  function abrir(i) {
    if (i < 0 || i >= ITEMS.length) return;
    ensureCtx();
    parar();
    cur = i;
    var v = ITEMS[i];
    $('pv-t').textContent = v.title;
    $('pv-a').textContent = v.author;
    $('pv-img').src = api('/thumb/' + v.id);
    $('mi-img').src = api('/thumb/' + v.id);
    $('mi-t').textContent = v.title;
    $('fill').style.width = '0%'; $('knob').style.left = '0%';
    $('cur').textContent = '0:00'; $('tot').textContent = fmt(v.seconds);
    pst('Preparando o áudio... pode levar até 1 minuto');
    showView('pv');
    preparar(v.id, ++jobTok);
  }

  // ---------- busca / lista ----------
  function render() {
    var h = '';
    for (var i = 0; i < ITEMS.length; i++) {
      var v = ITEMS[i];
      h += '<div class="row" data-i="' + i + '"><div class="th"><img loading="lazy" alt="" src="' + api('/thumb/' + v.id) + '">' +
        (v.seconds ? '<span class="dur">' + fmt(v.seconds) + '</span>' : '') + '</div><div class="tx"><div class="tt">' + esc(v.title) +
        '</div><div class="ch">' + esc(v.author) + '</div></div></div>';
    }
    $('list').innerHTML = h;
  }
  function buscar(q) {
    st('Buscando...');
    $('list').innerHTML = '';
    getJSON(api('/search', '&n=20&q=' + encodeURIComponent(q))).then(function (r) {
      ITEMS = r; cur = -1; parar(); render();
      $('retry').style.display = 'none'; $('dg').textContent = '';
      st(r.length ? '' : 'Nada encontrado.');
    }).catch(function (e) { st('Erro ao buscar: ' + msg(e)); });
  }
  function fazerBusca() {
    var v = ($('q').value || '').trim();
    if (v) buscar(v);
  }
  function diagnosticar(e) {
    var d = $('dg');
    d.textContent = 'Diagnóstico:\\n• endereço: ' + API + '\\n• erro: ' + (e && e.message ? e.message : e);
    function add(t) { d.textContent += '\\n' + t; }
    try {
      fetch(api('/ping'), { mode: 'no-cors' })
        .then(function () { add('• servidor do bot: ALCANÇÁVEL (o problema é a resposta/CORS)'); })
        .catch(function (x) { add('• servidor do bot: NÃO alcançável (' + (x && x.message ? x.message : x) + ')'); });
    } catch (x) { add('• teste do servidor falhou: ' + x.message); }
    try {
      fetch('https://api.github.com/zen')
        .then(function () { add('• internet do card (api.github.com): OK'); })
        .catch(function () { add('• internet do card (api.github.com): BLOQUEADA'); });
    } catch (x) {}
  }
  function iniciar() {
    $('retry').style.display = 'none';
    $('dg').textContent = '';
    st('Conectando ao servidor...');
    getJSON(api('/ping')).then(function () { buscar(INICIAL); })
      .catch(function (e) { st('❌ ' + msg(e)); $('retry').style.display = 'block'; diagnosticar(e); });
  }

  // ---------- eventos ----------
  var chipsHtml = '';
  for (var c = 0; c < CHIPS.length; c++) chipsHtml += '<button class="chip" data-c="' + esc(CHIPS[c]) + '">' + esc(CHIPS[c]) + '</button>';
  $('chips').innerHTML = chipsHtml;
  $('chips').addEventListener('click', function (e) {
    var b = e.target && e.target.closest ? e.target.closest('.chip') : null;
    if (!b) return;
    var nome = b.getAttribute('data-c');
    $('q').value = nome;
    buscar(nome + ' músicas mais tocadas');
  });
  $('list').addEventListener('click', function (e) {
    var r = e.target && e.target.closest ? e.target.closest('.row') : null;
    if (r) abrir(Number(r.getAttribute('data-i')));
  });
  $('go').addEventListener('click', fazerBusca);
  $('q').addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.keyCode === 13) fazerBusca(); });
  $('retry').addEventListener('click', iniciar);
  $('back').addEventListener('click', function () { showView('home'); });
  $('mini').addEventListener('click', function (e) {
    if (e.target && e.target.closest && e.target.closest('#mi-pp')) { toggle(); return; }
    showView('pv');
  });
  $('pb').addEventListener('click', toggle);
  $('b10').addEventListener('click', function () { seekTo(pos() - 10); });
  $('f10').addEventListener('click', function () { seekTo(pos() + 10); });
  $('prev').addEventListener('click', function () { abrir(cur - 1); });
  $('next').addEventListener('click', function () { abrir(cur + 1); });
  $('rp').addEventListener('click', function () {
    E.loop = !E.loop;
    if (E.src) E.src.loop = E.loop;
    if (E.el) E.el.loop = E.loop;
    $('rp').className = 'chip2' + (E.loop ? ' on' : '');
  });
  $('dl').addEventListener('click', function () {
    var v = ITEMS[cur];
    if (!v) return;
    var cmd = P + 'tube baixar ' + v.id;
    try { if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(cmd); } catch (e) {}
    var w = null;
    try { w = window.open(api('/dl/' + v.id), '_blank'); } catch (e) {}
    pst(w ? 'Abrindo o download no navegador... (se não abrir, cole no chat: ' + cmd + ')' : 'Comando copiado! Cole no chat para o bot mandar o MP3: ' + cmd);
  });

  var drag = false;
  function seekEvent(e) {
    var r = $('seek').getBoundingClientRect();
    var p = Math.min(1, Math.max(0, (e.clientX - r.left) / r.width));
    seekTo(p * dur());
  }
  $('seek').addEventListener('pointerdown', function (e) {
    drag = true;
    if ($('seek').setPointerCapture) { try { $('seek').setPointerCapture(e.pointerId); } catch (x) {} }
    seekEvent(e);
  });
  $('seek').addEventListener('pointermove', function (e) { if (drag) seekEvent(e); });
  $('seek').addEventListener('pointerup', function () { drag = false; });
  $('seek').addEventListener('pointercancel', function () { drag = false; });

  setInterval(tick, 300);
  icons();
  iniciar();
})();
</script>
</body>
</html>`
}

// ---------- plugin ----------
// ============================================================
//  CONVERSA: toques em botões/listas e respostas de texto
//  (assim tudo acontece dentro de UM comando: !tube)
// ============================================================
const ID_PREFIXO = 'arltube|'
const OUVINTE = G.ouvinte

// id que vai dentro do botão. Com o ouvinte ativo, o toque é tratado aqui mesmo;
// sem ele, o botão manda um comando normal para o bot processar.
function idBtn(p, acao, arg = '') {
  if (OUVINTE.ativo) return `${ID_PREFIXO}${acao}${arg ? '|' + arg : ''}`
  switch (acao) {
    case 'menu':
    case 'play':
    case 'mp3':
    case 'baixar':
    case 'video':
      return `${p}tube ${acao} ${arg}`
    case 'cat':
      return `${p}tube ${arg} mais tocadas`
    default:
      return `${p}tube`
  }
}

const linhasDeLista = (items, p) =>
  items.map((v, k) => ({
    header: '',
    title: `${k + 1}. ${v.title}`.slice(0, 50),
    description: `${v.author}${v.seconds ? ' • ' + fmtTime(v.seconds) : ''}`.slice(0, 70),
    id: idBtn(p, 'menu', v.id),
  }))

function idParaTexto(id) {
  const partes = id.split('|')
  const acao = partes[1]
  const arg = partes.slice(2).join('|')
  switch (acao) {
    case 'buscar': return '__buscar'
    case 'alta': return '__alta'
    case 'cats': return '__cats'
    case 'cat': return `${arg} mais tocadas`
    case 'inicio': return ''
    case 'menu':
    case 'play':
    case 'mp3':
    case 'baixar':
    case 'video':
      return `${acao} ${arg}`
    default:
      return null
  }
}

function desembrulhar(message) {
  let msg = message
  for (let k = 0; k < 4 && msg; k++) {
    const dentro =
      (msg.ephemeralMessage && msg.ephemeralMessage.message) ||
      (msg.viewOnceMessage && msg.viewOnceMessage.message) ||
      (msg.viewOnceMessageV2 && msg.viewOnceMessageV2.message) ||
      (msg.documentWithCaptionMessage && msg.documentWithCaptionMessage.message)
    if (!dentro) break
    msg = dentro
  }
  return msg
}

function idDoToque(msg) {
  try {
    const nf = msg.interactiveResponseMessage && msg.interactiveResponseMessage.nativeFlowResponseMessage
    if (nf && nf.paramsJson) {
      const j = JSON.parse(nf.paramsJson)
      if (j && j.id) return String(j.id)
    }
  } catch {}
  return (
    (msg.listResponseMessage && msg.listResponseMessage.singleSelectReply && msg.listResponseMessage.singleSelectReply.selectedRowId) ||
    (msg.buttonsResponseMessage && msg.buttonsResponseMessage.selectedButtonId) ||
    (msg.templateButtonReplyMessage && msg.templateButtonReplyMessage.selectedId) ||
    ''
  )
}

const chaveDe = (m) => `${m.key.remoteJid}|${m.key.fromMe ? 'eu' : m.key.participant || m.key.remoteJid}`

async function tratarMensagem(columbina, m) {
  if (!m || !m.message || !m.key) return
  const jid = m.key.remoteJid
  if (!jid || jid === 'status@broadcast') return

  const idMsg = m.key.id
  if (idMsg) {
    if (OUVINTE.vistos.has(idMsg)) return
    OUVINTE.vistos.add(idMsg)
    if (OUVINTE.vistos.size > 1000) OUVINTE.vistos.delete(OUVINTE.vistos.values().next().value)
  }

  const msg = desembrulhar(m.message)
  const agora = Date.now()

  const executar = (texto) =>
    module.exports.execute({
      columbina,
      from: jid,
      text: texto,
      prefix: PREFIXO,
      reagir: (e) => columbina.sendMessage(jid, { react: { text: e, key: m.key } }),
      reply: (t) => columbina.sendMessage(jid, { text: t }),
    })

  // toque em botão ou item de lista do Arlequina Tube
  const toque = idDoToque(msg)
  if (toque && toque.startsWith(ID_PREFIXO)) {
    const texto = idParaTexto(toque)
    if (texto === null) return
    if (texto === '__buscar' && !m.key.fromMe) OUVINTE.esperando.set(chaveDe(m), { exp: agora + 3 * 60 * 1000 })
    await executar(texto)
    return
  }

  // resposta à pergunta "o que você quer ouvir?"
  const texto = String(msg.conversation || (msg.extendedTextMessage && msg.extendedTextMessage.text) || '').trim()
  if (!texto) return
  const citado = msg.extendedTextMessage && msg.extendedTextMessage.contextInfo && msg.extendedTextMessage.contextInfo.stanzaId
  const pend = citado ? OUVINTE.pendentes.get(citado) : null
  if (pend && pend.exp > agora) {
    OUVINTE.pendentes.delete(citado)
    await executar(texto)
    return
  }
  if (!m.key.fromMe && !/^[!\/.#]/.test(texto)) {
    const k = chaveDe(m)
    const w = OUVINTE.esperando.get(k)
    if (w && w.exp > agora) {
      OUVINTE.esperando.delete(k)
      await executar(texto)
    }
  }
}

function instalarOuvinte(columbina) {
  if (!columbina) return
  OUVINTE.sock = columbina // sempre usa a conexão mais recente para responder
  const ev = columbina.ev
  if (OUVINTE.ev && OUVINTE.ev === ev) return // já está ouvindo esta conexão

  try {
    // conexão nova: tira o ouvinte antigo para não responder em dobro
    if (OUVINTE.ev && OUVINTE.handler && typeof OUVINTE.ev.off === 'function') {
      try { OUVINTE.ev.off('messages.upsert', OUVINTE.handler) } catch {}
    }
    if (ev && typeof ev.on === 'function') {
      const handler = (u) => {
        for (const m of (u && u.messages) || []) {
          tratarMensagem(OUVINTE.sock, m).catch((e) => console.error('[tube] erro ao tratar mensagem:', e && e.message))
        }
      }
      ev.on('messages.upsert', handler)
      OUVINTE.ev = ev
      OUVINTE.handler = handler
      OUVINTE.ativo = true
      console.log('[tube] ouvinte de botões e respostas ativo')
    } else {
      OUVINTE.ev = null
      OUVINTE.handler = null
      OUVINTE.ativo = false
      console.log('[tube] sem columbina.ev: os botões vão mandar comandos normais')
    }
  } catch (e) {
    console.error('[tube] não consegui instalar o ouvinte:', e && e.message)
  }
}

const CATEGORIAS = [
  ['🔥', 'Funk'], ['🤠', 'Sertanejo'], ['🎤', 'Pop'], ['🎧', 'Rap'], ['💎', 'Trap'],
  ['🥁', 'Pagode'], ['🪗', 'Forró'], ['🎛️', 'Eletrônica'], ['🙏', 'Gospel'], ['🎸', 'Rock'],
]

const ROTULOS = {
  play: 'o player interativo',
  mp3: 'o áudio',
  baixar: 'o arquivo MP3',
  video: 'o vídeo',
}

const midia = (file) => (fs.statSync(file).size > 20 * 1024 * 1024 ? { url: file } : fs.readFileSync(file))

const limparNome = (s) => String(s || 'musica').replace(/[\\/:*?"<>|]/g, '').trim().slice(0, 80) || 'musica'

module.exports = {
  name: 'tube',
  description: 'Arlequina Tube: busca, toca, baixa música e manda vídeo',
  category: 'download',
  aliases: ['tube', 'tuber', 'arlequinatube', 'arlequinayoutube', 'arlequinayt', 'atube'],

  async execute(ctx) {
    const { columbina, from, reagir, reply } = ctx
    const react = async (e) => {
      try {
        if (reagir) await reagir(e)
      } catch {}
    }
    const p = ctx.prefix || ctx.prefixo || PREFIXO
    const inline = EXIBICAO === 'inline'
    const ytmusic = ctx.estilo === 'ytmusic' // vem do atalho !play2 (card vermelho estilo YT Music)
    const marca = ytmusic ? PLAY2_NOME : BOT_NAME
    instalarOuvinte(columbina)

    // sobe o servidor/túnel do app em segundo plano e manda o link assim que estiver pronto
    let appPronto = null
    let erroApp = ''
    let linkEnviado = false
    const mandarLinkApp = async (consulta) => {
      if (!APP_WEB || linkEnviado) return
      linkEnviado = true
      const app = await appPronto
      if (!app || !app.url) {
        await reply(
          `⚠️ Não consegui abrir o app completo agora${erroApp ? ': ' + erroApp.slice(0, 140) : ''}.\n` +
            `Confira se o *cloudflared* (ou o *openssh*) está instalado no Termux.`
        )
        return
      }
      const link = `${app.url}/app?k=${app.token}` + (consulta ? `&q=${encodeURIComponent(consulta)}` : '')
      await reply(
        `🌐 *${BOT_NAME} — app completo*\n\n` +
          `Aqui você pesquisa qualquer coisa, toca, pausa e baixa. Toque no link:\n${link}`
      )
    }
    const prepararApp = (consulta = '') => {
      if (!APP_WEB || appPronto) return
      if (!APP.url) Promise.resolve(reply('🌐 Preparando o app completo... pode levar até 1 minuto.')).catch(() => {})
      appPronto = iniciarApp().catch((e) => {
        erroApp = errCurto(e)
        console.error('[tube] app web indisponível:', erroApp)
        return null
      })
      appPronto.then(() => mandarLinkApp(consulta)).catch((e) => console.error('[tube] falha ao mandar o link:', e && e.message))
    }

    // abre o app (o "YouTube" dentro do card)
    const abrirApp = async (consulta) => {
      await reply(`🎬 *${BOT_NAME}*\nAbrindo o app...`)
      const app = await iniciarApp()
      const html = buildAppHtml({ base: app.url, token: app.token, consulta, prefixo: p, inline })
      await enviarPlayer(columbina, from, html, [...TRUSTED, new URL(app.url).hostname, 'api.github.com'])
      if (APP_LINK_DEBUG) {
        await reply(
          `🔗 Teste do servidor (toque no link, deve aparecer {"ok":true}):\n${app.url}/ping?k=${app.token}` +
            (app.noAr ? '' : '\n\n⚠️ O próprio bot não conseguiu falar com esse endereço ainda.')
        )
      }
    }

    // depois de uma ação, oferece as outras por botão
    const proximos = async (video, feito) => {
      if (!BOTOES_APOS_ACAO) return
      try {
        await enviarBotoes(columbina, from, {
          texto: 'Mais opções para esta música:',
          botoes: botoesDoVideo(video, p, [feito]),
        })
      } catch (e) {
        console.error('[tube] botões pós-ação falharam:', e.message)
      }
    }

    const ajuda =
      `🎬 *${BOT_NAME}*\n\n` +
      `Use só *${p}tube* (ou *${p}arlequinatube*):\n\n` +
      `1️⃣ Toque em *🔎 Pesquisar* e responda com o nome da música\n` +
      `2️⃣ Escolha na lista\n` +
      `3️⃣ Toque em ▶ Tocar, 🎵 Áudio, ⬇ Baixar MP3 ou 🎬 Vídeo\n\n` +
      `Também dá para pesquisar direto: *${p}tube nome da música*\n` +
      `Vídeos: *${p}tubevd nome* ou *${p}p2vd nome*`

    const rawIn = pickQuery(ctx)
    const home = !rawIn
    if (home && APP_ATIVO) {
      try {
        await abrirApp('')
        return
      } catch (e) {
        console.error('[tube] app indisponível:', e)
        await reply('⚠️ Não consegui abrir o app agora: ' + errCurto(e).slice(0, 160))
      }
    }
    const raw = rawIn || APP_HOME
    if (raw.trim().toLowerCase() === 'ajuda') return reply(ajuda)
    if (raw.trim().toLowerCase() === 'app') {
      return reply(`O app no navegador foi desativado. Use o card e os botões do *${p}tube*.`)
    }
    if (raw.trim().toLowerCase() === 'atualizar') {
      if (Date.now() - ATUALIZADO_EM < 5 * 60 * 1000) return reply('⏳ O yt-dlp já foi atualizado há pouco. Tente de novo em alguns minutos.')
      ATUALIZADO_EM = Date.now()
      await reply('🔄 Atualizando o yt-dlp... pode levar um minutinho.')
      try {
        let ok = false
        for (const pip of ['pip', 'pip3']) {
          try {
            await execFileP(pip, ['install', '-U', 'yt-dlp[default]', '--break-system-packages'], { timeout: 600000, maxBuffer: 20 * 1024 * 1024 })
            ok = true
            break
          } catch {}
        }
        const { stdout } = await execFileP('yt-dlp', ['--version'])
        return reply(ok ? `✅ yt-dlp atualizado: *${stdout.trim()}*` : `⚠️ Não consegui atualizar sozinho. Versão atual: *${stdout.trim()}*\nNo Termux, rode: pip install -U "yt-dlp[default]"`)
      } catch (e) {
        return reply('❌ Não consegui atualizar: ' + errCurto(e).slice(0, 140))
      }
    }
    if (raw.trim().toLowerCase() === 'versao' || raw.trim().toLowerCase() === 'versão') {
      return reply(`🎬 *${BOT_NAME}* ${VERSAO}\nApp web: ${APP_WEB ? 'ligado' : 'desligado'}\nBotões/respostas: ${OUVINTE.ativo ? 'ativos' : 'desativados'}`)
    }
    if (raw.trim().toLowerCase() === 'teste3') {
      try {
        await reply(`🔧 *${BOT_NAME}*\nPreparando o diagnóstico 3 (folha que sobe, 2 cards). Depois de chegar, toque em cada um para abrir e espere uns 8 segundos.`)
        const app = await iniciarApp()
        const host = new URL(app.url).hostname
        const extras = ['api.github.com', 'cdnjs.cloudflare.com']
        const variantes = [
          { titulo: 'Diagnóstico C (folha, domínio puro)', trusted: [...TRUSTED, host, ...extras] },
          { titulo: 'Diagnóstico D (folha, https://)', trusted: [...TRUSTED, host, ...extras].map((d) => 'https://' + d) },
        ]
        for (const v of variantes) {
          await enviarPlayer(columbina, from, buildDiag2Html({ base: app.url, token: app.token, titulo: v.titulo, inline: false }), v.trusted, 'sheet')
        }
      } catch (e) {
        console.error('[tube] diagnóstico 3 falhou:', e)
        await reply('❌ Não consegui montar o diagnóstico 3: ' + errCurto(e).slice(0, 160))
      }
      return
    }
    if (raw.trim().toLowerCase() === 'teste2') {
      try {
        await reply(`🔧 *${BOT_NAME}*\nPreparando o diagnóstico 2 (2 cards)...`)
        const app = await iniciarApp()
        const host = new URL(app.url).hostname
        const extras = ['api.github.com', 'cdnjs.cloudflare.com']
        const variantes = [
          { titulo: 'Diagnóstico A (domínio puro)', trusted: [...TRUSTED, host, ...extras] },
          { titulo: 'Diagnóstico B (https://)', trusted: [...TRUSTED, host, ...extras].map((d) => 'https://' + d) },
        ]
        for (const v of variantes) {
          await enviarPlayer(columbina, from, buildDiag2Html({ base: app.url, token: app.token, titulo: v.titulo, inline }), v.trusted)
        }
      } catch (e) {
        console.error('[tube] diagnóstico 2 falhou:', e)
        await reply('❌ Não consegui montar o diagnóstico 2: ' + errCurto(e).slice(0, 160))
      }
      return
    }
    if (raw.trim().toLowerCase() === 'link') {
      if (!APP.url) return reply(`O app ainda não foi iniciado. Mande *${p}arlequinatube* primeiro.`)
      return reply(`🔗 Teste do servidor (deve aparecer {"ok":true}):\n${APP.url}/ping?k=${APP.token}`)
    }

    // ----- toques internos (botões do Arlequina Tube) -----
    const especial = raw.trim()
    if (especial === '__buscar') {
      if (!OUVINTE.ativo) return reply(`🔎 Para pesquisar, envie: *${p}tube nome da música*`)
      try {
        const r = await columbina.sendMessage(from, {
          text:
            `🔎 *${BOT_NAME}*\n\nO que você quer ouvir?\n\n` +
            `👉 *Responda esta mensagem* (deslize para o lado) com o nome da música ou artista.\n` +
            `Ex.: _MC Menor RF_`,
        })
        const idPrompt = r && r.key && r.key.id
        if (idPrompt) {
          OUVINTE.pendentes.set(idPrompt, { exp: Date.now() + 10 * 60 * 1000 })
          if (OUVINTE.pendentes.size > 200) OUVINTE.pendentes.delete(OUVINTE.pendentes.keys().next().value)
        }
      } catch (e) {
        await reply('❌ Não consegui abrir a pesquisa: ' + (e && e.message))
      }
      return
    }
    if (especial === '__cats') {
      try {
        await enviarLista(columbina, from, {
          texto: '📂 Escolha uma categoria 👇',
          botao: '📂 Categorias',
          secao: 'Categorias',
          linhas: CATEGORIAS.map(([emoji, nome]) => ({
            header: '',
            title: `${emoji} ${nome}`,
            description: 'Mais tocadas',
            id: idBtn(p, 'cat', nome),
          })),
        })
      } catch (e) {
        await reply('❌ Não consegui abrir as categorias: ' + (e && e.message))
      }
      return
    }
    if (especial === '__alta') {
      let d
      try {
        await react('⏳')
        d = fs.mkdtempSync(path.join(os.tmpdir(), 'tube_'))
        const dados = await carregarHome(d)
        const itemsAlta = dados.secoes[0].items
        ultimas.set(from, { items: itemsAlta, ts: Date.now() })
        await enviarLista(columbina, from, {
          texto: '🔥 *Em alta agora*\nToque em *Escolher música* 👇',
          botao: '🎵 Escolher música',
          secao: 'Em alta',
          linhas: linhasDeLista(itemsAlta, p),
        })
        await react('✅')
      } catch (e) {
        console.error('[tube] em alta falhou:', e)
        await react('❌')
        await reply('⚠️ Não foi possível carregar o Em alta agora. Tente novamente.')
      } finally {
        if (d) fs.rm(d, { recursive: true, force: true }, () => {})
      }
      return
    }

    // separa a ação do resto: "play 2", "mp3 nome da música"...
    const mAcao = raw.match(/^(play|mp3|baixar|video|vídeo|menu)\s+(.+)$/i)
    let acao = mAcao ? mAcao[1].toLowerCase().replace('í', 'i') : 'lista'
    const arg = mAcao ? mAcao[2].trim() : raw

    // ping: usado pelo botão de teste
    if (raw.trim().toLowerCase() === 'ping') {
      return reply('🏓 pong! O botão funcionou e o bot recebeu o comando.')
    }

    // teste: descobre o que o card e os botões conseguem fazer
    if (raw.trim().toLowerCase() === 'teste') {
      try {
        await reply(`🔧 *${BOT_NAME}*\nEnviando o diagnóstico (card + botão)...`)
        const trustedTeste = [...TRUSTED, 'api.github.com', 'httpbin.org', 'www.soundhelix.com']
        await enviarPlayer(columbina, from, buildDiagHtml({ inline, prefixo: p }), trustedTeste)
        try {
          await enviarBotoes(columbina, from, {
            texto: `Teste 2: toque no botão abaixo.\nSe o bot responder *pong*, os botões do WhatsApp funcionam com o seu bot.`,
            botoes: [{ texto: '🏓 Testar botão', id: `${p}tube ping` }],
          })
        } catch (e) {
          await reply('⚠️ Não consegui enviar o botão nativo: ' + (e && e.message))
        }
      } catch (e) {
        console.error('[tube] diagnóstico falhou:', e)
        await reply('❌ Não consegui enviar o diagnóstico: ' + (e && e.message))
      }
      return
    }

    let dir
    let etapa = 'início'
    const t0 = Date.now()
    const log = (m) => console.log(`[tube] ${((Date.now() - t0) / 1000).toFixed(1)}s - ${m}`)

    try {
      await react('⏳')

      // ===== lista de resultados =====
      if (acao === 'lista') {
        prepararApp(home ? '' : arg)
        if (APP_ATIVO) {
          try {
            await abrirApp(arg)
            await react('✅')
            return
          } catch (e) {
            console.error('[tube] app indisponível:', e)
            await reply('⚠️ Não consegui abrir o app (' + errCurto(e).slice(0, 120) + '). Usando o modo lista.')
          }
        }
        await reply(home ? `🎬 *${BOT_NAME}*\nAbrindo a home (em alta agora)... _(${VERSAO})_` : `🎧 *${BOT_NAME}*\nBuscando *${arg}*...`)
        dir = fs.mkdtempSync(path.join(os.tmpdir(), 'tube_'))
        let items
        let html
        if (home) {
          etapa = 'montagem da home'
          const dados = await carregarHome(dir)
          items = dados.secoes[0].items
          log(`home ok: ${dados.secoes.length} seções`)
          html = buildYouTubeHtml({ secoes: dados.secoes, thumbs: dados.thumbs, inline, prefixo: p, titulo: 'Em alta agora' })
        } else {
          etapa = 'busca'
          items = filtrarMusicas(await searchVideos(arg, RESULTADOS + 6)).slice(0, RESULTADOS)
          log(`busca ok: ${items.length} resultados`)
          if (!items.length) {
            await react('❌')
            return reply('❌ Não encontrei nada com esse nome.')
          }
          etapa = 'miniaturas'
          const th = {}
          await mapLimit(items, 6, async (v) => {
            th[v.id] = await makeThumb(v.id, dir, 288, 162, 8)
          })
          html = buildYouTubeHtml({
            secoes: [{ nome: 'Resultados', items }],
            thumbs: th,
            inline,
            prefixo: p,
            titulo: `Resultados para “${arg}”`,
            busca: true,
            consulta: arg,
          })
        }
        ultimas.set(from, { items, ts: Date.now() })

        etapa = 'envio do card'
        log(`card: ${Math.round(Buffer.byteLength(html) / 1024)} KB`)
        await enviarPlayer(columbina, from, html)
        await react('✅')

        // home: botões do app (pesquisar / em alta / categorias)
        if (home && OUVINTE.ativo) {
          try {
            await enviarBotoes(columbina, from, {
              texto: 'O que você quer fazer? 👇',
              botoes: [
                { texto: '🔎 Pesquisar', id: idBtn(p, 'buscar') },
                { texto: '🔥 Em alta', id: idBtn(p, 'alta') },
                { texto: '📂 Categorias', id: idBtn(p, 'cats') },
              ],
            })
          } catch (e) {
            console.error('[tube] botões da home falharam:', e.message)
          }
          await mandarLinkApp('')
          return
        }

        try {
          await enviarLista(columbina, from, {
            texto: 'Toque em *Escolher música* para abrir uma delas 👇',
            botao: '🎵 Escolher música',
            secao: 'Resultados',
            linhas: linhasDeLista(items, p),
          })
        } catch (e) {
          console.error('[tube] lista nativa falhou:', e.message)
          return reply(
            `👆 Escolha pelo número:\n` +
              `• *${p}tube play 1* — player\n` +
              `• *${p}tube mp3 1* — áudio\n` +
              `• *${p}tube baixar 1* — arquivo MP3\n` +
              `• *${p}tube video 1* — vídeo`
          )
        }
        if (OUVINTE.ativo) {
          try {
            await enviarBotoes(columbina, from, {
              texto: 'Não achou? 👇',
              botoes: [
                { texto: '🔎 Nova pesquisa', id: idBtn(p, 'buscar') },
                { texto: '🏠 Início', id: idBtn(p, 'inicio') },
              ],
            })
          } catch {}
          await mandarLinkApp(home ? '' : arg)
        } else if (home) {
          try {
            await enviarLista(columbina, from, {
              texto: 'Ou explore por categoria 👇\n\nPara pesquisar qualquer música: *' + p + 'tube nome da música*',
              botao: '📂 Categorias',
              secao: 'Categorias',
              linhas: CATEGORIAS.map(([emoji, nome]) => ({
                header: '',
                title: `${emoji} ${nome}`,
                description: 'Mais tocadas',
                id: idBtn(p, 'cat', nome),
              })),
            })
          } catch (e) {
            console.error('[tube] categorias falharam:', e.message)
          }
        }
        if (!OUVINTE.ativo) await mandarLinkApp(home ? '' : arg)
        return
      }

      // ===== ações: menu / play / mp3 / baixar / video =====
      let video
      etapa = 'busca'
      const avisar = (texto) => (acao === 'menu' ? null : reply(texto))
      const porId = /^[A-Za-z0-9_-]{11}$/.test(arg) ? pegarVideo(arg) : null
      if (porId) {
        video = porId
        await avisar(`🎧 *${marca}*\nPreparando ${ROTULOS[acao]} de *${video.title}*...`)
      } else if (/^\d{1,2}$/.test(arg)) {
        const salvo = ultimas.get(from)
        const item = salvo && Date.now() - salvo.ts < VALIDADE_MS ? salvo.items[Number(arg) - 1] : null
        if (!item) {
          await react('❌')
          return reply(`❌ Não achei o resultado ${arg}. Faça uma busca primeiro: *${p}tube <nome>*`)
        }
        video = item
        await avisar(`🎧 *${marca}*\nPreparando ${ROTULOS[acao]} de *${video.title}*...`)
      } else {
        await avisar(`🎧 *${marca}*\nPreparando ${ROTULOS[acao]} para *${arg}*...`)
        const achados = await searchVideos(arg, acao === 'video' ? 6 : 1)
        video = acao === 'video' ? achados.find((v) => !v.seconds || v.seconds <= VIDEO_BUSCA_MAX_SECONDS) || achados[0] : achados[0]
        if (!video) {
          await react('❌')
          return reply('❌ Não encontrei nada com esse nome.')
        }
      }
      log('alvo: ' + video.title)

      // ----- menu da música: capa + botões (como abrir um vídeo no YouTube) -----
      if (acao === 'menu') {
        etapa = 'menu da música'
        const legenda = `🎬 *${video.title}*\n👤 ${video.author}` + (video.seconds ? `\n⏱️ ${fmtTime(video.seconds)}` : '')
        let enviouCapa = false
        for (const nome of ['maxresdefault', 'mqdefault']) {
          try {
            await columbina.sendMessage(from, { image: { url: `https://i.ytimg.com/vi/${video.id}/${nome}.jpg` }, caption: legenda })
            enviouCapa = true
            break
          } catch {}
        }
        if (!enviouCapa) await reply(legenda)
        await enviarBotoes(columbina, from, {
          texto: 'O que você quer fazer?',
          botoes: botoesDoVideo(video, p),
        })
        if (OUVINTE.ativo) {
          try {
            await enviarBotoes(columbina, from, {
              texto: 'Mais:',
              botoes: [
                { texto: '🎬 Vídeo', id: idBtn(p, 'video', video.id) },
                { texto: '🔎 Pesquisar', id: idBtn(p, 'buscar') },
                { texto: '🏠 Início', id: idBtn(p, 'inicio') },
              ],
            })
          } catch {}
        }
        await react('✅')
        return
      }

      // faixa longa demais para o card: manda o áudio no chat em vez de recusar
      if (acao === 'play' && excede(video.seconds, MAX_SECONDS)) {
        acao = 'mp3'
        await reply(`ℹ️ Essa faixa tem ${fmtTime(video.seconds)}: o card só aguenta músicas de até ${fmtTime(MAX_SECONDS)}. Vou mandar o áudio no chat.`)
      }
      const limite = acao === 'video' ? MAX_VIDEO_SECONDS : MAX_MP3_SECONDS
      if (excede(video.seconds, limite)) {
        await react('❌')
        return reply(`❌ Muito longo (${fmtTime(video.seconds)}). Limite para isso: ${fmtTime(limite)}.`)
      }

      dir = fs.mkdtempSync(path.join(os.tmpdir(), 'tube_'))

      // ----- vídeo -----
      if (acao === 'video') {
        etapa = 'download do vídeo'
        const file = await baixarVideo(video.url, dir)
        const mb = fs.statSync(file).size / 1024 / 1024
        log(`vídeo ok: ${mb.toFixed(1)}MB`)
        if (excede(mb, MAX_VIDEO_MB)) {
          await react('❌')
          return reply(`❌ Vídeo ficou com ${mb.toFixed(1)}MB (limite ${MAX_VIDEO_MB}MB).`)
        }
        etapa = 'envio do vídeo'
        const duracao = video.seconds ? `\n⏱️ ${fmtTime(video.seconds)}` : ''
        const legenda = ytmusic
          ? `🎧 *${PLAY2_NOME}*\n🎵 *${video.title}*\n👤 ${video.author}${duracao}`
          : `🎬 *${BOT_NAME}*\n*${video.title}*\n👤 ${video.author}${duracao}`
        if (mb <= VIDEO_INLINE_MB) {
          await columbina.sendMessage(from, { video: midia(file), mimetype: 'video/mp4', caption: legenda })
        } else {
          await columbina.sendMessage(from, {
            document: midia(file),
            mimetype: 'video/mp4',
            fileName: limparNome(video.title) + '.mp4',
            caption: legenda + '\n\n(enviado como arquivo por ser grande)',
          })
        }
        await react('✅')
        if (!ytmusic) await proximos(video, 'video')
        return
      }

      // ----- áudio (play / mp3 / baixar) -----
      etapa = 'download do áudio'
      const bruto = await baixarAudioBruto(video.url, dir)
      log('áudio bruto ok')

      etapa = 'capa'
      const cover = await makeCover(video.id, dir)
      if (!video.seconds) video.seconds = await probeSeconds(bruto)

      // manda o áudio no chat (mp3) ou como arquivo (baixar); nunca recusa por tamanho
      const enviarAudio = async (tipo) => {
        etapa = 'conversão para mp3'
        const file = await mp3Completo(bruto, dir, video, path.join(dir, 'cover.jpg'))
        const mb = fs.statSync(file).size / 1024 / 1024
        log(`mp3 ok: ${mb.toFixed(1)}MB`)
        etapa = 'envio do áudio'
        const nome = limparNome(video.title) + '.mp3'
        if (tipo === 'mp3' && mb <= AUDIO_INLINE_MB) {
          await columbina.sendMessage(from, { audio: midia(file), mimetype: 'audio/mpeg', fileName: nome })
        } else {
          await columbina.sendMessage(from, {
            document: midia(file),
            mimetype: 'audio/mpeg',
            fileName: nome,
            caption: `🎵 *${video.title}*\n${video.author}\n\nSalve o arquivo e toque no seu player favorito, inclusive em segundo plano.`,
          })
        }
        await react('✅')
        await proximos(video, tipo)
      }

      if (acao === 'mp3' || acao === 'baixar') {
        await enviarAudio(acao)
        return
      }

      // ----- play (card interativo) -----
      etapa = 'conversão para o card'
      const pequeno = await audioParaCard(bruto, dir, video.seconds)
      const sizeMB = fs.statSync(pequeno).size / 1024 / 1024
      if (sizeMB > TARGET_MB * 2) {
        await reply(`ℹ️ Essa faixa é pesada para o card (${sizeMB.toFixed(1)}MB). Vou mandar o áudio no chat.`)
        await enviarAudio('mp3')
        return
      }

      etapa = 'montagem do card'
      let html
      if (ytmusic) {
        html = buildPlay2Html({
          title: video.title,
          author: video.author,
          seconds: video.seconds,
          cover,
          audioB64: fs.readFileSync(pequeno).toString('base64'),
          inline,
        })
      } else {
        const salvo = ultimas.get(from)
        const rel = ((salvo && salvo.items) || []).filter((v) => v.id !== video.id).slice(0, 4)
        const relThumbs = {}
        await mapLimit(rel, 4, async (v) => {
          relThumbs[v.id] = await makeThumb(v.id, dir, 200, 113, 9)
        })
        html = buildWatchHtml({
          title: video.title,
          author: video.author,
          seconds: video.seconds,
          cover,
          audioB64: fs.readFileSync(pequeno).toString('base64'),
          inline,
          prefixo: p,
          videoId: video.id,
          rel,
          relThumbs,
        })
      }
      const kb = Math.round(Buffer.byteLength(html) / 1024)
      log(`card montado: ${kb} KB`)

      // card pesado demais: o WhatsApp descarta sem avisar. Manda o áudio no chat em vez de perder a música.
      if (kb > CARD_MAX_KB) {
        await reply(`ℹ️ Essa faixa deixaria o card com ${kb} KB (o WhatsApp aguenta até uns ${CARD_MAX_KB} KB). Vou mandar o áudio no chat.`)
        await enviarAudio('mp3')
        return
      }

      etapa = 'envio do card'
      await enviarPlayer(columbina, from, html)
      await react('✅')
      if (DEBUG) await reply(`✅ Card enviado (${kb} KB).`)
      if (!ytmusic) await proximos(video, 'play')
    } catch (err) {
      console.error('[tube] erro na etapa "' + etapa + '":', err)
      await react('❌')
      const detalhe = String((err && err.stderr) || (err && err.message) || err)
        .split('\n')
        .filter((l) => /error/i.test(l))
        .pop()
      if (ehBloqueio(err)) {
        await reply(
          `😈 *${BOT_NAME}*\n\nO YouTube pediu verificação e não liberou essa faixa agora.\n` +
            `Tente outra música ou tente de novo em alguns instantes.\n\n` +
            `_Dica: mande *${p}tube atualizar* para atualizar o yt-dlp._`
        )
      } else {
        await reply(
          `❌ Não foi possível concluir agora.\nEtapa: *${etapa}*` + (detalhe ? `\n${detalhe.slice(0, 200)}` : '')
        )
      }
    } finally {
      if (dir) fs.rm(dir, { recursive: true, force: true }, () => {})
    }
  },
}
