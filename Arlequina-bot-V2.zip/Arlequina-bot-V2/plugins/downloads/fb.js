/*
 Convertido automaticamente do connect.js (bot antigo monolitico) para
 o sistema de plugins da Arlequina Bot. Comando original: facebook, fb
*/
const { carregarUsuarios, salvarUsuarios, getUsuario } = require('../../arquivos/js/rpgDB.js')
const adminState = require('../../arquivos/js/adminState.js')
const donoState = require('../../arquivos/js/donoState.js')
const { imagemDaBrincadeira, buscarImagemAleatoria } = require('../../arquivos/js/brincadeirasHelpers.js')
const fs = require('fs')
const axios = require('axios')
const { exec } = require('child_process')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'fb',
description: "Baixa vídeo do Facebook",
category: 'downloads',
aliases: ["facebook"],
async execute({ arlequina, from, info, args, q, reply, reagir, prefix, sender, pushname, isGroup, donoJid, commandManager, config, getFileBuffer, sleep, fetchJson }) {

const sock = arlequina
const msg = info
const jid = sender
const jidReal = sender
const numeroReal = String(sender || '').split('@')[0]
const isGrupo = isGroup
const nome = pushname
const texto = q || args.join(' ')
const baixarMidia = (mediaMsg, tipo) => getFileBuffer(mediaMsg, tipo)

const ehDono = (jidAlvo, numeroAlvo) => {
const donoNum = String(donoJid || '').replace(/[^0-9]/g, '')
const num = String(numeroAlvo || '').replace(/[^0-9]/g, '')
return (donoNum && num === donoNum) || jidAlvo === donoJid
}

const usuarios = carregarUsuarios()
getUsuario(usuarios, sender)

const enviar = async (conteudo, _opcoes) => {
if (typeof conteudo === 'string') return reply(conteudo)
try {
return await sock.sendMessage(from, conteudo, { quoted: info })
} catch (e) {
const fallback = conteudo?.caption || conteudo?.text || '✅'
return reply(fallback)
}
}

try {
  const link = args[0]
  
  if (!link || (!link.includes('facebook.com') && !link.includes('fb.watch')))
  return reply(caixaArlequina("fb", `❌ Envie um link válido do Facebook.\n\n(Busca por nome não é suportada para Facebook, só link.)\n\nEx: !facebook https://www.facebook.com/watch/?v=xxxxx`))
  
  await reply('⏳ Baixando do Facebook...')
  
  const file = `./tmp_fb_${Date.now()}.mp4`
  
  try {
  
  const cmd = `python3 -m yt_dlp -o "${file}" "${link}"`
  
  await new Promise((resolve, reject) => {
  exec(cmd, { maxBuffer: 1024 * 1024 * 100 }, (err, stdout, stderr) => {
  if (err) {
  console.log(stderr || err)
  return reject(err)
  }
  resolve()
  })
  })
  
  if (!fs.existsSync(file))
  return reply('❌ Não consegui baixar esse vídeo. Verifique se o link é público.')
  
  const buffer = fs.readFileSync(file)
  
  await enviar({
  video: buffer,
  caption: caixaArlequina('fb', '📘 Facebook\n\n✅ Baixado com sucesso!')
  }, { quoted: msg })
  
  fs.unlinkSync(file)
  
  } catch (e) {
  console.log(e)
  if (fs.existsSync(file)) fs.unlinkSync(file)
  await reply('❌ Erro ao baixar do Facebook.\n\nVerifique se o yt-dlp está instalado (pip install yt-dlp).')
  }
} catch (e) {
console.log('❌ ERRO (fb):', e?.message)
await reply('❌ Não consegui executar esse comando agora.')
} finally {
salvarUsuarios(usuarios)
}

}
}
