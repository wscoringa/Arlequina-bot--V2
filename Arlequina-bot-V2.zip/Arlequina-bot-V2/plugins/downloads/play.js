const fs = require('fs')
const axios = require('axios')
const { exec, execFile } = require('child_process')
const { prepareWAMessageMedia, generateWAMessageFromContent, generateMessageIDV2, isJidGroup } = require('@whiskeysockets/baileys')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Mesmo node extra usado no !menu — avisa o WhatsApp que a mensagem tem
// um native_flow de verdade, senão ele só mostra o texto e ignora o botão.
function nodeDoBotao(jid) {
  const node = {
    tag: 'biz',
    attrs: {},
    content: [{
      tag: 'interactive',
      attrs: { type: 'native_flow', v: '1' },
      content: [{ tag: 'native_flow', attrs: { v: '9', name: 'mixed' } }]
    }]
  }
  const nodes = [node]
  if (!isJidGroup(jid)) nodes.push({ tag: 'bot', attrs: { biz_bot: '1' } })
  return nodes
}

function fmtDur(s) {
  const seg = parseInt(s) || 0
  return `${Math.floor(seg/60)}:${String(seg%60).padStart(2,'0')}`
}

function shell(cmd, ms = 20000) {
  return new Promise((res, rej) => {
    const c = exec(cmd, { timeout: ms, killSignal: 'SIGKILL' }, (err, out, errStr) => {
      clearTimeout(k)
      if (err) return rej(new Error(errStr?.split('\n')[0] || err.message))
      res((out || '').trim())
    })
    const k = setTimeout(() => { try { c.kill('SIGKILL') } catch(_) {} }, ms + 2000)
  })
}

function ytOk() {
  return new Promise(r => execFile('yt-dlp', ['--version'], { timeout: 5000 }, e => r(!e)))
}

function ytRun(args, ms = 25000) {
  return new Promise((resolve, reject) => {
    execFile('yt-dlp', args, { timeout: ms, maxBuffer: 10 * 1024 * 1024 }, (err, stdout, stderr) => {
      if (err) {
        const detalhe = (stderr || stdout || err.message || '').trim()
        reject(new Error(detalhe.split('\n').filter(Boolean).slice(0, 3).join('\n') || err.message))
        return
      }
      resolve((stdout || '').trim())
    })
  })
}

// yt-dlp funciona corretamente sem forçar player_client.
const YT_ARGS = ``

async function getThumb(url) {
  try {
    const r = await axios.get(url, { responseType: 'arraybuffer', timeout: 10000 })
    return Buffer.from(r.data)
  } catch { return null }
}

async function baixarEnviarPlay(arlequina, from, info, reply, reagir, dados, tipo) {
  if (!fs.existsSync('./temp')) fs.mkdirSync('./temp', { recursive: true })
  const tmp = `./temp/play_${Date.now()}`
  const label = tipo === 'audio' ? '🎧 Áudio MP3' : tipo === 'video' ? '🎬 Vídeo MP4' : '📁 Documento MP3'
  await reagir('⬇️')
  await reply(`╭─━━─🃏💜「 🃏💜 *PLAY* 💜🃏 」💜🃏─━━─╮\n┃ ⬇️ *${dados.titulo}*\n┃ 📦 ${label}\n┃ ⏳ Baixando...\n╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯`)
  try {
    const yt = `https://youtube.com/watch?v=${dados.id}`
    if (tipo === 'audio' || tipo === 'documento') {
      await shell(`yt-dlp --no-warnings ${YT_ARGS} -x --audio-format mp3 --audio-quality 128K -o "${tmp}.%(ext)s" "${yt}"`, 20 * 60 * 1000)
      const mp3 = `${tmp}.mp3`
      if (!fs.existsSync(mp3)) throw new Error('MP3 não gerado')
      const buf = fs.readFileSync(mp3); fs.unlinkSync(mp3)
      if (tipo === 'audio') {
        await arlequina.sendMessage(from, { audio: buf, mimetype: 'audio/mpeg', ptt: false, fileName: `${dados.titulo}.mp3` }, { quoted: info })
      } else {
        await arlequina.sendMessage(from, { document: buf, mimetype: 'audio/mpeg', fileName: `${dados.titulo}.mp3` }, { quoted: info })
      }
    } else {
      await shell(`yt-dlp --no-warnings ${YT_ARGS} -f "bestvideo[height<=480][vcodec^=avc]+bestaudio[acodec^=mp4a]/bestvideo[height<=480]+bestaudio/best[height<=480]" --merge-output-format mp4 --recode-video mp4 -o "${tmp}.%(ext)s" "${yt}"`, 25 * 60 * 1000)
      const mp4 = `${tmp}.mp4`
      if (!fs.existsSync(mp4)) throw new Error('MP4 não gerado')
      if (fs.statSync(mp4).size > 64 * 1024 * 1024) { fs.unlinkSync(mp4); return reply('❌ Vídeo muito grande! Tente como 🎧 Áudio.') }
      const buf = fs.readFileSync(mp4); fs.unlinkSync(mp4)
      await arlequina.sendMessage(from, { video: buf, caption: `${caixaArlequina("play", `🃏💜 *ARLEQUINA PLAY*\n\n🎵 *${dados.titulo}*\n👑 ${dados.canal}\n⏱️ ${fmtDur(dados.duracao)}`)}`, mimetype: 'video/mp4' }, { quoted: info })
    }
    await reagir('✅')
  } catch(e) {
    if (/sign in to confirm|not a bot/i.test(e?.message || '')) {
      await reply(`❌ O YouTube bloqueou o download (verificação anti-bot).\n\n💡 Se isso continuar sempre, rode no servidor: *pip install -U yt-dlp*`)
    } else {
      await reply(`❌ Erro ao baixar: ${e?.message}`)
    }
  } finally {
    for (const ext of ['mp3', 'mp4', 'webm', 'm4a', 'opus', 'mkv']) {
      const f = `${tmp}.${ext}`; if (fs.existsSync(f)) try { fs.unlinkSync(f) } catch(_) {}
    }
  }
}

module.exports = {
  name: 'play',
  description: '🎵 Busca música no YouTube',
  category: 'downloads',
  aliases: ['p', 'musica', 'yt', 'youtube', 'ytmusic', 'youtubemusic', 'ytaudio1', 'ytvideo1', 'ytaudio2', 'ytvideo2', 'ytdl_audio2', 'ytdl_video2', 'playvideo', 'playvid'],
  baixarEnviarPlay,

  async execute({ arlequina, columbina, from, info, q, args, reply, reagir, sender, prefix }) {
    const pesquisa = (q || args.join(' ')).trim()
    if (!pesquisa) return reply(caixaArlequina("play", `❌ Digite o nome da música.\n💡 Ex: *${prefix}play* MC Gabzin`))

    await reagir('🎵')

    try {
      if (!await ytOk()) return reply('❌ yt-dlp não instalado! Rode: pip install -U yt-dlp')

      await reply(caixaArlequina("play", `🔍 Procurando: *${pesquisa}*\n⏳ Aguarde um instante...\n\n💜🃏 _Deixa que eu acho pra você... 😈_`))

      const termoBusca = `ytsearch1:${pesquisa.replace(/["\\]/g, '')}`
      const id = await ytRun(['--no-warnings', '--print', 'id', termoBusca], 30000)
      if (!id) return reply(caixaArlequina("play", `❌ Nenhum resultado encontrado.\n💡 Tenta escrever o nome de outro jeito.`))

      // Pega metadados em JSON para montar um card mais completo sem
      // depender de separadores que podem aparecer no título da música.
      const metaRaw = await ytRun([
        '--no-warnings',
        '--dump-single-json',
        '--skip-download',
        `https://youtube.com/watch?v=${id}`
      ], 30000)

      let meta = {}
      try {
        meta = JSON.parse(metaRaw)
      } catch {
        // Fallback caso uma versão do yt-dlp imprima alguma linha extra.
        const inicio = metaRaw.indexOf('{')
        const fim = metaRaw.lastIndexOf('}')
        if (inicio >= 0 && fim > inicio) meta = JSON.parse(metaRaw.slice(inicio, fim + 1))
      }

      const titulo = String(meta.title || pesquisa).trim()
      const duracao = Number(meta.duration || 0)
      const canal = String(meta.uploader || meta.channel || 'YouTube').trim()
      const thumb = String(meta.thumbnail || '').trim()
      const visualizacoes = Number(meta.view_count || 0)
      const dataUpload = String(meta.upload_date || '').trim()
      const descricao = String(meta.description || '').trim()

      if (duracao > 10800) return reply(caixaArlequina("play", `❌ Muito longo! Máximo 3 horas.`))

      const dataBonita = /^\d{8}$/.test(dataUpload)
        ? `${dataUpload.slice(6, 8)}/${dataUpload.slice(4, 6)}/${dataUpload.slice(0, 4)}`
        : 'Não informado'

      const viewsBonitas = visualizacoes > 0
        ? visualizacoes.toLocaleString('pt-BR')
        : 'Não informado'

      // Tenta descobrir gênero/álbum apenas quando o próprio yt-dlp fornece.
      const genero = String(meta.genre || meta.categories?.[0] || 'Não informado').trim()
      const album = String(meta.album || 'Não informado').trim()

      if (!global.sessoesPlay) global.sessoesPlay = {}
      // Sessão do CHAT inteiro → qualquer pessoa do grupo pode baixar
      global.sessoesPlay[from] = {
        id,
        titulo,
        duracao,
        canal,
        thumb,
        genero,
        album,
        dataUpload,
        visualizacoes,
        por: sender
      }
      setTimeout(() => { if (global.sessoesPlay) delete global.sessoesPlay[from] }, 300000)

      const linha = '━━━━━━━━━━━━━━━━━━━━━━━━━━━━'
      const tituloExibicao = titulo.length > 70 ? `${titulo.slice(0, 67)}...` : titulo

      const menuTxt =
        `╭━━━ 🃏💜「 *ARLEQUINA PLAY* 」💜🃏 ━━━╮\n` +
        `┃\n` +
        `┃ 🎵 *${tituloExibicao}*\n` +
        `┃\n` +
        `┃ 👑 *ARTISTA/CANAL:* ${canal}\n` +
        `┃ ⏱️ *DURAÇÃO:* ${fmtDur(duracao)}\n` +
        `┃ 💿 *ÁLBUM:* ${album}\n` +
        `┃ 🎼 *GÊNERO:* ${genero}\n` +
        `┃ 📅 *LANÇAMENTO:* ${dataBonita}\n` +
        `┃ 👁️ *VISUALIZAÇÕES:* ${viewsBonitas}\n` +
        `┃\n` +
        `┃ ${linha}\n` +
        `┃\n` +
        `╰━━━ 🃏💜 *ARLEQUINA BOT* 💜🃏 ━━━╯`

      const conn = columbina || arlequina
      const thumbBuf = await getThumb(thumb?.trim())

      // Só o menu com BOTÃO (sem o card de texto de cima)
      try {
        const mediaCard = thumbBuf ? await prepareWAMessageMedia(
          { image: thumbBuf },
          { upload: conn.waUploadToServer }
        ) : null

        const conteudoMensagem = {
          interactiveMessage: {
            contextInfo: {
              stanzaId: info.key.id,
              participant: info.key.participant || info.key.remoteJid,
              quotedMessage: info.message
            },
            header: { hasMediaAttachment: !!mediaCard, imageMessage: mediaCard ? mediaCard.imageMessage : undefined },
            body: { text: menuTxt },
            footer: { text: '🃏💜 Arlequina Bot • Música do seu jeito' },
            nativeFlowMessage: {
              buttons: [{
                name: 'single_select',
                buttonParamsJson: JSON.stringify({
                  title: '🎵 ESCOLHER FORMATO',
                  sections: [{
                    title: 'Escolha um formato',
                    rows: [
                      { header: '', title: '🎧 Áudio (mp3)', description: 'Baixar somente o áudio da música', id: 'audio' },
                      { header: '', title: '🎬 Vídeo (mp4)', description: 'Baixar a música em vídeo', id: 'video' },
                      { header: '', title: '📁 Documento', description: 'Enviar o MP3 como arquivo', id: 'documento' }
                    ]
                  }]
                })
              }]
            }
          }
        }

        const msgGerada = generateWAMessageFromContent(from, conteudoMensagem, {
          userJid: conn.user.id,
          messageId: generateMessageIDV2(conn.user.id)
        })

        await conn.relayMessage(from, msgGerada.message, {
          messageId: msgGerada.key.id,
          additionalNodes: nodeDoBotao(from)
        })
      } catch (eBotao) {
        console.log('[play] botão falhou, fallback texto:', eBotao?.message)
        const menuTxtFallback = caixaArlequina("play", `${menuTxt}

╭━━━〔 🃏💜 FORMATO 〕━━━╮
┃ 1️⃣ 🎧 Áudio MP3
┃ 2️⃣ 🎬 Vídeo MP4
┃ 3️⃣ 📁 Documento MP3
╰━━━━━━━━━━━━━━━━━━━━━━╯

💡 Digite *1*, *2* ou *3*`)
        if (thumbBuf) {
          await conn.sendMessage(from, { image: thumbBuf, caption: menuTxtFallback }, { quoted: info })
        } else {
          await conn.sendMessage(from, { text: menuTxtFallback }, { quoted: info })
        }
      }

    } catch(e) {
      console.log('[play] ERRO:', e?.message)
      if (/sign in to confirm|not a bot/i.test(e?.message || '')) {
        await reply(`❌ O YouTube bloqueou essa tentativa (verificação anti-bot).\n\n💡 Se isso continuar acontecendo sempre, rode no servidor: *pip install -U yt-dlp*`)
      } else {
        await reply(`❌ Erro: ${e?.message}`)
      }
    }
  }
}

