// ============================================================
//  plugins/download/tubevideo.js  (ATALHO)
//  tubevideo / tubevd <qualquer coisa>  =  pesquisa e manda o VÍDEO no chat
//  (estilo Arlequina Tube)
//
//  Coloque na MESMA pasta do tube.js.
// ============================================================
const tube = require('./tube.js')

function pegarTexto(ctx) {
  const cands = [ctx.text, ctx.q, ctx.query, ctx.texto, Array.isArray(ctx.args) ? ctx.args.join(' ') : ctx.args]
  const achou = cands.find((v) => typeof v === 'string' && v.trim())
  if (achou) return achou.trim()
  if (typeof ctx.body === 'string' && ctx.body.trim()) return ctx.body.trim().split(/\s+/).slice(1).join(' ').trim()
  return ''
}

module.exports = {
  name: 'tubevideo',
  description: 'Pesquisa qualquer coisa e manda o vídeo (estilo Arlequina Tube)',
  category: 'download',
  aliases: ['tubevideo', 'tubevd'],

  async execute(ctx) {
    const nome = pegarTexto(ctx)
    if (!nome) return ctx.reply('🎬 Diga o que você quer assistir.\nExemplo: *.tubevd MC Menor RF clipe*')
    return tube.execute({ ...ctx, text: 'video ' + nome })
  },
}
