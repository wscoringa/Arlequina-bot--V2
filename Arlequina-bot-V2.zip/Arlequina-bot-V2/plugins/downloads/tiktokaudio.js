/*
 Convertido automaticamente do connect.js (bot antigo monolitico) para
 o sistema de plugins da Arlequina Bot. Comando original: tiktokaudio, ttmp3

 Atualizado pra usar o helper arquivos/js/tiktokDownload.js (mesma
 lógica de retry/VexAPI do !tt).
*/
const { carregarUsuarios, salvarUsuarios, getUsuario } = require('../../arquivos/js/rpgDB.js')
const { baixarPorLink, buscarPorNome, ehErroCloudflare } = require('../../arquivos/js/tiktokDownload.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'tiktokaudio',
description: "Baixa o áudio de um vídeo do TikTok",
category: 'downloads',
aliases: ["ttmp3"],
async execute({ arlequina, from, info, args, q, reply, reagir, prefix, sender, pushname, isGroup, donoJid, commandManager, config, getFileBuffer, sleep, fetchJson }) {

const sock = arlequina
const usuarios = carregarUsuarios()
getUsuario(usuarios, sender)

const enviar = async (conteudo) => {
if (typeof conteudo === 'string') return reply(conteudo)
try {
  return await sock.sendMessage(from, conteudo, { quoted: info })
} catch (e) {
  const fallback = conteudo?.caption || conteudo?.text || '✅'
  return reply(fallback)
}
}

try {
  const entrada = q

  if (!entrada)
    return reply(caixaArlequina("tiktokaudio", `❌ Envie um link ou o nome do vídeo.\n\nEx: !ttmp3 https://vm.tiktok.com/xxxxx\nEx: !ttmp3 edit coringa`))

  const ehLink = entrada.includes('tiktok.com')

  await reply(ehLink ? '⏳ Baixando áudio do TikTok...' : `🔍 Procurando no TikTok:\n${entrada}`)

  try {
    let video = null

    if (ehLink) {
      video = await baixarPorLink(entrada, config?.VexApiKey)
      if (!video?.music)
        return reply('❌ Não consegui baixar o áudio desse vídeo.')
    } else {
      const resultado = await buscarPorNome(entrada)
      if (!resultado?.music)
        return reply('❌ Nenhum áudio encontrado com esse nome.')
      video = resultado
    }

    await enviar({
      audio: { url: video.music },
      mimetype: 'audio/mpeg'
    })

  } catch (e) {
    const foiCloudflare = ehErroCloudflare(e)
    console.log('❌ ERRO tiktokaudio:', foiCloudflare ? 'Cloudflare bloqueou a requisição (403)' : (e?.message || e))
    await reply(foiCloudflare
      ? `❌ O TikWM tá bloqueando por Cloudflare mesmo depois do retry. Tenta de novo em alguns minutos${config?.VexApiKey ? '' : `, ou configure uma "VexApiKey" em database/config.json`}.`
      : '❌ Erro ao baixar o áudio do TikTok.')
  }
} catch (e) {
  console.log('❌ ERRO (tiktokaudio):', e?.message)
  await reply('❌ Não consegui executar esse comando agora.')
} finally {
  salvarUsuarios(usuarios)
}

}
}
