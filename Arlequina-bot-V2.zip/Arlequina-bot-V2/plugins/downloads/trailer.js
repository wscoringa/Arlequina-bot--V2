/*
 !trailer <nome do filme/série>
 Busca o trailer oficial no YouTube e manda a capa + o link direto pra
 assistir (não baixa o vídeo — só entrega o link, é mais rápido e leve).
*/
const { exec, execFile } = require('child_process')
const axios = require('axios')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

function shell(cmd, ms = 20000) {
  return new Promise((res, rej) => {
    const c = exec(cmd, { timeout: ms, killSignal: 'SIGKILL' }, (err, out, errStr) => {
      clearTimeout(k)
      if (err) return rej(new Error(errStr?.split('\n')[0] || err.message))
      res((out || '').trim())
    })
    const k = setTimeout(() => { try { c.kill('SIGKILL') } catch(_) {} }, ms + 2000)
  })
}

function ytOk() {
  return new Promise(r => execFile('yt-dlp', ['--version'], { timeout: 5000 }, e => r(!e)))
}

const YT_ARGS = `--extractor-args "youtube:player_client=android,tv,ios,web"`

function fmtDur(s) {
  const seg = parseInt(s) || 0
  const h = Math.floor(seg / 3600)
  const m = Math.floor((seg % 3600) / 60)
  const sAtual = seg % 60
  return h > 0 ? `${h}:${String(m).padStart(2,'0')}:${String(sAtual).padStart(2,'0')}` : `${m}:${String(sAtual).padStart(2,'0')}`
}

async function getThumb(url) {
  try {
    const r = await axios.get(url, { responseType: 'arraybuffer', timeout: 10000 })
    return Buffer.from(r.data)
  } catch { return null }
}

module.exports = {
  name: 'trailer',
  description: '🎬 Busca o trailer oficial de um filme/série no YouTube e manda o link',
  category: 'downloads',
  aliases: ['trailerfilme', 'trailermovie'],
  async execute({ arlequina, from, info, q, args, reply, reagir, sender, prefix }) {
    const pesquisa = (q || args.join(' ')).trim()
    if (!pesquisa) return reply(caixaArlequina("trailer", `❌ Digite o nome do filme/série.\n💡 Ex: *${prefix}trailer* Duna Parte 2`))

    await reagir('🎬')

    try {
      if (!await ytOk()) return reply('❌ yt-dlp não instalado! Rode: pip install -U yt-dlp')

      await reply(caixaArlequina("trailer", `🔍 Procurando trailer de: *${pesquisa}*\n⏳ Aguarde um instante...`))

      const buscaTexto = `${pesquisa} trailer oficial legendado`
      const id = await shell(`yt-dlp --no-warnings ${YT_ARGS} --print id "ytsearch1:${buscaTexto.replace(/"/g, '')}"`, 25000)
      if (!id) return reply(caixaArlequina("trailer", `❌ Não encontrei nenhum trailer pra isso.\n💡 Tenta escrever o nome de outro jeito.`))

      const meta = await shell(`yt-dlp --no-warnings ${YT_ARGS} --print "%(title)s|||%(duration)s|||%(uploader)s|||%(thumbnail)s" "https://youtube.com/watch?v=${id}"`, 20000)
      const [titulo, duracao, canal, thumb] = meta.split('|||')
      const link = `https://youtube.com/watch?v=${id}`

      const texto = caixaArlequina("trailer", `🎬 *${titulo?.trim() || pesquisa}*\n👤 Canal: ${canal?.trim() || 'YouTube'}\n⏱️ Duração: ${fmtDur(duracao)}\n\n▶️ *Assistir:*\n${link}`)

      const thumbBuf = await getThumb(thumb?.trim())
      if (thumbBuf) {
        await arlequina.sendMessage(from, { image: thumbBuf, caption: texto }, { quoted: info })
      } else {
        await arlequina.sendMessage(from, { text: texto }, { quoted: info })
      }
      await reagir('✅')
    } catch (e) {
      console.log('[trailer] ERRO:', e?.message)
      if (/sign in to confirm|not a bot/i.test(e?.message || '')) {
        await reply(`❌ O YouTube bloqueou essa tentativa (verificação anti-bot).\n\n💡 Se isso continuar sempre, rode no servidor: *pip install -U yt-dlp*`)
      } else {
        await reply(`❌ Erro: ${e?.message}`)
      }
    }
  }
}
