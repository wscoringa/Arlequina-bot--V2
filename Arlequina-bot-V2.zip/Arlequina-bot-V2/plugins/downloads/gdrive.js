const { ytOk, baixarComYtDlp } = require('../../arquivos/js/ytdlpHelper.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
  name: 'gdrive',
  description: '📁 Baixa vídeo público do Google Drive',
  category: 'downloads',
  aliases: ['googledrive', 'drivedl'],
  async execute({ arlequina, from, info, q, args, reply, reagir, prefix }) {
    const link = (q || args.join(' ')).trim()
    if (!link || !link.includes('drive.google.com')) return reply(caixaArlequina('gdrive', `❌ Envie um link válido do Google Drive.\n⚠️ O arquivo precisa estar com acesso público ("qualquer pessoa com o link").\n💡 Ex: *${prefix}gdrive* https://drive.google.com/file/d/xxxxx/view`))
    if (!await ytOk()) return reply('❌ yt-dlp não instalado! Rode: pip install -U yt-dlp')

    try {
      await reagir('📁')
      await reply(caixaArlequina('gdrive', '⏳ Baixando do Google Drive...'))
      const buffer = await baixarComYtDlp(link, 'tmp_gdrive', 120000)
      if (!buffer) return reply(caixaArlequina('gdrive', '❌ Não consegui baixar esse arquivo (verifique se ele é público).'))
      await arlequina.sendMessage(from, { video: buffer, caption: caixaArlequina('gdrive', '📁 Google Drive\n\n✅ Baixado com sucesso!') }, { quoted: info })
    } catch (e) {
      console.log('❌ ERRO gdrive:', e?.message)
      await reply('❌ Não consegui baixar esse arquivo do Drive. Verifique se ele é público e se é um vídeo.')
    }
  }
}
