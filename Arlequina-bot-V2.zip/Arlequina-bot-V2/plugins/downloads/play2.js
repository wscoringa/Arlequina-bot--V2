// ============================================================
//  plugins/download/play2.js  (ATALHO)
//  !play2 <música>  =  !tube play <música>, com o card vermelho estilo YT Music
//
//  Este arquivo só repassa para o tube.js, que já cuida do peso do card,
//  do áudio e dos erros. Coloque na MESMA pasta do tube.js.
// ============================================================
const tube = require('./tube.js')

function pegarTexto(ctx) {
  const cands = [ctx.text, ctx.q, ctx.query, ctx.texto, Array.isArray(ctx.args) ? ctx.args.join(' ') : ctx.args]
  const achou = cands.find((v) => typeof v === 'string' && v.trim())
  if (achou) return achou.trim()
  if (typeof ctx.body === 'string' && ctx.body.trim()) return ctx.body.trim().split(/\s+/).slice(1).join(' ').trim()
  return ''
}

module.exports = {
  name: 'play2',
  description: 'Atalho: toca a música no player (igual ao !tube play)',
  category: 'download',
  aliases: ['play2'],

  async execute(ctx) {
    const nome = pegarTexto(ctx)
    if (!nome) return ctx.reply('🎧 Diga o nome da música.\nExemplo: *.play2 MC Menor RF*')
    return tube.execute({ ...ctx, text: 'play ' + nome, estilo: 'ytmusic' })
  },
}
