/*
 Convertido automaticamente do connect.js (bot antigo monolitico) para
 o sistema de plugins da Arlequina Bot. Comando original: tiktok, tt

 Igual ao tt.js — os dois são aliases um do outro, então usam o mesmo
 helper arquivos/js/tiktokDownload.js (VexAPI + TikWM com retry).
*/
const { carregarUsuarios, salvarUsuarios, getUsuario } = require('../../arquivos/js/rpgDB.js')
const { baixarPorLink, buscarPorNome, ehErroCloudflare } = require('../../arquivos/js/tiktokDownload.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'tiktok',
description: "Baixa vídeo do TikTok",
category: 'downloads',
aliases: ["tt"],
async execute({ arlequina, from, info, args, q, reply, reagir, prefix, sender, pushname, isGroup, donoJid, commandManager, config, getFileBuffer, sleep, fetchJson }) {

const sock = arlequina
const usuarios = carregarUsuarios()
getUsuario(usuarios, sender)

const enviar = async (conteudo) => {
if (typeof conteudo === 'string') return reply(conteudo)
try {
  return await sock.sendMessage(from, conteudo, { quoted: info })
} catch (e) {
  const fallback = conteudo?.caption || conteudo?.text || '✅'
  return reply(fallback)
}
}

try {
  const entrada = q

  if (!entrada)
    return reply('❌ Envie um link ou o nome do vídeo.\n\nEx: !tt https://vm.tiktok.com/xxxxx\nEx: !tt edit coringa')

  const ehLink = entrada.includes('tiktok.com')

  await reply(ehLink ? '⏳ Baixando vídeo do TikTok...' : `🔍 Procurando no TikTok:\n${entrada}`)

  try {
    let video = null

    if (ehLink) {
      video = await baixarPorLink(entrada, config?.VexApiKey)
      if (!video?.play)
        return reply('❌ Não consegui baixar esse vídeo. Verifique o link.')
    } else {
      const resultado = await buscarPorNome(entrada)
      if (!resultado)
        return reply('❌ Nenhum vídeo encontrado com esse nome.')
      video = resultado
    }

    await enviar({
      video: { url: video.play },
      caption: `${caixaArlequina("tiktok", `🎵 TikTok\n\n📝 ${video.title || 'Sem título'}\n👤 @${video.author?.unique_id || '?'}`)}`
    })

  } catch (e) {
    const foiCloudflare = ehErroCloudflare(e)
    console.log('❌ ERRO tiktok:', foiCloudflare ? 'Cloudflare bloqueou a requisição (403)' : (e?.message || e))
    await reply(foiCloudflare
      ? `❌ O TikWM (serviço que baixa o vídeo) tá bloqueando por Cloudflare mesmo depois de tentar 2 domínios com retry. Tenta de novo em alguns minutos${config?.VexApiKey ? '' : `, ou configure uma "VexApiKey" em database/config.json pra usar uma API paga sem esse bloqueio`}.`
      : '❌ Erro ao baixar o vídeo do TikTok. Tente novamente em alguns minutos.')
  }
} catch (e) {
  console.log('❌ ERRO (tiktok):', e?.message)
  await reply('❌ Não consegui executar esse comando agora.')
} finally {
  salvarUsuarios(usuarios)
}

}
}
