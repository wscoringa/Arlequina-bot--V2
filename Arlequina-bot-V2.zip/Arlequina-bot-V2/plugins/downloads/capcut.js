const { ytOk, baixarComYtDlp } = require('../../arquivos/js/ytdlpHelper.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
  name: 'capcut',
  description: '🎬 Baixa vídeo/template do CapCut',
  category: 'downloads',
  aliases: ['capcutdl'],
  async execute({ arlequina, from, info, q, args, reply, reagir, prefix }) {
    const link = (q || args.join(' ')).trim()
    if (!link || !link.includes('capcut')) return reply(caixaArlequina('capcut', `❌ Envie um link válido do CapCut.\n💡 Ex: *${prefix}capcut* https://www.capcut.com/t/xxxxx`))
    if (!await ytOk()) return reply('❌ yt-dlp não instalado! Rode: pip install -U yt-dlp')

    try {
      await reagir('🎬')
      const buffer = await baixarComYtDlp(link, 'tmp_capcut')
      if (!buffer) return reply(caixaArlequina('capcut', '❌ Não consegui baixar esse vídeo do CapCut.'))
      await arlequina.sendMessage(from, { video: buffer, caption: caixaArlequina('capcut', '🎬 CapCut\n\n✅ Baixado com sucesso!') }, { quoted: info })
    } catch (e) {
      console.log('❌ ERRO capcut:', e?.message)
      await reply('❌ Não consegui baixar esse vídeo do CapCut. Verifique o link.')
    }
  }
}
