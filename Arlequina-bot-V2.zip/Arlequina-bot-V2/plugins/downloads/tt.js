const {
  carregarUsuarios,
  salvarUsuarios,
  getUsuario
} = require('../../arquivos/js/rpgDB.js')

const {
  baixarPorLink,
  buscarPorNome,
  ehErroCloudflare
} = require('../../arquivos/js/tiktokDownload.js')

const {
  caixaArlequina
} = require('../../arquivos/js/estiloArlequina')

module.exports = {
  name: 'tt',

  description: 'Baixa vídeo do TikTok',

  category: 'downloads',

  aliases: ['tiktok'],

  async execute({
    arlequina,
    from,
    info,
    args,
    q,
    reply,
    reagir,
    prefix,
    sender,
    pushname,
    isGroup,
    donoJid,
    commandManager,
    config,
    getFileBuffer,
    sleep,
    fetchJson
  }) {

    const sock = arlequina

    const usuarios = carregarUsuarios()

    getUsuario(
      usuarios,
      sender
    )

    const enviar = async (conteudo) => {

      if (typeof conteudo === 'string') {
        return reply(conteudo)
      }

      try {

        return await sock.sendMessage(
          from,
          conteudo,
          {
            quoted: info
          }
        )

      } catch (e) {

        const fallback =
          conteudo?.caption ||
          conteudo?.text ||
          '✅'

        return reply(fallback)
      }
    }

    try {

      const entrada = String(q || '').trim()

      /*
       * SEM ARGUMENTO
       */

      if (!entrada) {

        return reply(
          '❌ Envie um link ou o nome do vídeo.\n\n' +
          `Ex: ${prefix || '!'}tt https://vm.tiktok.com/xxxxx\n` +
          `Ex: ${prefix || '!'}tt edit coringa`
        )
      }

      /*
       * DETECTA LINK
       */

      const ehLink =
        /(?:https?:\/\/)?(?:www\.)?(?:vm\.tiktok\.com|vt\.tiktok\.com|tiktok\.com)/i
          .test(entrada)

      /*
       * MENSAGEM INICIAL
       */

      if (ehLink) {

        await reply(
          '⏳ Baixando vídeo do TikTok...'
        )

      } else {

        await reply(
          `🔍 Procurando no TikTok:\n${entrada}`
        )
      }

      let video = null

      /*
       * DOWNLOAD POR LINK
       */

      if (ehLink) {

        video = await baixarPorLink(
          entrada,
          config?.VexApiKey
        )

        if (!video?.play) {

          return reply(
            '❌ Não consegui obter o vídeo desse link.'
          )
        }

      }

      /*
       * BUSCA POR NOME
       */

      else {

        const resultado =
          await buscarPorNome(entrada)

        if (!resultado) {

          return reply(
            '❌ A busca por nome não está disponível no momento.\n\n' +
            '💡 Tente enviar o link direto do TikTok.'
          )
        }

        video = resultado
      }

      /*
       * ENVIA VÍDEO
       */

      await enviar({

        video: {
          url: video.play
        },

        caption:
          caixaArlequina(
            'tt',
            `🎵 TikTok\n\n` +
            `📝 ${video.title || 'Sem título'}\n` +
            `👤 @${video.author?.unique_id || '?'}`
          )
      })

    } catch (e) {

      const foiCloudflare =
        ehErroCloudflare(e)

      console.log(
        '❌ ERRO tt:',
        foiCloudflare
          ? 'Cloudflare/HTTP 403 ou 429'
          : (e?.message || e)
      )

      if (foiCloudflare) {

        return reply(
          '❌ O serviço de download do TikTok bloqueou a requisição (403/429).\n\n' +
          '🔗 Tente novamente usando outro link ou mais tarde.'
        )
      }

      return reply(
        '❌ Erro ao baixar o vídeo do TikTok.\n\n' +
        `📋 ${e?.message || 'Erro desconhecido'}`
      )
    }

    finally {

      salvarUsuarios(
        usuarios
      )
    }
  }
}
