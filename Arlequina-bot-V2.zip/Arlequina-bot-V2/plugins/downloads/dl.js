/*
 Convertido automaticamente do connect.js (bot antigo monolitico) para
 o sistema de plugins da Arlequina Bot. Comando original: dl, baixar
*/
const { carregarUsuarios, salvarUsuarios, getUsuario } = require('../../arquivos/js/rpgDB.js')
const adminState = require('../../arquivos/js/adminState.js')
const donoState = require('../../arquivos/js/donoState.js')
const { imagemDaBrincadeira, buscarImagemAleatoria } = require('../../arquivos/js/brincadeirasHelpers.js')
const fs = require('fs')
const axios = require('axios')
const { exec } = require('child_process')
const { baixarPorLink, buscarPorNome, ehErroCloudflare } = require('../../arquivos/js/tiktokDownload.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'dl',
description: "Baixa mídia de um link",
category: 'downloads',
aliases: ["baixar"],
async execute({ arlequina, from, info, args, q, reply, reagir, prefix, sender, pushname, isGroup, donoJid, commandManager, config, getFileBuffer, sleep, fetchJson }) {

const sock = arlequina
const msg = info
const jid = sender
const jidReal = sender
const numeroReal = String(sender || '').split('@')[0]
const isGrupo = isGroup
const nome = pushname
const texto = q || args.join(' ')
const baixarMidia = (mediaMsg, tipo) => getFileBuffer(mediaMsg, tipo)

const ehDono = (jidAlvo, numeroAlvo) => {
const donoNum = String(donoJid || '').replace(/[^0-9]/g, '')
const num = String(numeroAlvo || '').replace(/[^0-9]/g, '')
return (donoNum && num === donoNum) || jidAlvo === donoJid
}

const usuarios = carregarUsuarios()
getUsuario(usuarios, sender)

const enviar = async (conteudo, _opcoes) => {
if (typeof conteudo === 'string') return reply(conteudo)
try {
return await sock.sendMessage(from, conteudo, { quoted: info })
} catch (e) {
const fallback = conteudo?.caption || conteudo?.text || '✅'
return reply(fallback)
}
}

try {
  const entrada = q
  
  if (!entrada)
  return reply('❌ Envie um link ou o nome do conteúdo.\n\nSuporta link: TikTok, Instagram, Twitter/X, Facebook, YouTube.\nSuporta busca por nome: TikTok e YouTube.\n\nEx: !dl https://...\nEx: !dl edit coringa')
  
  const ehLink = /^https?:\/\//.test(entrada)
  
  if (!ehLink) {
  
  await reply(`${caixaArlequina("dl", `🔍 Procurando:\n${entrada}`)}`)
  
  try {
  
  const resultado = await buscarPorNome(entrada)
  
  if (resultado?.play) {
  
  await enviar({
  video: { url: resultado.play },
  caption: caixaArlequina('dl', `🎵 TikTok\n\n📝 ${resultado.title || 'Sem título'}\n👤 @${resultado.author?.unique_id || '?'}`)
  }, { quoted: msg })
  
  return
  }
  
  } catch (e) {
  console.log('⚠️ baixar (busca TikTok):', ehErroCloudflare(e) ? 'Cloudflare bloqueou (403)' : e?.message)
  }
  
  // se não achou no TikTok, tenta YouTube
  const file = `./tmp_dl_${Date.now()}.mp4`
  
  try {
  
  const cmd = `python3 -m yt_dlp -o "${file}" "ytsearch1:${entrada}"`
  
  await new Promise((resolve, reject) => {
  exec(cmd, { maxBuffer: 1024 * 1024 * 100 }, (err, stdout, stderr) => {
  if (err) {
  console.log(stderr || err)
  return reject(err)
  }
  resolve()
  })
  })
  
  if (!fs.existsSync(file))
  return reply('❌ Nenhum resultado encontrado.')
  
  const buffer = fs.readFileSync(file)
  
  await enviar({
  video: buffer,
  caption: caixaArlequina('dl', '▶️ YouTube\n\n✅ Baixado com sucesso!')
  }, { quoted: msg })
  
  fs.unlinkSync(file)
  
  } catch (e) {
  console.log(e)
  if (fs.existsSync(file)) fs.unlinkSync(file)
  await reply('❌ Nenhum resultado encontrado.')
  }
  
  return
  }
  
  const link = entrada
  
  if (link.includes('tiktok.com')) {
  
  await reply('⏳ Baixando do TikTok...')
  
  try {
  const video = await baixarPorLink(link, config?.VexApiKey)
  
  if (!video?.play)
  return reply('❌ Não consegui baixar esse vídeo do TikTok.')
  
  await enviar({
  video: { url: video.play },
  caption: caixaArlequina('dl', `🎵 TikTok\n\n📝 ${video.title || 'Sem título'}`)
  }, { quoted: msg })
  } catch (e) {
  const foiCloudflare = ehErroCloudflare(e)
  console.log('❌ ERRO dl (tiktok):', foiCloudflare ? 'Cloudflare bloqueou (403)' : e?.message)
  await reply(foiCloudflare ? '❌ O TikWM bloqueou por Cloudflare, tenta de novo em alguns minutos.' : '❌ Erro ao baixar do TikTok.')
  }
  
  return
  }
  
  const plataforma =
  link.includes('instagram.com') ? '📸 Instagram' :
  (link.includes('twitter.com') || link.includes('x.com')) ? '🐦 Twitter/X' :
  (link.includes('facebook.com') || link.includes('fb.watch')) ? '📘 Facebook' :
  (link.includes('youtube.com') || link.includes('youtu.be')) ? '▶️ YouTube' :
  '🌐 Vídeo'
  
  await reply(`⏳ Baixando de ${plataforma}...`)
  
  const file = `./tmp_dl_${Date.now()}.mp4`
  
  try {
  
  const cmd = `python3 -m yt_dlp -o "${file}" "${link}"`
  
  await new Promise((resolve, reject) => {
  exec(cmd, { maxBuffer: 1024 * 1024 * 100 }, (err, stdout, stderr) => {
  if (err) {
  console.log(stderr || err)
  return reject(err)
  }
  resolve()
  })
  })
  
  if (!fs.existsSync(file))
  return reply('❌ Não consegui baixar esse conteúdo. Verifique o link.')
  
  const buffer = fs.readFileSync(file)
  
  await enviar({
  video: buffer,
  caption: caixaArlequina('dl', `${plataforma}\n\n✅ Baixado com sucesso!`)
  }, { quoted: msg })
  
  fs.unlinkSync(file)
  
  } catch (e) {
  console.log(e)
  if (fs.existsSync(file)) fs.unlinkSync(file)
  await reply('❌ Erro ao baixar.\n\nVerifique se o yt-dlp está instalado (pip install yt-dlp) e se o link é válido/público.')
  }
} catch (e) {
console.log('❌ ERRO (baixar):', e?.message)
await reply('❌ Não consegui executar esse comando agora.')
} finally {
salvarUsuarios(usuarios)
}

}
}
