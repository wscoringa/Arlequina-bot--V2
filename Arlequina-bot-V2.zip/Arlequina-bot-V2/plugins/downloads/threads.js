const { ytOk, baixarComYtDlp } = require('../../arquivos/js/ytdlpHelper.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
  name: 'threads',
  description: '🧵 Baixa vídeo/imagem do Threads',
  category: 'downloads',
  aliases: ['threadsdl'],
  async execute({ arlequina, from, info, q, args, reply, reagir, prefix }) {
    const link = (q || args.join(' ')).trim()
    if (!link || !link.includes('threads.net') && !link.includes('threads.com')) return reply(caixaArlequina('threads', `❌ Envie um link válido do Threads.\n💡 Ex: *${prefix}threads* https://www.threads.net/@user/post/xxxxx`))
    if (!await ytOk()) return reply('❌ yt-dlp não instalado! Rode: pip install -U yt-dlp')

    try {
      await reagir('🧵')
      const buffer = await baixarComYtDlp(link, 'tmp_threads')
      if (!buffer) return reply(caixaArlequina('threads', '❌ Não consegui baixar esse conteúdo do Threads (pode ser só texto/imagem sem vídeo).'))
      await arlequina.sendMessage(from, { video: buffer, caption: caixaArlequina('threads', '🧵 Threads\n\n✅ Baixado com sucesso!') }, { quoted: info })
    } catch (e) {
      console.log('❌ ERRO threads:', e?.message)
      await reply('❌ Não consegui baixar esse conteúdo do Threads. Verifique o link.')
    }
  }
}
