/*
 Busca imagens no Pinterest a partir de um termo de pesquisa.

 Antes esse comando fazia um esquema complicado direto no Pinterest
 (visitar a home pra pegar cookie/CSRF, chamar o endpoint interno deles,
 e cair pra um fallback de regex no HTML se isso falhasse) — muito
 frágil, quebrava toda hora que o Pinterest mudava alguma coisa.

 Agora usa uma API pronta (systemzone.store) que já devolve os links de
 imagem direto em JSON, bem mais simples e estável.
*/
const axios = require('axios')
const { baixarBufferUrl } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

const HEADERS_PADRAO = {
  'User-Agent': 'Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0 Mobile Safari/537.36'
}

const MAX_IMAGENS = 5

// Busca via API pronta (rápida, mas depende de um serviço de terceiro
// que pode cair). Se der ruim, buscarNoPinterestDireto() é o plano B.
async function buscarViaApi(termo) {
  const url = `https://systemzone.store/api/pinterest?q=${encodeURIComponent(termo)}&limit=10`
  const { data } = await axios.get(url, { timeout: 15000, headers: HEADERS_PADRAO })
  return (data?.results || []).map(r => r?.image_url).filter(Boolean)
}

// Plano B: busca direto na página de busca do Pinterest e extrai os
// links de imagem do HTML (i.pinimg.com/originals/...). Não depende de
// nenhum serviço de terceiro, só do próprio Pinterest.
async function buscarNoPinterestDireto(termo) {
  const url = `https://www.pinterest.com/search/pins/?q=${encodeURIComponent(termo)}`
  const { data: html } = await axios.get(url, {
    timeout: 15000,
    headers: { ...HEADERS_PADRAO, 'Accept-Language': 'pt-BR,pt;q=0.9' }
  })
  const encontrados = new Set()
  const regex = /https:\/\/i\.pinimg\.com\/(?:originals|736x|564x)\/[a-zA-Z0-9/._-]+\.(?:jpg|jpeg|png|webp)/g
  let m
  while ((m = regex.exec(html)) !== null) {
    // Troca qualquer tamanho pequeno (736x, 564x) pelo "originals" pra
    // pegar a imagem em resolução máxima
    encontrados.add(m[0].replace(/\/(736x|564x)\//, '/originals/'))
  }
  return Array.from(encontrados)
}

module.exports = {
  name: 'pinterest',
  description: '📌 Busca imagens no Pinterest pelo termo digitado',
  category: 'downloads',
  aliases: ['pin', 'pesquisarpin', 'pinterest2', 'pinimg', 'pinsearch'],

  async execute({ arlequina, from, info, q, args, reply, reagir, prefix }) {
    const p = prefix

    let termo = (q || args.join(' ')).trim()
    let quantidade = MAX_IMAGENS

    // Detecta quantidade no final (ex: "#pinterest gatinhos 3")
    const ultimoArg = args[args.length - 1]
    if (/^\d+$/.test(ultimoArg) && args.length > 1) {
      quantidade = parseInt(ultimoArg)
      termo = args.slice(0, -1).join(' ').trim()
    }
    quantidade = Math.min(Math.max(quantidade, 1), MAX_IMAGENS)

    if (!termo) {
      return reply(`
╭─━━─🃏💜「 🃏💜 *PINTEREST* 💜🃏 」💜🃏─━━─╮
┃ 📌 Como usar:
┃ ${p}pinterest <termo> [qtd]
┃
┃ 📸 Exemplos:
┃ ${p}pinterest gatinhos        (manda ${MAX_IMAGENS})
┃ ${p}pinterest paisagem 3
┃ ${p}pinterest anime 1
┃
┃ 🔥 Padrão: ${MAX_IMAGENS} imagens | Limite: ${MAX_IMAGENS}
╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯`.trim())
    }

    try {
      await reagir('🔍')

      let resultados = []
      let origemFalhou = null

      try {
        resultados = await buscarViaApi(termo)
      } catch (eApi) {
        origemFalhou = eApi
        console.log('⚠️ ERRO pinterest (API principal falhou, tentando plano B):', eApi?.response?.status || eApi?.code || eApi?.message)
      }

      if (resultados.length === 0) {
        try {
          resultados = await buscarNoPinterestDireto(termo)
        } catch (eDireto) {
          console.log('⚠️ ERRO pinterest (busca direta também falhou):', eDireto?.response?.status || eDireto?.code || eDireto?.message)
        }
      }

      if (resultados.length === 0) {
        await reagir('❌')
        return reply(caixaArlequina('pinterest', `❌ Não encontrei nada no Pinterest pra *${termo}* agora. Tenta de novo com outro termo, ou tenta de novo daqui a pouco (o Pinterest pode ter bloqueado temporariamente).`))
      }

      // Embaralha e baixa candidato por candidato até completar a
      // quantidade pedida (se algum link falhar ao baixar, tenta o
      // próximo em vez de mandar menos imagens do que devia).
      const candidatos = resultados.sort(() => Math.random() - 0.5)
      const buffersValidos = []

      for (const link of candidatos) {
        if (buffersValidos.length >= quantidade) break
        try {
          const buffer = await baixarBufferUrl(link)
          buffersValidos.push(buffer)
        } catch (eDownload) {
          console.log('❌ ERRO pinterest (baixar imagem):', eDownload?.code || eDownload?.message)
        }
      }

      if (buffersValidos.length === 0) {
        await reagir('❌')
        return reply('❌ Encontrei resultados, mas não consegui baixar nenhuma imagem. Tenta de novo.')
      }

      for (let i = 0; i < buffersValidos.length; i++) {
        const legenda = buffersValidos.length > 1
          ? `📌 *${termo}* (${i + 1}/${buffersValidos.length})`
          : `📌 *${termo}*`

        await arlequina.sendMessage(from, { image: buffersValidos[i], caption: legenda }, { quoted: info })

        if (i < buffersValidos.length - 1) {
          await new Promise(r => setTimeout(r, 600))
        }
      }

      await reagir('✅')
    } catch (e) {
      const status = e?.response?.status
      console.error('❌ ERRO pinterest:', status ? `HTTP ${status}` : (e?.code || e?.message), e?.response?.data ? JSON.stringify(e.response.data).slice(0, 200) : '')
      await reagir('❌')
      const dicaRede = e?.code === 'ENOTFOUND' || e?.code === 'ECONNREFUSED'
        ? '\n\n(Erro de rede/DNS do servidor — o bot não conseguiu acessar a internet.)'
        : status
        ? `\n\n(O serviço respondeu com erro ${status} — pode estar fora do ar ou bloqueando temporariamente.)`
        : ''
      await reply(`❌ Erro ao buscar *${termo}*.\nTente novamente com outro termo.${dicaRede}`)
    }
  }
}
