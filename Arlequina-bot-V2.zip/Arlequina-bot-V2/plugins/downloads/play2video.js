// ============================================================
//  plugins/download/play2video.js  (ATALHO)
//  play2video / p2vd <qualquer coisa>  =  pesquisa e manda o VÍDEO no chat
//  (estilo Play2)
//
//  Coloque na MESMA pasta do tube.js.
// ============================================================
const tube = require('./tube.js')

function pegarTexto(ctx) {
  const cands = [ctx.text, ctx.q, ctx.query, ctx.texto, Array.isArray(ctx.args) ? ctx.args.join(' ') : ctx.args]
  const achou = cands.find((v) => typeof v === 'string' && v.trim())
  if (achou) return achou.trim()
  if (typeof ctx.body === 'string' && ctx.body.trim()) return ctx.body.trim().split(/\s+/).slice(1).join(' ').trim()
  return ''
}

module.exports = {
  name: 'play2video',
  description: 'Pesquisa qualquer coisa e manda o vídeo (estilo Play2)',
  category: 'download',
  aliases: ['play2video', 'p2vd'],

  async execute(ctx) {
    const nome = pegarTexto(ctx)
    if (!nome) return ctx.reply('🎬 Diga o que você quer assistir.\nExemplo: *.p2vd MC Menor RF clipe*')
    return tube.execute({ ...ctx, text: 'video ' + nome, estilo: 'ytmusic' })
  },
}
