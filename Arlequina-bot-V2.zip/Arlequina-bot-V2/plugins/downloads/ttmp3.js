/*
 Convertido automaticamente do connect.js (bot antigo monolitico) para
 o sistema de plugins da Arlequina Bot. Comando original: tiktokaudio, ttmp3
*/
const { carregarUsuarios, salvarUsuarios, getUsuario } = require('../../arquivos/js/rpgDB.js')
const adminState = require('../../arquivos/js/adminState.js')
const donoState = require('../../arquivos/js/donoState.js')
const { imagemDaBrincadeira, buscarImagemAleatoria } = require('../../arquivos/js/brincadeirasHelpers.js')
const fs = require('fs')
const axios = require('axios')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'ttmp3',
description: "Baixa o áudio de um vídeo do TikTok",
category: 'downloads',
aliases: ["tiktokaudio"],
async execute({ arlequina, from, info, args, q, reply, reagir, prefix, sender, pushname, isGroup, donoJid, commandManager, config, getFileBuffer, sleep, fetchJson }) {

const sock = arlequina
const msg = info
const jid = sender
const jidReal = sender
const numeroReal = String(sender || '').split('@')[0]
const isGrupo = isGroup
const nome = pushname
const texto = q || args.join(' ')
const baixarMidia = (mediaMsg, tipo) => getFileBuffer(mediaMsg, tipo)

const ehDono = (jidAlvo, numeroAlvo) => {
const donoNum = String(donoJid || '').replace(/[^0-9]/g, '')
const num = String(numeroAlvo || '').replace(/[^0-9]/g, '')
return (donoNum && num === donoNum) || jidAlvo === donoJid
}

const usuarios = carregarUsuarios()
getUsuario(usuarios, sender)

const enviar = async (conteudo, _opcoes) => {
if (typeof conteudo === 'string') return reply(conteudo)
try {
return await sock.sendMessage(from, conteudo, { quoted: info })
} catch (e) {
const fallback = conteudo?.caption || conteudo?.text || '✅'
return reply(fallback)
}
}

try {
  const entrada = q
  
  if (!entrada)
  return reply(caixaArlequina("ttmp3", `❌ Envie um link ou o nome do vídeo.\n\nEx: !ttmp3 https://vm.tiktok.com/xxxxx\nEx: !ttmp3 edit coringa`))
  
  const ehLink = entrada.includes('tiktok.com')
  
  await reply(ehLink ? '⏳ Baixando áudio do TikTok...' : `🔍 Procurando no TikTok:\n${entrada}`)
  
  try {
  
  let video = null
  
  if (ehLink) {
  
  const { data } = await axios.get('https://www.tikwm.com/api/', {
  params: { url: entrada }
  })
  
  if (!data?.data?.music)
  return reply('❌ Não consegui baixar o áudio desse vídeo.')
  
  video = data.data
  
  } else {
  
  const { data } = await axios.get('https://www.tikwm.com/api/feed/search', {
  params: { keywords: entrada, count: 1 }
  })
  
  const resultado = data?.data?.videos?.[0]
  
  if (!resultado || !resultado.music)
  return reply('❌ Nenhum áudio encontrado com esse nome.')
  
  video = resultado
  }
  
  await enviar({
  audio: { url: video.music },
  mimetype: 'audio/mpeg'
  }, { quoted: msg })
  
  } catch (e) {
  console.log(e)
  await reply('❌ Erro ao baixar o áudio do TikTok.')
  }
} catch (e) {
console.log('❌ ERRO (ttmp3):', e?.message)
await reply('❌ Não consegui executar esse comando agora.')
} finally {
salvarUsuarios(usuarios)
}

}
}
