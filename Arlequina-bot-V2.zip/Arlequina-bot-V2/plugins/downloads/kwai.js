const { ytOk, baixarComYtDlp } = require('../../arquivos/js/ytdlpHelper.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
  name: 'kwai',
  description: '📱 Baixa vídeo do Kwai',
  category: 'downloads',
  aliases: ['kwaidl'],
  async execute({ arlequina, from, info, q, args, reply, reagir, prefix }) {
    const link = (q || args.join(' ')).trim()
    if (!link || !link.includes('kwai')) return reply(caixaArlequina('kwai', `❌ Envie um link válido do Kwai.\n💡 Ex: *${prefix}kwai* https://s.kwai.com/xxxxx`))
    if (!await ytOk()) return reply('❌ yt-dlp não instalado! Rode: pip install -U yt-dlp')

    try {
      await reagir('📱')
      const buffer = await baixarComYtDlp(link, 'tmp_kwai')
      if (!buffer) return reply(caixaArlequina('kwai', '❌ Não consegui baixar esse vídeo do Kwai.'))
      await arlequina.sendMessage(from, { video: buffer, caption: caixaArlequina('kwai', '📱 Kwai\n\n✅ Baixado com sucesso!') }, { quoted: info })
    } catch (e) {
      console.log('❌ ERRO kwai:', e?.message)
      await reply('❌ Não consegui baixar esse vídeo do Kwai. Verifique o link.')
    }
  }
}
