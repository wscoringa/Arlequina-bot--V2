/*
 MediaFire não é suportado pelo yt-dlp (é host de arquivo genérico, não
 vídeo). Aqui a gente pega o link de download direto que fica escondido
 na própria página, via regex simples (sem cheerio, pra não depender
 do undici que já deu problema em outros comandos).
*/
const axios = require('axios')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
  name: 'mediafire',
  description: '📂 Baixa arquivo do MediaFire',
  category: 'downloads',
  aliases: ['mf', 'mfdl'],
  async execute({ arlequina, from, info, q, args, reply, reagir, prefix }) {
    const link = (q || args.join(' ')).trim()
    if (!link || !link.includes('mediafire.com')) return reply(caixaArlequina('mediafire', `❌ Envie um link válido do MediaFire.\n💡 Ex: *${prefix}mediafire* https://www.mediafire.com/file/xxxxx`))

    try {
      await reagir('📂')
      const { data: html } = await axios.get(link, {
        timeout: 20000,
        headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36' }
      })

      const matchLink = html.match(/href="(https:\/\/download[^"]+)"/) || html.match(/aria-label="Download file"[^>]*href="([^"]+)"/)
      const matchNome = html.match(/<div class="dl-btn-label"[^>]*>([^<]+)<\/div>/) || html.match(/<title>([^<]+) - MediaFire<\/title>/)

      if (!matchLink) return reply(caixaArlequina('mediafire', '❌ Não consegui achar o link de download (o arquivo pode ter sido removido, ou o MediaFire mudou o layout).'))

      const urlDownload = matchLink[1]
      const nomeArquivo = matchNome?.[1]?.trim() || 'arquivo'

      const texto = `📂 *${nomeArquivo}*\n\n🔗 ${urlDownload}`
      await reply(caixaArlequina('mediafire', texto))
    } catch (e) {
      console.log('❌ ERRO mediafire:', e?.message)
      await reply('❌ Não consegui acessar esse link do MediaFire agora.')
    }
  }
}
