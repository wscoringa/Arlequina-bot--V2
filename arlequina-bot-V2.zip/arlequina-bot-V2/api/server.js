const http = require('http')
const fs = require('fs')
const path = require('path')

const config = JSON.parse(
  fs.readFileSync(path.join(__dirname, 'config.json'), 'utf8')
)

const botConfig = JSON.parse(
  fs.readFileSync(path.join(__dirname, '..', 'database', 'config.json'), 'utf8')
)

const { perguntarGemini } = require('../arquivos/js/geminiAI.js')
const { baixarPorLink } = require('../arquivos/js/tiktokDownload.js')

function responder(res, status, dados) {
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization'
  })

  res.end(JSON.stringify(dados))
}

function autorizado(req) {
  const header = req.headers.authorization || ''
  return header === `Bearer ${config.apiKey}`
}

function lerBody(req) {
  return new Promise((resolve, reject) => {
    let body = ''

    req.on('data', parte => {
      body += parte

      if (body.length > 1024 * 1024) {
        reject(new Error('Corpo da requisição muito grande'))
        req.destroy()
      }
    })

    req.on('end', () => {
      try {
        resolve(body ? JSON.parse(body) : {})
      } catch {
        reject(new Error('JSON inválido'))
      }
    })

    req.on('error', reject)
  })
}

const server = http.createServer(async (req, res) => {

  if (req.method === 'GET' && req.url.startsWith('/api/tiktok/buscar')) {
    const auth = req.headers.authorization || '';

    if (auth !== 'Bearer ' + configApi.apiKey) {
      return responder(res, 401, {
        sucesso: false,
        erro: 'Não autorizado'
      });
    }

    const query = new URL(req.url, 'http://localhost').searchParams.get('query');

    if (!query) {
      return responder(res, 400, {
        sucesso: false,
        erro: 'Informe ?query=flamengo'
      });
    }

    try {
      const resposta = await axios.get(
        'https://www.socialcrawl.dev/v1/tiktok/search',
        {
          params: {
            query,
            limit: 10
          },
          headers: {
            'x-api-key': configApi.socialCrawlApiKey
          }
        }
      );

      return responder(res, 200, {
        sucesso: true,
        query,
        resultados: resposta.data?.data?.items || []
      });

    } catch (e) {
      return responder(res, e.response?.status || 500, {
        sucesso: false,
        erro: e.response?.data || e.message
      });
    }
  }

  if (req.method === 'OPTIONS') {
    return responder(res, 204, {})
  }

  if (req.url === '/api/status' && req.method === 'GET') {
    return responder(res, 200, {
      sucesso: true,
      bot: 'Arlequina',
      api: 'online',
      versao: '1.1.0',
      servicos: {
        gemini: !!botConfig.GeminiApiKey,
        tiktok: true
      }
    })
  }

  if (!autorizado(req)) {
    return responder(res, 401, {
      sucesso: false,
      erro: 'Não autorizado'
    })
  }

  if (req.url === '/api/teste' && req.method === 'GET') {
    return responder(res, 200, {
      sucesso: true,
      mensagem: 'API da Arlequina funcionando!'
    })
  }

  if (req.url === '/api/ia/gemini' && req.method === 'POST') {
    try {
      const body = await lerBody(req)
      const mensagem = String(body.mensagem || body.pergunta || '').trim()

      if (!mensagem) {
        return responder(res, 400, {
          sucesso: false,
          erro: 'Envie "mensagem" no JSON'
        })
      }

      const resultado = await perguntarGemini(
        mensagem,
        botConfig.GeminiApiKey
      )

      if (resultado.erro) {
        return responder(res, 502, {
          sucesso: false,
          erro: resultado.mensagem
        })
      }

      return responder(res, 200, {
        sucesso: true,
        provedor: 'gemini',
        resposta: resultado.resposta
      })

    } catch (e) {
      console.log('❌ API Gemini:', e.message)

      return responder(res, 500, {
        sucesso: false,
        erro: 'Erro ao processar a requisição da IA'
      })
    }
  }

  if (req.url === '/api/tiktok' && req.method === 'POST') {
    try {
      const body = await lerBody(req)
      const url = String(body.url || body.link || '').trim()

      if (!url) {
        return responder(res, 400, {
          sucesso: false,
          erro: 'Envie "url" com o link do TikTok'
        })
      }

      if (!url.includes('tiktok.com')) {
        return responder(res, 400, {
          sucesso: false,
          erro: 'URL do TikTok inválida'
        })
      }

      const video = await baixarPorLink(
        url,
        botConfig.VexApiKey
      )

      return responder(res, 200, {
        sucesso: true,
        tipo: 'tiktok',
        video: {
          url: video.play,
          titulo: video.title || 'TikTok',
          autor: video.author || {}
        }
      })

    } catch (e) {
      console.log('❌ API TikTok:', e.message)

      return responder(res, 502, {
        sucesso: false,
        erro: 'Não foi possível obter o vídeo do TikTok'
      })
    }
  }

  return responder(res, 404, {
    sucesso: false,
    erro: 'Rota não encontrada'
  })
})

server.listen(config.porta, '0.0.0.0', () => {
  console.log('\n🃏 API DA ARLEQUINA ONLINE')
  console.log(`🌐 Porta: ${config.porta}`)
  console.log('🔐 Autenticação: Bearer Token')
  console.log('\nRotas:')
  console.log('GET  /api/status')
  console.log('GET  /api/teste')
  console.log('POST /api/ia/gemini')
  console.log('POST /api/tiktok')
})
