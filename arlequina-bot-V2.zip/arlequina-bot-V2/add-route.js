const fs = require('fs');

const p = 'api/server.js';
let s = fs.readFileSync(p, 'utf8');

if (s.includes('/api/tiktok/buscar')) {
  console.log('Rota já existe');
  process.exit(0);
}

const marker = "const server = http.createServer(async (req, res) => {";

if (!s.includes(marker)) {
  console.log('ERRO: ponto do server.js não encontrado');
  process.exit(1);
}

const bloco = `
  if (req.method === 'GET' && req.url.startsWith('/api/tiktok/buscar')) {
    const auth = req.headers.authorization || '';

    if (auth !== 'Bearer ' + configApi.apiKey) {
      return responder(res, 401, {
        sucesso: false,
        erro: 'Não autorizado'
      });
    }

    const query = new URL(req.url, 'http://localhost').searchParams.get('query');

    if (!query) {
      return responder(res, 400, {
        sucesso: false,
        erro: 'Informe ?query=flamengo'
      });
    }

    try {
      const resposta = await axios.get(
        'https://www.socialcrawl.dev/v1/tiktok/search',
        {
          params: {
            query,
            limit: 10
          },
          headers: {
            'x-api-key': configApi.socialCrawlApiKey
          }
        }
      );

      return responder(res, 200, {
        sucesso: true,
        query,
        resultados: resposta.data?.data?.items || []
      });

    } catch (e) {
      return responder(res, e.response?.status || 500, {
        sucesso: false,
        erro: e.response?.data || e.message
      });
    }
  }
`;

s = s.replace(marker, marker + '\n' + bloco);

fs.writeFileSync(p, s);
console.log('Rota adicionada com sucesso');
