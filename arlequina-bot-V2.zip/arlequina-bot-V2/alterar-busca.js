const fs = require('fs');

const p = 'arquivos/js/tiktokDownload.js';
let s = fs.readFileSync(p, 'utf8');

const inicio = s.indexOf('async function buscarPorNome(query) {');
const fim = s.indexOf('\n}\n\nasync function buscarListaPorNome', inicio);

if (inicio === -1 || fim === -1) {
  console.log('ERRO: função buscarPorNome não encontrada');
  process.exit(1);
}

const novaFuncao = `async function buscarPorNome(query) {
  if (!query || !String(query).trim()) {
    return null
  }

  query = String(query).trim()

  console.log(\`🔎 Procurando no TikTok via SocialCrawl: \${query}\`)

  try {
    const apiKey = process.env.SOCIALCRAWL_API_KEY

    if (!apiKey) {
      console.log('❌ SOCIALCRAWL_API_KEY não configurada')
      return null
    }

    const { data } = await axios.get(
      'https://www.socialcrawl.dev/v1/tiktok/search',
      {
        params: {
          query,
          limit: 1
        },
        headers: {
          'x-api-key': apiKey
        }
      }
    )

    const item = data?.data?.items?.[0]
    const post = item?.post

    if (!post?.content?.media_urls) {
      console.log('❌ Nenhum vídeo encontrado')
      return null
    }

    return {
      play: post.content.media_urls,
      video_url: post.content.media_urls,
      title: post.content.text || query,
      desc: post.content.text || query,
      author: post.author?.username || '',
      author_name: post.author?.display_name || '',
      thumbnail: post.content.thumbnail_url || '',
      duration: post.content.duration_seconds || 0,
      url: post.url || ''
    }

  } catch (e) {
    console.log(
      '❌ Erro SocialCrawl:',
      e.response?.status || e.message
    )
    return null
  }
}`;

s = s.slice(0, inicio) + novaFuncao + s.slice(fim + 2);

fs.writeFileSync(p, s);
console.log('buscarPorNome atualizada com SocialCrawl');
