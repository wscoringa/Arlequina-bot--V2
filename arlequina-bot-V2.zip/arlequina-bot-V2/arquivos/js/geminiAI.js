const axios = require('axios')

const MODELOS = [
  'gemini-3.8-flash',
  'gemini-3.7-flash',
  'gemini-3.1-flash-lite'
]

async function perguntarGemini(pergunta, apiKey) {
  if (!apiKey) {
    return {
      erro: true,
      mensagem: 'Chave da Gemini não configurada.'
    }
  }

  let ultimoErro = null

  for (const modelo of MODELOS) {
    try {
      const url =
        `https://generativelanguage.googleapis.com/v1beta/models/${modelo}:generateContent?key=${apiKey}`

      const { data } = await axios.post(
        url,
        {
          contents: [
            {
              parts: [{ text: pergunta }]
            }
          ]
        },
        {
          timeout: 30000
        }
      )

      const resposta =
        data?.candidates?.[0]?.content?.parts?.[0]?.text

      if (resposta) {
        console.log(`✅ Gemini respondeu usando ${modelo}`)

        return {
          erro: false,
          resposta: resposta.trim()
        }
      }

      ultimoErro = `Modelo ${modelo} não retornou resposta`

    } catch (e) {
      const status = e?.response?.status

      console.log(`⚠️ Gemini ${modelo}: HTTP ${status || e?.code || 'erro'}`)

      ultimoErro = e

      if (status === 400) {
        return {
          erro: true,
          mensagem: 'A Gemini rejeitou a requisição ou a chave é inválida.'
        }
      }

      if (status === 429) {
        continue
      }

      if (status === 404 || status === 503 || status === 500) {
        continue
      }
    }
  }

  return {
    erro: true,
    mensagem: 'Todos os modelos Gemini estão temporariamente indisponíveis. Tente novamente em alguns segundos.'
  }
}

module.exports = { perguntarGemini }
