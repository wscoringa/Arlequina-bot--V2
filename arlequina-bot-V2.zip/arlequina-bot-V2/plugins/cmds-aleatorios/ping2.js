const os = require('os')
const { Jimp, rgbaToInt } = require('jimp')

/*
╔══════════════════════════════════════════════╗
║        ARLEQUINA PING2 - IMAGE SYSTEM       ║
║     PNG 100% gerado pelo próprio Jimp       ║
╚══════════════════════════════════════════════╝
*/

// Fonte bitmap 5x7
const FONT = {
  'A': ['01110','10001','10001','11111','10001','10001','10001'],
  'B': ['11110','10001','10001','11110','10001','10001','11110'],
  'C': ['01111','10000','10000','10000','10000','10000','01111'],
  'D': ['11110','10001','10001','10001','10001','10001','11110'],
  'E': ['11111','10000','10000','11110','10000','10000','11111'],
  'F': ['11111','10000','10000','11110','10000','10000','10000'],
  'G': ['01111','10000','10000','10111','10001','10001','01111'],
  'H': ['10001','10001','10001','11111','10001','10001','10001'],
  'I': ['11111','00100','00100','00100','00100','00100','11111'],
  'J': ['00111','00010','00010','00010','10010','10010','01100'],
  'K': ['10001','10010','10100','11000','10100','10010','10001'],
  'L': ['10000','10000','10000','10000','10000','10000','11111'],
  'M': ['10001','11011','10101','10101','10001','10001','10001'],
  'N': ['10001','11001','10101','10011','10001','10001','10001'],
  'O': ['01110','10001','10001','10001','10001','10001','01110'],
  'P': ['11110','10001','10001','11110','10000','10000','10000'],
  'Q': ['01110','10001','10001','10001','10101','10010','01101'],
  'R': ['11110','10001','10001','11110','10100','10010','10001'],
  'S': ['01111','10000','10000','01110','00001','00001','11110'],
  'T': ['11111','00100','00100','00100','00100','00100','00100'],
  'U': ['10001','10001','10001','10001','10001','10001','01110'],
  'V': ['10001','10001','10001','10001','10001','01010','00100'],
  'W': ['10001','10001','10001','10101','10101','11011','10001'],
  'X': ['10001','10001','01010','00100','01010','10001','10001'],
  'Y': ['10001','10001','01010','00100','00100','00100','00100'],
  'Z': ['11111','00001','00010','00100','01000','10000','11111'],

  '0': ['01110','10001','10011','10101','11001','10001','01110'],
  '1': ['00100','01100','00100','00100','00100','00100','01110'],
  '2': ['01110','10001','00001','00010','00100','01000','11111'],
  '3': ['11110','00001','00001','01110','00001','00001','11110'],
  '4': ['00010','00110','01010','10010','11111','00010','00010'],
  '5': ['11111','10000','10000','11110','00001','00001','11110'],
  '6': ['01110','10000','10000','11110','10001','10001','01110'],
  '7': ['11111','00001','00010','00100','01000','01000','01000'],
  '8': ['01110','10001','10001','01110','10001','10001','01110'],
  '9': ['01110','10001','10001','01111','00001','00001','01110'],

  ':': ['00000','00100','00100','00000','00100','00100','00000'],
  '.': ['00000','00000','00000','00000','00000','00110','00110'],
  '/': ['00001','00010','00100','01000','10000','00000','00000'],
  '-': ['00000','00000','00000','11111','00000','00000','00000'],
  '_': ['00000','00000','00000','00000','00000','00000','11111'],
  '%': ['11001','11010','00010','00100','01000','01011','10011'],
  '|': ['00100','00100','00100','00100','00100','00100','00100'],
  '#': ['01010','11111','01010','01010','11111','01010','01010'],
  '+': ['00000','00100','00100','11111','00100','00100','00000'],
  '*': ['00000','10101','01110','11111','01110','10101','00000'],
  '=': ['00000','11111','00000','11111','00000','00000','00000'],
  '>': ['10000','01000','00100','00010','00100','01000','10000'],
  '<': ['00001','00010','00100','01000','00100','00010','00001'],
  '[': ['01110','01000','01000','01000','01000','01000','01110'],
  ']': ['01110','00010','00010','00010','00010','00010','01110'],
  '(': ['00010','00100','01000','01000','01000','00100','00010'],
  ')': ['01000','00100','00010','00010','00010','00100','01000'],
  ' ': ['00000','00000','00000','00000','00000','00000','00000']
}

function color(hex, alpha = 255) {
  return rgbaToInt(
    parseInt(hex.slice(1, 3), 16),
    parseInt(hex.slice(3, 5), 16),
    parseInt(hex.slice(5, 7), 16),
    alpha
  )
}

function pixel(img, x, y, c) {
  if (x < 0 || y < 0 || x >= img.bitmap.width || y >= img.bitmap.height) return
  img.bitmap.data.writeUInt32BE(c >>> 0, (y * img.bitmap.width + x) * 4)
}

function rect(img, x, y, w, h, c) {
  for (let yy = y; yy < y + h; yy++) {
    for (let xx = x; xx < x + w; xx++) {
      pixel(img, xx, yy, c)
    }
  }
}

function line(img, x1, y1, x2, y2, c) {
  const dx = Math.abs(x2 - x1)
  const dy = Math.abs(y2 - y1)
  const sx = x1 < x2 ? 1 : -1
  const sy = y1 < y2 ? 1 : -1

  let err = dx - dy

  while (true) {
    pixel(img, x1, y1, c)

    if (x1 === x2 && y1 === y2) break

    const e2 = err * 2

    if (e2 > -dy) {
      err -= dy
      x1 += sx
    }

    if (e2 < dx) {
      err += dx
      y1 += sy
    }
  }
}

function textWidth(text, scale = 2) {
  return text.length * (6 * scale)
}

function drawText(img, text, x, y, scale, c) {
  text = String(text).toUpperCase()

  for (const ch of text) {
    const glyph = FONT[ch] || FONT[' ']

    for (let gy = 0; gy < 7; gy++) {
      for (let gx = 0; gx < 5; gx++) {
        if (glyph[gy][gx] === '1') {
          rect(
            img,
            x + gx * scale,
            y + gy * scale,
            scale,
            scale,
            c
          )
        }
      }
    }

    x += 6 * scale
  }
}

function drawCentered(img, text, y, scale, c) {
  const w = textWidth(text, scale)
  const x = Math.floor((img.bitmap.width - w) / 2)
  drawText(img, text, x, y, scale, c)
}

function panel(img, x, y, w, h) {
  const bg = color('#0B0714')
  const border = color('#7A1FFF')

  rect(img, x, y, w, h, bg)

  line(img, x, y, x + w, y, border)
  line(img, x, y + h, x + w, y + h, border)
  line(img, x, y, x, y + h, border)
  line(img, x + w, y, x + w, y + h, border)

  // pequenos detalhes neon
  line(img, x, y, x + 45, y, color('#FF1493'))
  line(img, x + w - 45, y + h, x + w, y + h, color('#00E5FF'))
}

function formatUptime(sec) {
  const d = Math.floor(sec / 86400)
  const h = Math.floor((sec % 86400) / 3600)
  const m = Math.floor((sec % 3600) / 60)
  const s = sec % 60

  return [
    d ? `${d}D` : '',
    h ? `${h}H` : '',
    m ? `${m}M` : '',
    `${s}S`
  ].filter(Boolean).join(' ')
}

function getStatus(ping) {
  if (ping <= 300) return ['EXCELENTE', 10]
  if (ping <= 700) return ['BOA', 8]
  if (ping <= 1500) return ['MEDIA', 6]
  if (ping <= 3000) return ['LENTA', 4]
  return ['CRITICA', 2]
}

module.exports = {
  name: 'ping2',
  description: 'Painel visual de status da Arlequina',
  category: 'cmds-aleatorios',
  aliases: [],

  async execute({
    arlequina,
    from,
    info,
    reply,
    reagir,
    config,
    commandManager
  }) {
    try {
      await reagir('🃏')

      const inicio = Date.now()

      // Informações reais do processo
      const mem = process.memoryUsage()
      const rssMB = (mem.rss / 1024 / 1024).toFixed(1)

      const totalRAM = (
        os.totalmem() /
        1024 /
        1024 /
        1024
      ).toFixed(1)

      const freeRAM = (
        os.freemem() /
        1024 /
        1024 /
        1024
      ).toFixed(1)

      const cpuLoad = (os.loadavg()[0] || 0).toFixed(2)

      const uptime = formatUptime(
        Math.floor(process.uptime())
      )

      const platform = os.platform().toUpperCase()
      const arch = os.arch().toUpperCase()
      const nodeVersion = process.version.toUpperCase()

      const botName =
        config?.NomeDoBot ||
        config?.nomeBot ||
        'ARLEQUINA'

      // Contagem real de comandos
      let commandCount = 0
      let categoryCount = 0

      try {
        if (commandManager?.ObterTodosComandos) {
          const todos = commandManager.ObterTodosComandos()

          commandCount = todos.filter(
            c => !c.isAlias
          ).length
        }

        if (commandManager?.categorias) {
          categoryCount =
            commandManager.categorias.length
        }
      } catch (_) {}

      /*
       * O ping abaixo representa o tempo de processamento
       * deste diagnóstico local.
       */
      const ping = Date.now() - inicio

      const [status, bars] = getStatus(ping)

      // =========================
      // IMAGEM
      // =========================

      const W = 1200
      const H = 720

      const img = new Jimp({
        width: W,
        height: H,
        color: color('#05030A')
      })

      // Fundo
      rect(img, 0, 0, W, H, color('#05030A'))

      // Faixas decorativas
      rect(img, 0, 0, W, 5, color('#FF1493'))
      rect(img, 0, 5, W, 3, color('#7A1FFF'))
      rect(img, H - 8, 0, W, 8, color('#00E5FF'))

      // Moldura
      line(img, 18, 18, W - 18, 18, color('#7A1FFF'))
      line(img, 18, H - 18, W - 18, H - 18, color('#7A1FFF'))
      line(img, 18, 18, 18, H - 18, color('#7A1FFF'))
      line(img, W - 18, 18, W - 18, H - 18, color('#7A1FFF'))

      // =========================
      // CABEÇALHO
      // =========================

      drawText(
        img,
        'ARLEQUINA',
        45,
        42,
        5,
        color('#FF4DB8')
      )

      drawText(
        img,
        'CRIME SYSTEM // JOKER NETWORK',
        48,
        82,
        2,
        color('#A88BFF')
      )

      // Status
      panel(img, 790, 35, 345, 100)

      drawText(
        img,
        'SYSTEM STATUS',
        815,
        52,
        2,
        color('#A88BFF')
      )

      drawText(
        img,
        'ONLINE',
        815,
        82,
        4,
        color('#00FF9D')
      )

      drawText(
        img,
        'SECURE',
        1010,
        88,
        2,
        color('#00E5FF')
      )

      // =========================
      // PING GRANDE
      // =========================

      panel(img, 45, 135, 1110, 130)

      drawText(
        img,
        'NETWORK LATENCY',
        75,
        158,
        2,
        color('#8B6CFF')
      )

      drawText(
        img,
        `${ping} MS`,
        75,
        190,
        7,
        color('#FFFFFF')
      )

      drawText(
        img,
        status,
        850,
        202,
        3,
        status === 'EXCELENTE'
          ? color('#00FF9D')
          : color('#FFCC00')
      )

      // =========================
      // PAINEIS
      // =========================

      panel(img, 45, 285, 350, 220)
      panel(img, 425, 285, 350, 220)
      panel(img, 805, 285, 350, 220)

      // Sistema
      drawText(
        img,
        'SYSTEM INFORMATION',
        65,
        305,
        2,
        color('#FF4DB8')
      )

      drawText(
        img,
        `UPTIME ${uptime}`,
        65,
        340,
        2,
        color('#FFFFFF')
      )

      drawText(
        img,
        `RAM ${rssMB} MB`,
        65,
        370,
        2,
        color('#FFFFFF')
      )

      drawText(
        img,
        `TOTAL ${totalRAM} GB`,
        65,
        400,
        2,
        color('#FFFFFF')
      )

      drawText(
        img,
        `FREE ${freeRAM} GB`,
        65,
        430,
        2,
        color('#FFFFFF')
      )

      // Core
      drawText(
        img,
        'ARLEQUINA CORE',
        445,
        305,
        2,
        color('#FF4DB8')
      )

      drawText(
        img,
        `BOT ${botName}`,
        445,
        340,
        2,
        color('#FFFFFF')
      )

      drawText(
        img,
        `COMMANDS ${commandCount}`,
        445,
        370,
        2,
        color('#FFFFFF')
      )

      drawText(
        img,
        `CATEGORIES ${categoryCount}`,
        445,
        400,
        2,
        color('#FFFFFF')
      )

      drawText(
        img,
        `NODE ${nodeVersion}`,
        445,
        430,
        2,
        color('#FFFFFF')
      )

      // Network
      drawText(
        img,
        'NETWORK',
        825,
        305,
        2,
        color('#FF4DB8')
      )

      drawText(
        img,
        `PLATFORM ${platform}`,
        825,
        340,
        2,
        color('#FFFFFF')
      )

      drawText(
        img,
        `ARCH ${arch}`,
        825,
        370,
        2,
        color('#FFFFFF')
      )

      drawText(
        img,
        `CPU LOAD ${cpuLoad}`,
        825,
        400,
        2,
        color('#FFFFFF')
      )

      drawText(
        img,
        `BAILEYS ${require('@whiskeysockets/baileys/package.json').version}`,
        825,
        430,
        2,
        color('#FFFFFF')
      )

      // =========================
      // GRÁFICO
      // =========================

      panel(img, 45, 530, 1110, 135)

      drawText(
        img,
        'SYSTEM PERFORMANCE',
        70,
        550,
        2,
        color('#A88BFF')
      )

      // Barra
      const barX = 70
      const barY = 590
      const barW = 900
      const barH = 22

      rect(
        img,
        barX,
        barY,
        barW,
        barH,
        color('#171020')
      )

      const segmentW = 78
      const gap = 10

      for (let i = 0; i < 10; i++) {
        const active = i < bars

        rect(
          img,
          barX + i * (segmentW + gap),
          barY,
          segmentW,
          barH,
          active
            ? color(i < 7 ? '#7A1FFF' : '#00E5FF')
            : color('#20152D')
        )
      }

      drawText(
        img,
        '0',
        70,
        625,
        2,
        color('#6F6380')
      )

      drawText(
        img,
        '100',
        925,
        625,
        2,
        color('#6F6380')
      )

      // Online final
      drawText(
        img,
        'ONLINE',
        1010,
        588,
        2,
        color('#00FF9D')
      )

      // Rodapé
      drawText(
        img,
        'ARLEQUINA CRIME SYSTEM',
        45,
        680,
        2,
        color('#6F6380')
      )

      drawText(
        img,
        'JOKER NETWORK',
        900,
        680,
        2,
        color('#6F6380')
      )

      // =========================
      // PNG
      // =========================

      const buffer = await img.getBuffer('image/png')

      await arlequina.sendMessage(
        from,
        {
          image: buffer,
          caption: `🃏 *ARLEQUINA PING2*

📡 Ping: *${ping}ms*
🟢 Status: *${status}*
⏱️ Uptime: *${uptime}*
💻 CPU: *${cpuLoad}*
🧠 RAM: *${rssMB} MB*
⚙️ Comandos: *${commandCount}*`
        },
        { quoted: info }
      )

    } catch (e) {
      console.error('❌ ERRO ping2:', e)

      try {
        await reply(
          `❌ Erro no ping2:\n${e.message}`
        )
      } catch (_) {}
    }
  }
}